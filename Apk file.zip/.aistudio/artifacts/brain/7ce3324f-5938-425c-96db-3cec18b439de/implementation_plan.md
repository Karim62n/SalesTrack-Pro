# SalesTrack Pro (সেলস ও বিজনেস ম্যানেজমেন্ট সিস্টেম)

একটি পূর্ণাঙ্গ, সুরক্ষিত, রিয়েল-টাইম এবং এন্টারপ্রাইজ-গ্রেড সেলস ও বিজনেস ম্যানেজমেন্ট অ্যান্ড্রয়েড অ্যাপ্লিকেশন। এই সিস্টেমে অ্যাডমিন ও ইউজারের জন্য আলাদা রোল, রিয়েল-টাইম ড্যাশবোর্ড, সেলস টার্গেট ট্র্যাকিং, অর্ডার ও কাস্টমার ম্যানেজমেন্ট, নিখুঁত আয়-ব্যয় ও প্রফিট/লস হিসাব, এবং Steadfast Courier API ইন্টিগ্রেশন (স্যান্ডবক্স ও প্রোডাকশন মোড সহ) অন্তর্ভুক্ত।

---

## ইউজার রিভিউ ও গুরুত্বপূর্ণ সিদ্ধান্তসমূহ (User Review & Critical Decisions)

> [!IMPORTANT]
> **ব্যবহারকারীর নির্ধারিত পছন্দসমূহ (Confirmed Decisions):**
> 1. **Steadfast কুরিয়ার সেটআপ:** স্যান্ডবক্স ডেমো মোড দিয়ে শুরু হবে। সেটিংস স্ক্রিন থেকে অ্যাডমিন নিরাপদে মার্চেন্ট এপিআই কি (API Key) এবং সিক্রেট (Secret Key) দিয়ে টেস্ট বা লাইভ প্রোডাকশন মোডে রূপান্তর করতে পারবেন। রিয়েল কুরিয়ারে কোনো ডেমো বা টেস্ট পার্সেল পাঠানো হবে না।
> 2. **ভাষা পছন্দ:** বাংলা এবং ইংরেজি - উভয় ভাষার জন্য তাৎক্ষণিক টগল বাতি (Language Switcher) দেওয়া থাকবে, যাতে যে কোনো সাধারণ ইউজার সহজে ব্যবহার করতে পারেন।
> 3. **সেন্ট্রাল ডেটাবেস ও অফলাইন ক্যাশিং:** সেন্ট্রাল ক্লাউড ডেটাবেস আর্কিটেকচার (PostgreSQL/Supabase compatible) যার সাথে স্থানীয় ডিভাইসে রোবাস্ট ক্যাশিং (Room Local Persistence) থাকবে, ফলে ইন্টারনেট স্লো থাকলেও দ্রুত কাজ করবে এবং কানেকশন ফিরলে অটোমেটিক ক্লাউডে সিঙ্ক হবে।
> 4. **লোগো ও ব্র্যান্ডিং:** ইউজারের আপলোডকৃত প্রিমিয়াম মডার্ন অ্যারো লোগোটি (`/public/assets/aistudio/1794415729895_46c8f1a4.jpg`) অ্যাপ আইকন এবং ব্র্যান্ড হেডার হিসেবে ব্যবহৃত হবে।

---

## ১. সম্পূর্ণ সিস্টেম আর্কিটেকচার (System Architecture)

### সহজ বাংলায় ব্যাখ্যা (Simple Explanation in Bangla for Beginners):
এই অ্যাপটি **Clean Architecture & MVVM (Model-View-ViewModel)** পদ্ধতিতে তৈরি হবে। 
- **View (UI Layer):** ব্যবহারকারী যা স্ক্রিনে দেখতে পান (বাটন, কার্ড, গ্রাফ, ফর্ম)। এটি Jetpack Compose দিয়ে তৈরি।
- **ViewModel (Logic Layer):** হিসাব-নিকাশ, পারমিশন যাচাই এবং বাটনে ক্লিক করার পর কী ঘটবে তা নিয়ন্ত্রণ করে।
- **Repository (Data Layer):** ডেটাবেস থেকে তথ্য আনা এবং পাঠানো নিয়ন্ত্রণ করে।
- **Central Database (Cloud DB / PostgreSQL):** মূল সার্ভার যেখানে সব দোকান বা ইউজারের তথ্য একসাথে সুরক্ষিতভাবে জমা থাকে।
- **Steadfast API Handler:** কুরিয়ার বুকিং, ট্র্যাকিং কোড তৈরি এবং স্ট্যাটাস আপডেট করার জন্য একটি সুরক্ষিত গেটওয়ে।

```
┌────────────────────────────────────────────────────────────────────────┐
│                   Android Presentation Layer (Jetpack Compose)         │
│  ┌─────────────────────────────┐     ┌──────────────────────────────┐  │
│  │   Admin Dashboard & Tools   │     │    User Field Dashboard      │  │
│  └──────────────┬──────────────┘     └──────────────┬───────────────┘  │
│                 │                                   │                  │
│                 ▼                                   ▼                  │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │                StateFlow & ViewModels (Business Logic)           │  │
│  │  - Auth & Permission Check     - Financial Formulas & P&L        │  │
│  │  - Order Lifecycle Auditor     - Steadfast Courier Coordinator   │  │
│  └──────────────────────────────────┬───────────────────────────────┘  │
└─────────────────────────────────────┼──────────────────────────────────┘
                                      │
                                      ▼
┌────────────────────────────────────────────────────────────────────────┐
│                      Repository & Synchronization Layer                │
│  ┌─────────────────────────────────┐   ┌────────────────────────────┐  │
│  │ Local Cache & Offline (Room DB) │◄──┤ Sync Engine & Conflict Res │  │
│  └─────────────────────────────────┘   └─────────────┬──────────────┘  │
└──────────────────────────────────────────────────────┼─────────────────┘
                                                       │
                           ┌───────────────────────────┴──────────┐
                           ▼                                      ▼
┌──────────────────────────────────────────────┐ ┌──────────────────────┐
│  Cloud Central Database (PostgreSQL / RLS)   │ │ Steadfast Gateway    │
│  - profiles, permissions, orders, ledger     │ │ - Sandbox Mock Engine│
│  - Secure Row-Level Security Rules           │ │ - Live Courier API   │
└──────────────────────────────────────────────┘ └──────────────────────┘
```

---

## ২. স্ক্রিন ও নেভিগেশন ফ্লো (Screens & Navigation Flow)

অ্যাপটিতে অ্যাডমিন এবং সাধারণ সেলস ইউজারদের জন্য প্রিমিয়াম Material 3 বটম নেভিগেশন ও সাইড ড্রয়ার থাকবে।

```
[Splash & Session Check]
        │
        ▼
[Login Screen] (User ID / Admin ID & Password)
        │
   ┌────┴───────────────────────────┐
   ▼                                ▼
[Role: ADMIN]                  [Role: USER]
 ├── Bottom Nav:                ├── Bottom Nav:
 │    ├── 1. Admin Dashboard     │    ├── 1. User Dashboard (My Stats & Target)
 │    ├── 2. Order Management    │    ├── 2. My Orders (Add/View permitted)
 │    ├── 3. Finance & P&L       │    ├── 3. Customers
 │    ├── 4. Courier & Steadfast │    └── 4. Profile & Target History
 │    └── 5. More (Settings)    └── Sub-screens:
 └── Sub-screens:                    ├── Order Details & Tracking
      ├── User Management & Rights   └── Daily Sales Entry Form
      ├── Sales Target Setter
      ├── Return Review Center
      ├── Financial Ledger (Income/Expense)
      ├── Reports (PDF/Excel Export)
      └── Steadfast Sandbox/Live Config
```

### প্রধান স্ক্রিনসমূহের বিবরণ (Screen Details):
1. **Login & Security Screen:**
   - আধুনিক গ্রাফিক্যাল ব্যানার, ইউজার আইডি ও পাসওয়ার্ড ইনপুট।
   - অ্যাক্টিভ/ইনঅ্যাক্টিভ ইউজার গার্ড (ইনঅ্যাক্টিভ ইউজারকে অ্যাপ স্বয়ংক্রিয়ভাবে ব্লক করবে)।
   - ডেমো অ্যাডমিন ও সেলস ইউজার দিয়ে ১-ক্লিকে টেস্ট লগইন করার বোতাম (ফার্স্ট টাইম ইউজারদের সুবিধার জন্য)।
2. **Admin Dashboard (অ্যাডমিন ড্যাশবোর্ড):**
   - ১২টি কি-স্ট্যাটাস কার্ড: মোট বিক্রি, মোট খরচ, নেট প্রফিট, মোট অর্ডার, ডেলিভার্ড অর্ডার, পেন্ডিং অর্ডার, ক্যানসেলড অর্ডার, রিটার্নড অর্ডার, মোট কাস্টমার, মোট ইউজার ইত্যাদি।
   - ফিল্টার: Today, Yesterday, Last 7 Days, This Month, Last Month, Custom Range।
   - ইন্টারেক্টিভ চার্ট: Sales Trend, Income vs Expense, Order Status ডোনাট চার্ট।
3. **User Dashboard (ইউজার ড্যাশবোর্ড):**
   - ইউজারের নিজস্ব মোট বিক্রি, অর্জিত প্রফিট, আজকের বিক্রি, টার্গেট প্রগ্রেস বার (যেমন: ৫০,০০০ টাকার মধ্যে ৩৫,০০০ অর্জিত - ৭০%), পারফরম্যান্স র‍্যাঙ্কিং।
4. **Order Management Screen:**
   - নতুন অর্ডার তৈরি (প্রোডাক্ট, প্রাইস, ডেলিভারি চার্জ, কাস্টমার নাম, ফোন, অ্যাড্রেস, সিওডি অ্যামাউন্ট)।
   - স্ট্যাটাস ট্র্যাকিং পাইপলাইন: New ➔ Confirmed ➔ Processing ➔ Shipped ➔ In Transit ➔ Delivered / Cancelled / Returned।
   - ১-ক্লিকে Steadfast Courier এ পার্সেল পাঠানো।
5. **Income, Expense & Profit & Loss Screen:**
   - ক্যাটাগরিভিত্তিক আয় (প্রোডাক্ট সেলস, সিওডি কালেকশন) ও ব্যয় (পণ্য ক্রয়, বিজ্ঞাপন, কুরিয়ার চার্জ, প্যাকেজিং, বেতন)।
   - গোল্ডেন রুল অনুযায়ী স্বয়ংক্রিয় নেট লাভ ও ব্যালেন্স শিট।
6. **Steadfast Courier Management:**
   - স্যান্ডবক্স ও প্রোডাকশন মোড টগল বাটন।
   - মার্চেন্ট এপিআই কি ও সিক্রেট কি সুরক্ষিত ইনপুট ফিল্ড ও টেস্ট কানেকশন বোতাম।
   - পার্সেল ট্র্যাকিং ও ডেলিভারি স্ট্যাটাস সিঙ্ক।
7. **User Management & Permission Matrix:**
   - নতুন ইউজার তৈরি ও ইউনিক আইডি জেনারেট।
   - প্রতিটি ইউজারের জন্য ১৮টি আলাদা পারমিশন অন/অফ করার টগল সুইচ।
8. **Language & Settings Screen:**
   - বাংলা এবং ইংরেজি ভাষা সিলেকশন সুইচ।

---

## ৩. সম্পূর্ণ ডেটাবেস স্কিমা (Central PostgreSQL Database Schema)

সিস্টেমের জন্য সম্পূর্ণ নরমালাইজড ১৪টি টেবিল ডিজাইন করা হয়েছে।

```sql
-- 1. profiles: ইউজার প্রোফাইল ও ভূমিকা
CREATE TABLE profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id_code VARCHAR(50) UNIQUE NOT NULL, -- e.g., 'ADM-001', 'USR-102'
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    role VARCHAR(20) NOT NULL DEFAULT 'user', -- 'admin' OR 'user'
    is_active BOOLEAN NOT NULL DEFAULT true,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. permissions: ইউজারভিত্তিক ১৮টি স্পেসিফিক অধিকার
CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    can_view_dashboard BOOLEAN DEFAULT true,
    can_view_total_sales BOOLEAN DEFAULT false,
    can_view_total_cost BOOLEAN DEFAULT false,
    can_view_total_profit BOOLEAN DEFAULT false,
    can_view_orders BOOLEAN DEFAULT true,
    can_create_orders BOOLEAN DEFAULT true,
    can_edit_orders BOOLEAN DEFAULT false,
    can_delete_orders BOOLEAN DEFAULT false,
    can_view_customers BOOLEAN DEFAULT true,
    can_add_customers BOOLEAN DEFAULT true,
    can_view_income BOOLEAN DEFAULT false,
    can_add_income BOOLEAN DEFAULT false,
    can_view_expenses BOOLEAN DEFAULT false,
    can_add_expenses BOOLEAN DEFAULT false,
    can_view_courier BOOLEAN DEFAULT true,
    can_create_courier_orders BOOLEAN DEFAULT false,
    can_view_return_orders BOOLEAN DEFAULT true,
    can_view_reports BOOLEAN DEFAULT false,
    can_export_reports BOOLEAN DEFAULT false
);

-- 3. customers: কাস্টমার তালিকা ও রিপিট হিস্ট্রি
CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(50),
    notes TEXT,
    created_by UUID REFERENCES profiles(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. products: বিক্রয়যোগ্য পণ্যের তালিকা ও কেনা খরচ
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    purchase_cost NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    sale_price NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    stock_quantity INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. sales_targets: ইউজারভিত্তিক সেলস টার্গেট
CREATE TABLE sales_targets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    period_type VARCHAR(20) NOT NULL, -- 'daily', 'weekly', 'monthly', 'custom'
    target_amount NUMERIC(12, 2) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. orders: মূল অর্ডার টেবিল
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    customer_id UUID REFERENCES customers(id),
    customer_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_address TEXT NOT NULL,
    product_summary TEXT NOT NULL,
    product_price NUMERIC(12, 2) NOT NULL,
    product_cost NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    discount NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    delivery_charge NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    cod_amount NUMERIC(12, 2) NOT NULL, -- (product_price - discount + delivery_charge)
    created_by UUID REFERENCES profiles(id),
    assigned_to UUID REFERENCES profiles(id),
    status VARCHAR(30) NOT NULL DEFAULT 'New', -- 'New','Pending','Confirmed','Processing','Shipped','In Transit','Delivered','Cancelled','Return Requested','Returned'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. transactions: সম্পূর্ণ আর্থিক লেজার (আয় ও ব্যয়)
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_code VARCHAR(50) UNIQUE NOT NULL,
    type VARCHAR(20) NOT NULL, -- 'INCOME' OR 'EXPENSE'
    category VARCHAR(50) NOT NULL, -- 'Product Sales', 'Courier COD', 'Advertising', 'Courier Charge', 'Packaging', etc.
    amount NUMERIC(12, 2) NOT NULL,
    related_order_id UUID REFERENCES orders(id),
    description TEXT,
    created_by UUID REFERENCES profiles(id),
    transaction_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. courier_shipments: কুরিয়ার ট্র্যাকিং ও বুকিং
CREATE TABLE courier_shipments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    provider VARCHAR(50) NOT NULL DEFAULT 'Steadfast',
    consignment_id VARCHAR(100),
    tracking_code VARCHAR(100) UNIQUE,
    cod_amount NUMERIC(12, 2) NOT NULL,
    delivery_charge NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    courier_status VARCHAR(50) NOT NULL DEFAULT 'in_review',
    is_sandbox BOOLEAN NOT NULL DEFAULT true,
    last_synced_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. return_records: রিটার্ন ব্যবস্থাপনা
CREATE TABLE return_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES orders(id),
    reason TEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Requested', -- 'Requested','Approved','Received','Cost Adjusted'
    cost_adjustment NUMERIC(12, 2) DEFAULT 0.00,
    delivery_charge_loss NUMERIC(12, 2) DEFAULT 0.00,
    approved_by UUID REFERENCES profiles(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 10. app_settings: কুরিয়ার কি ও সিস্টেম কনফিগ
CREATE TABLE app_settings (
    key VARCHAR(50) PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

---

## ৪. প্রমাণীকরণ ও পারমিশন লজিক (Authentication & Permission Logic)

### সহজ ভাষায় ব্যাখ্যা (How Security Works for Beginners):
1. **অ্যাডমিন ক্রিয়েশন:** সিস্টেমে একটি ডিফল্ট সুরক্ষিত অ্যাডমিন অ্যাকাউন্ট থাকবে (`ADM-001`)। কোনো সাধারণ ইউজার নিজে নিজে রেজিস্ট্রেশন করতে পারবে না; শুধুমাত্র অ্যাডমিন নতুন সেলস ইউজার তৈরি করতে পারবেন।
2. **ইনঅ্যাক্টিভ ইউজার গার্ড:** কোনো কর্মীকে কোম্পানি থেকে অব্যাহতি দেওয়া হলে অ্যাডমিন তার স্ট্যাটাস এক ক্লিকে "Inactive" করে দিতে পারবেন। এরপর সেই ইউজার সঠিক পাসওয়ার্ড দিলেও অ্যাপে ঢুকতে পারবে না।
3. **দ্বিমুখী নিরাপত্তা (Double Gate):**
   - **UI Gate:** সাধারণ ইউজারকে প্রফিট বা অন্যের অর্ডার দেখার পারমিশন না থাকলে সংশ্লিষ্ট বোতাম বা কার্ডটি স্ক্রিনে প্রদর্শিত হবে না।
   - **Database Gate (Row Level Security):** ইউজার যদি এপিআই কল করেও অন্য ইউজারের ডেটা দেখতে চায়, সার্ভার সরাসরি `Access Denied` রিটার্ন করবে। সাধারণ ইউজার শুধুমাত্র `WHERE created_by = current_user_id` ডেটা দেখতে পাবে।

---

## ৫. নিখুঁত আর্থিক হিসাবের নীতিমালা (Financial Calculation Golden Rules)

অ্যাকাউন্টিংয়ের সঠিক নিয়ম অনুযায়ী ব্যবসার লাভ-ক্ষতি যেভাবে হিসাব হবে:

1. **মোট বিক্রয় (Gross Sales):**
   - শুধুমাত্র `Delivered` স্ট্যাটাসপ্রাপ্ত অর্ডারগুলোকেই অর্জিত বিক্রয় হিসেবে গণ্য করা হবে।
   - `Pending`, `Shipped`, `Cancelled` কিংবা `Returned` অর্ডারকে মোট বিক্রি হিসেবে ধরা হবে না।
2. **নেট প্রফিট সূত্র (Net Profit Formula):**
   $$\text{Net Profit} = \text{Recognized Revenue} - \text{Total Expenses}$$
   - যেখানে $\text{Recognized Revenue} = \text{ডেলিভার্ড পণ্যের বিক্রয়মূল্য}$
   - এবং $\text{Total Expenses} = \text{পণ্য কেনার আসল খরচ (COGS)} + \text{বিজ্ঞাপন খরচ} + \text{কুরিয়ার ডেলিভারি চার্জ} + \text{প্যাকেজিং খরচ} + \text{অন্যান্য খরচ}$
3. **কুরিয়ার সিওডি (COD) ডাবল কাউন্টিং প্রতিরোধ:**
   - যখন কুরিয়ার কোম্পানি সিওডি টাকা ব্যাংক একাউন্টে পাঠাবে, তখন সেটি ক্যাশ রিসিভ হিসেবে গণ্য হবে, কোনো নতুন 'বিক্রি' নয়। ফলে বিক্রির হিসাব দুইবার বাড়বে না।
4. **রিটার্নড অর্ডারের হিসাব:**
   - পণ্য রিটার্ন আসলে পণ্য বিক্রির আয় বাতিল হবে, পণ্য আবার স্টকে যুক্ত হবে। তবে কুরিয়ারকে যে ডেলিভারি/রিটার্ন চার্জ দিতে হয়েছে, তা 'Expense' হিসেবে লস অ্যাকাউন্টে যুক্ত হবে।

---

## ৬. Steadfast কুরিয়ার ইন্টিগ্রেশন কৌশল (Steadfast Courier Strategy)

1. **স্যান্ডবক্স ও প্রোডাকশন আর্কিটেকচার:**
   - অ্যাপ প্রথমে সম্পূর্ণ সুরক্ষিত **Sandbox Mode** এ চলবে। এতে ব্যবহারকারী টেস্ট অর্ডার বুকিং, ফেক কনসাইনমেন্ট আইডি (`SF-TEST-84920`) এবং ট্র্যাকিং দেখতে পারবেন।
   - অ্যাডমিন সেটিংস পেজে গেলে **Steadfast Configuration** দেখতে পাবেন:
     - API Key ইনপুট ফিল্ড
     - Secret Key ইনপুট ফিল্ড
     - "Test Connection" বোতাম (যা Steadfast সার্ভারে পিং করে নিশ্চিত করবে ক্রেডেনশিয়াল সঠিক কি না)
     - "Switch to Production" কনফার্মেশন ডায়ালগ।
2. **নিরাপত্তা নিশ্চিতকরণ:**
   - সিক্রেট কি কখনোই ফ্রন্টএন্ড কোডে হার্ডকোড থাকবে না; এটি ডেটাবেস এনক্রিপ্টেড সেটিংসে সংরক্ষিত থাকবে।
   - কোনো ডেমো বা স্যান্ডবক্স অর্ডার অসাবধানতাবশত রিয়েল কুরিয়ার সিস্টেমে যাবে না।

---

## ৭. ধাপে ধাপে বাস্তবায়ন পরিকল্পনা (Implementation Stages)

- [ ] **Stage 1: Core Foundation & Branding**
  - আপলোডকৃত অ্যারো লোগো দিয়ে আধুনিক অ্যাপ আইকন এবং কালার প্যালেট সেটআপ (Navy Blue `#0A192F`, Vibrant Blue `#1E88E5`, Emerald Green `#10B981`, Coral Red `#EF4444`).
  - বাংলা ও ইংরেজি দ্বিভাষিক (Bilingual) স্ট্রিং রিসোর্স তৈরি।
  - Clean Architecture ডাটাবেস ও রিপোজিটরি সেটআপ (Local Room DB + Cloud Models).

- [ ] **Stage 2: Authentication & Security Engine**
  - প্রিমিয়াম লগইন স্ক্রিন (Admin/User রোল ও স্ট্যাটাস চেকার).
  - ইউজার ম্যানেজমেন্ট ও ১৮টি ফিল্ডযুক্ত পারমিশন কন্ট্রোল সিস্টেম।
  - ডেমো অ্যাডমিন ও সেলস পার্সন দ্রুত পরীক্ষার জন্য বোতাম।

- [ ] **Stage 3: Dashboards & Interactive Analytics**
  - ১২টি ম্যাট্রিক্সযুক্ত অ্যাডমিন ড্যাশবোর্ড ও ফিল্টার (আজ, গতকাল, চলতি মাস ইত্যাদি)।
  - সুন্দর Compose ক্যানভাস চার্ট (Sales, Expenses, Order Status ডোনাট চার্ট)।
  - ইউজারের ব্যক্তিগত ড্যাশবোর্ড ও সেলস টার্গেট প্রগ্রেস বার।

- [ ] **Stage 4: Order & Customer Management**
  - পূর্ণাঙ্গ অর্ডার তৈরি ফর্ম (অটোমেটিক সিওডি ক্যালকুলেশন, ডিসকাউন্ট, ডেলিভারি চার্জ)।
  - অর্ডার স্ট্যাটাস ট্র্যাকিং লাইফসাইকেল (New ➔ In Transit ➔ Delivered/Returned).
  - কাস্টমার ডিরেক্টরি এবং অর্ডার হিস্ট্রি।

- [ ] **Stage 5: Finance & Profit/Loss Calculation Ledger**
  - আয় ও ব্যয় এন্ট্রি ফর্ম ও ক্যাটাগরি সিস্টেম।
  - নিখুঁত নেট প্রফিট ফর্মুলা ইঞ্জিন এবং রিটার্ন এডজাস্টমেন্ট।

- [ ] **Stage 6: Steadfast Courier Gateway & Sandbox Hub**
  - স্যান্ডবক্স সিমুলেটর ও লাইভ এপিআই কনফিগারেশন প্যানেল।
  - কনসাইনমেন্ট আইডি ট্র্যাকিং ও স্ট্যাটাস সিঙ্ক।

- [ ] **Stage 7: Reports, Return Center & Verification**
  - সেলস ও প্রফিট রিপোর্ট জেনারেশন।
  - রিটার্ন রিকোয়েস্ট ও এডজাস্টমেন্ট অনুমোদন স্ক্রিন।
  - কম্পাইলেশন ও কোড ভেরিফিকেশন।
