package com.example.auth

import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory

private const val TAG = "AppCheckInitDebug"

private const val DEBUG_TOKEN_EXTRA = "FIREBASE_APPCHECK_DEBUG_TOKEN"
private const val DEBUG_STORE_PREFIX = "com.google.firebase.appcheck.debug.store."
private const val DEBUG_SECRET_KEY = "com.google.firebase.appcheck.debug.DEBUG_SECRET"

fun configureAppCheck(context: Context, intent: Intent?) {
    try {
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }

        val debugToken = intent?.getStringExtra(DEBUG_TOKEN_EXTRA)
        if (!debugToken.isNullOrEmpty()) {
            val persistenceKey = FirebaseApp.getInstance().persistenceKey
            val prefs = context.getSharedPreferences(
                "$DEBUG_STORE_PREFIX$persistenceKey",
                Context.MODE_PRIVATE
            )
            // Must use synchronous commit() before installing DebugAppCheckProviderFactory
            prefs.edit()
                .putString(DEBUG_SECRET_KEY, debugToken)
                .commit()
            Log.d(TAG, "App Check debug secret configured from launch intent.")
        } else {
            Log.d(TAG, "Installing DebugAppCheckProviderFactory for debug build.")
        }

        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
            DebugAppCheckProviderFactory.getInstance()
        )
    } catch (e: Exception) {
        Log.e(TAG, "Failed to initialize debug Firebase App Check", e)
    }
}

fun configureAppCheckForSecondaryApp(
    context: Context,
    primaryApp: FirebaseApp,
    secondaryApp: FirebaseApp
) {
    try {
        val primaryPrefs = context.getSharedPreferences(
            "$DEBUG_STORE_PREFIX${primaryApp.persistenceKey}",
            Context.MODE_PRIVATE
        )
        val existingSecret = primaryPrefs.getString(DEBUG_SECRET_KEY, null)
        if (!existingSecret.isNullOrEmpty()) {
            val secondaryPrefs = context.getSharedPreferences(
                "$DEBUG_STORE_PREFIX${secondaryApp.persistenceKey}",
                Context.MODE_PRIVATE
            )
            secondaryPrefs.edit()
                .putString(DEBUG_SECRET_KEY, existingSecret)
                .commit()
        }
        FirebaseAppCheck.getInstance(secondaryApp).installAppCheckProviderFactory(
            DebugAppCheckProviderFactory.getInstance()
        )
    } catch (e: Exception) {
        Log.w(TAG, "Secondary app debug App Check setup skipped: ${e.message}")
    }
}
