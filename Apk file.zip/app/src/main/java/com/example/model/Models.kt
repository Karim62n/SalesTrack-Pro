package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

enum class UserRole(val displayName: String) {
    PRIMARY_SUPER_ADMIN("Primary Super Admin (Owner)"),
    SECONDARY_SUPER_ADMIN("Secondary Super Admin"),
    USER("Sales User");

    val isAdmin: Boolean
        get() = this == PRIMARY_SUPER_ADMIN || this == SECONDARY_SUPER_ADMIN
}

enum class AccountStatus(val labelBn: String, val labelEn: String) {
    ACTIVE("সক্রিয় (Active)", "Active"),
    DEACTIVATED("নিষ্ক্রিয় (Deactivated)", "Deactivated"),
    SUSPENDED("সাসপেন্ডেড (Suspended)", "Suspended")
}

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val userIdCode: String = "", // e.g. "ADM-001", "ADM-002", "USR-101"
    val email: String = "",
    val fullName: String = "",
    val phone: String = "",
    val role: UserRole = UserRole.USER,
    val status: AccountStatus = AccountStatus.ACTIVE,
    @get:PropertyName("isActive") @set:PropertyName("isActive") var isActive: Boolean = true,
    val mustChangePasswordOnFirstLogin: Boolean = false,
    val monthlySalesTarget: Double = 50000.0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class ResetRequestStatus(val labelBn: String) {
    PENDING("পেন্ডিং (অনুমোদনের অপেক্ষায়)"),
    APPROVED("অনুমোদিত (অস্থায়ী পাসওয়ার্ড তৈরি)"),
    REJECTED("প্রত্যাখ্যাত"),
    USED("ব্যবহৃত ও পাসওয়ার্ড পরিবর্তিত")
}

@IgnoreExtraProperties
data class PasswordResetRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userIdCode: String = "",
    val userFullName: String = "",
    val email: String = "",
    val mobileNumber: String = "",
    val reason: String? = null,
    val status: ResetRequestStatus = ResetRequestStatus.PENDING,
    val approvedBy: String? = null,
    val approvedByName: String? = null,
    val rejectionReason: String? = null,
    val requestTimeMillis: Long = System.currentTimeMillis(),
    val resolvedTimeMillis: Long? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AuditLog(
    @DocumentId val id: String = "",
    val action: String = "",
    val performedBy: String = "",
    val performedByName: String = "",
    val targetUserId: String? = null,
    val details: String = "",
    val timestampMillis: Long = System.currentTimeMillis(),
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserPermissions(
    @DocumentId val id: String = "",
    val userId: String = "",
    val canViewDashboard: Boolean = true,
    val canViewTotalSales: Boolean = true,
    val canViewTotalCost: Boolean = false,
    val canViewTotalProfit: Boolean = false,
    val canViewOrders: Boolean = true,
    val canCreateOrders: Boolean = true,
    val canEditOrders: Boolean = false,
    val canDeleteOrders: Boolean = false,
    val canViewCustomers: Boolean = true,
    val canAddCustomers: Boolean = true,
    val canViewIncome: Boolean = false,
    val canAddIncome: Boolean = false,
    val canViewExpenses: Boolean = false,
    val canAddExpenses: Boolean = false,
    val canViewCourier: Boolean = true,
    val canCreateCourierOrders: Boolean = false,
    val canViewReturnOrders: Boolean = true,
    val canViewReports: Boolean = false,
    val canExportReports: Boolean = false,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    companion object {
        fun adminPermissions(userId: String) = UserPermissions(
            id = userId,
            userId = userId,
            canViewDashboard = true,
            canViewTotalSales = true,
            canViewTotalCost = true,
            canViewTotalProfit = true,
            canViewOrders = true,
            canCreateOrders = true,
            canEditOrders = true,
            canDeleteOrders = true,
            canViewCustomers = true,
            canAddCustomers = true,
            canViewIncome = true,
            canAddIncome = true,
            canViewExpenses = true,
            canAddExpenses = true,
            canViewCourier = true,
            canCreateCourierOrders = true,
            canViewReturnOrders = true,
            canViewReports = true,
            canExportReports = true
        )

        fun defaultUserPermissions(userId: String) = UserPermissions(
            id = userId,
            userId = userId,
            canViewDashboard = true,
            canViewTotalSales = true,
            canViewTotalCost = false,
            canViewTotalProfit = false,
            canViewOrders = true,
            canCreateOrders = true,
            canEditOrders = false,
            canDeleteOrders = false,
            canViewCustomers = true,
            canAddCustomers = true,
            canViewIncome = false,
            canAddIncome = false,
            canViewExpenses = false,
            canAddExpenses = false,
            canViewCourier = true,
            canCreateCourierOrders = false,
            canViewReturnOrders = true,
            canViewReports = false,
            canExportReports = false
        )
    }
}

@IgnoreExtraProperties
data class Customer(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val phone: String = "",
    val address: String = "",
    val city: String = "Dhaka",
    val notes: String = "",
    val totalOrders: Int = 0,
    val deliveredOrders: Int = 0,
    val returnedOrders: Int = 0,
    val createdBy: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Product(
    @DocumentId val id: String = "",
    val sku: String = "",
    val name: String = "",
    val purchaseCost: Double = 0.0,
    val salePrice: Double = 0.0,
    val stockQuantity: Int = 100,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class TargetPeriod {
    DAILY, WEEKLY, MONTHLY, CUSTOM
}

@IgnoreExtraProperties
data class SalesTarget(
    @DocumentId val id: String = "",
    val userId: String = "",
    val period: TargetPeriod = TargetPeriod.MONTHLY,
    val targetAmount: Double = 50000.0,
    val startDate: Long = 0L,
    val endDate: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class OrderStatus(val displayName: String) {
    NEW("New"),
    PENDING("Pending"),
    CONFIRMED("Confirmed"),
    PROCESSING("Processing"),
    SHIPPED("Shipped"),
    IN_TRANSIT("In Transit"),
    DELIVERED("Delivered"),
    CANCELLED("Cancelled"),
    RETURN_REQUESTED("Return Requested"),
    RETURNED("Returned")
}

@IgnoreExtraProperties
data class Order(
    @DocumentId val id: String = "",
    val userId: String = "",
    val invoiceNumber: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val customerAddress: String = "",
    val productSummary: String = "",
    val productPrice: Double = 0.0,
    val productCost: Double = 0.0,
    val discount: Double = 0.0,
    val deliveryCharge: Double = 0.0,
    val codAmount: Double = 0.0,
    val createdBy: String = "",
    val createdByName: String = "",
    val assignedTo: String = "",
    val status: OrderStatus = OrderStatus.NEW,
    val consignmentId: String? = null,
    val trackingCode: String? = null,
    val orderDateMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class TransactionType {
    INCOME, EXPENSE
}

@IgnoreExtraProperties
data class Transaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val transactionCode: String = "",
    val type: TransactionType = TransactionType.INCOME,
    val category: String = "",
    val amount: Double = 0.0,
    val relatedOrderId: String? = null,
    val description: String = "",
    val createdBy: String = "",
    val dateMillis: Long = System.currentTimeMillis(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SteadfastShipment(
    @DocumentId val id: String = "",
    val userId: String = "",
    val orderId: String = "",
    val invoiceNumber: String = "",
    val consignmentId: String = "",
    val trackingCode: String = "",
    val codAmount: Double = 0.0,
    val deliveryCharge: Double = 0.0,
    val status: String = "in_review",
    @get:PropertyName("isSandbox") @set:PropertyName("isSandbox") var isSandbox: Boolean = true,
    val lastSyncedMillis: Long = System.currentTimeMillis(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SteadfastConfig(
    val apiKey: String = "",
    val secretKey: String = "",
    @get:PropertyName("isSandbox") @set:PropertyName("isSandbox") var isSandbox: Boolean = true,
    @get:PropertyName("isConnected") @set:PropertyName("isConnected") var isConnected: Boolean = true,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ReturnRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val orderId: String = "",
    val invoiceNumber: String = "",
    val customerName: String = "",
    val reason: String = "",
    val status: String = "Requested",
    val costAdjustment: Double = 0.0,
    val deliveryChargeLoss: Double = 0.0,
    val approvedBy: String = "",
    val dateMillis: Long = System.currentTimeMillis(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class DashboardMetrics(
    val totalCost: Double = 0.0,
    val totalProfit: Double = 0.0,
    val totalOrders: Int = 0,
    val totalUsers: Int = 0,
    val totalCustomers: Int = 0,
    val totalSales: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val pendingOrders: Int = 0,
    val deliveredOrders: Int = 0,
    val cancelledOrders: Int = 0,
    val returnedOrders: Int = 0,
    val recognizedRevenue: Double = 0.0,
    val cogsAmount: Double = 0.0,
    val adCostAmount: Double = 0.0,
    val courierExpense: Double = 0.0,
    val packagingExpense: Double = 0.0
)

data class UserTargetProgress(
    val user: UserProfile,
    val targetAmount: Double,
    val achievedSales: Double,
    val remainingTarget: Double,
    val achievementPercentage: Double,
    val rank: Int = 1
)

@IgnoreExtraProperties
data class PackagingTrackingInfo(
    val totalExpense: Double = 0.0,
    val totalPiecesUsed: Int = 0,
    val stockRemainingPieces: Int = 0,
    val perPieceCost: Double = 0.0
)

@IgnoreExtraProperties
data class AdSpendInfo(
    val totalDollarsSpent: Double = 0.0,
    val dailyBudgetDollars: Double = 0.0,
    val activeAdsCount: Int = 0,
    val weeklyBudgetDollars: Double = 0.0,
    val monthlyBudgetDollars: Double = 0.0,
    val dollarRateBdt: Double = 122.0
)

@IgnoreExtraProperties
data class BoxTrackingInfo(
    val totalExpense: Double = 0.0,
    val totalBoxesStock: Int = 0,
    val totalBoxesUsed: Int = 0,
    val perPieceCost: Double = 0.0
)

@IgnoreExtraProperties
data class StickerTrackingInfo(
    val totalExpense: Double = 0.0,
    val totalStickersStock: Int = 0,
    val totalStickersUsed: Int = 0,
    val perPieceCost: Double = 0.0
)

data class CloudSyncConfig(
    val projectId: String = "gen-lang-client-0493994891",
    val databaseId: String = "",
    val serverUrl: String = "https://console.firebase.google.com/project/gen-lang-client-0493994891/firestore",
    val isCloudConnected: Boolean = false,
    val syncStrategy: String = "Firebase Cloud Firestore Multi-Device Realtime",
    val lastSyncTime: Long = System.currentTimeMillis(),
    val activeDevicesOnline: Int = 1
)
