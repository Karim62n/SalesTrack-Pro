package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BusinessRepository
import com.example.localization.AppLanguage
import com.example.localization.AppStrings
import com.example.localization.Strings
import com.example.model.*
import com.example.util.ConnectionType
import com.example.util.NetworkMonitor
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.UUID

enum class DateFilterType {
    TODAY, YESTERDAY, LAST_7_DAYS, THIS_MONTH, LAST_MONTH, ALL
}

class MainViewModel(
    private val repository: BusinessRepository,
    private val networkMonitor: NetworkMonitor? = null
) : ViewModel() {

    val connectionType: StateFlow<ConnectionType> =
        networkMonitor?.connectionType ?: MutableStateFlow(ConnectionType.WIFI).asStateFlow()

    val cloudSyncConfig: StateFlow<CloudSyncConfig> = repository.cloudSyncConfig
    val authInitializing: StateFlow<Boolean> = repository.authInitializing
    val authError: StateFlow<String?> = repository.authError
    val currentUser = repository.currentUser
    val userPermissions = repository.userPermissions
    val currentLanguage = repository.currentLanguage

    val strings: StateFlow<Strings> = repository.currentLanguage.map {
        AppStrings.get(it)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, AppStrings.get(AppLanguage.BANGLA))

    val users = repository.users
    val allPermissions = repository.allPermissions
    val customers = repository.customers
    val products = repository.products
    val orders = repository.orders
    val transactions = repository.transactions
    val shipments = repository.shipments
    val returns = repository.returns
    val salesTargets = repository.salesTargets
    val steadfastConfig = repository.steadfastConfig
    val packagingInfo = repository.packagingInfo
    val adSpendInfo = repository.adSpendInfo
    val boxInfo = repository.boxInfo
    val stickerInfo = repository.stickerInfo
    val passwordResetRequests = repository.passwordResetRequests
    val auditLogs = repository.auditLogs

    // UI States
    private val _currentDateFilter = MutableStateFlow(DateFilterType.THIS_MONTH)
    val currentDateFilter: StateFlow<DateFilterType> = _currentDateFilter.asStateFlow()

    private val _orderSearchQuery = MutableStateFlow("")
    val orderSearchQuery: StateFlow<String> = _orderSearchQuery.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow<OrderStatus?>(null)
    val selectedStatusFilter: StateFlow<OrderStatus?> = _selectedStatusFilter.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private val _isCourierLoading = MutableStateFlow(false)
    val isCourierLoading: StateFlow<Boolean> = _isCourierLoading.asStateFlow()

    // Calculated Metrics
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        orders, transactions, users, customers, _currentDateFilter
    ) { _, _, _, _, filter ->
        val range = getDateRangeForFilter(filter)
        repository.calculateMetrics(range.first, range.second)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    val userTargetProgress: StateFlow<UserTargetProgress?> = combine(
        currentUser, orders, salesTargets
    ) { user, _, _ ->
        val uid = user?.uid?.ifBlank { user.id }
        if (uid != null) repository.getUserTargetProgress(uid) else null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val userMetrics: StateFlow<DashboardMetrics> = combine(
        currentUser, orders, transactions
    ) { user, _, _ ->
        val uid = user?.uid?.ifBlank { user.id }
        if (uid != null) repository.getUserMetrics(uid) else DashboardMetrics()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    // Filtered Orders
    val filteredOrders: StateFlow<List<Order>> = combine(
        orders, _orderSearchQuery, _selectedStatusFilter, currentUser
    ) { orderList, query, status, user ->
        var list = orderList
        if (user != null && user.role == UserRole.USER) {
            val uid = user.uid.ifBlank { user.id }
            list = list.filter { it.userId == uid || it.createdBy == uid }
        }
        if (query.isNotBlank()) {
            list = list.filter {
                it.invoiceNumber.contains(query, ignoreCase = true) ||
                    it.customerName.contains(query, ignoreCase = true) ||
                    it.customerPhone.contains(query, ignoreCase = true) ||
                    it.productSummary.contains(query, ignoreCase = true)
            }
        }
        if (status != null) {
            list = list.filter { it.status == status }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    override fun onCleared() {
        super.onCleared()
        repository.cleanup()
    }

    // --- Authentication ---

    fun login(userIdOrEmail: String, password: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = repository.login(userIdOrEmail, password)
            result.onSuccess {
                onResult(true, null)
            }.onFailure {
                onResult(false, it.message)
            }
        }
    }

    fun loginWithGoogle(activityContext: Context, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = repository.loginWithGoogle(activityContext)
            result.onSuccess {
                onResult(true, null)
            }.onFailure {
                onResult(false, it.message)
            }
        }
    }

    fun requestPasswordReset(
        identifier: String,
        mobileNumber: String,
        reason: String = "পাসওয়ার্ড ভুলে গেছি",
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.requestPasswordReset(identifier, mobileNumber, reason)
            res.onSuccess {
                onResult(true, "✓ পাসওয়ার্ড রিসেট রিকোয়েস্ট পাঠানো হয়েছে! সুপার অ্যাডমিন অনুমোদন করলে অস্থায়ী পাসওয়ার্ড পাবেন।")
            }.onFailure {
                onResult(false, it.message ?: "রিকোয়েস্ট পাঠানো যায়নি")
            }
        }
    }

    fun logout(context: Context? = null) {
        viewModelScope.launch {
            repository.logout(context)
        }
    }

    fun clearAuthError() {
        repository.clearAuthError()
    }

    fun toggleLanguage() {
        val next = if (currentLanguage.value == AppLanguage.BANGLA) AppLanguage.ENGLISH else AppLanguage.BANGLA
        repository.switchLanguage(next)
    }

    fun setDateFilter(filter: DateFilterType) {
        _currentDateFilter.value = filter
    }

    fun setOrderSearch(query: String) {
        _orderSearchQuery.value = query
    }

    fun setOrderStatusFilter(status: OrderStatus?) {
        _selectedStatusFilter.value = status
    }

    // --- Orders ---

    fun createOrder(
        customerName: String,
        customerPhone: String,
        customerAddress: String,
        product: Product,
        quantity: Int,
        discount: Double,
        deliveryCharge: Double
    ) {
        val user = currentUser.value ?: return
        val uid = user.uid.ifBlank { user.id }
        viewModelScope.launch {
            val inv = "INV-2026-${(100 + orders.value.size + 1)}"
            val totalPrice = product.salePrice * quantity
            val totalCost = product.purchaseCost * quantity
            val cod = (totalPrice - discount + deliveryCharge).coerceAtLeast(0.0)

            var cust = customers.value.find { it.phone == customerPhone.trim() }
            if (cust == null) {
                val newCust = Customer(
                    id = "cust_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                    userId = uid,
                    name = customerName,
                    phone = customerPhone,
                    address = customerAddress,
                    createdBy = uid
                )
                repository.addCustomer(newCust).onSuccess { created ->
                    cust = created
                }
            }

            val order = Order(
                id = "ord_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                userId = uid,
                invoiceNumber = inv,
                customerId = cust?.id ?: "cust_unknown",
                customerName = customerName,
                customerPhone = customerPhone,
                customerAddress = customerAddress,
                productSummary = "${product.name} (${quantity}x)",
                productPrice = totalPrice,
                productCost = totalCost,
                discount = discount,
                deliveryCharge = deliveryCharge,
                codAmount = cod,
                createdBy = uid,
                createdByName = user.fullName,
                status = OrderStatus.NEW,
                orderDateMillis = System.currentTimeMillis()
            )

            repository.createOrder(order).onSuccess {
                _actionMessage.value = "Order $inv created & synced!"
            }.onFailure {
                _actionMessage.value = it.message ?: "অর্ডার তৈরি ব্যর্থ হয়েছে"
            }
        }
    }

    fun createCustomOrder(
        customerName: String,
        customerPhone: String,
        customerDistrict: String,
        customerAddress: String,
        productName: String,
        quantity: Int,
        productAmount: Double,
        productCostPerUnit: Double = 0.0,
        discount: Double = 0.0,
        deliveryCharge: Double = 0.0,
        sendToCourierImmediately: Boolean = false,
        onComplete: ((Boolean, String?) -> Unit)? = null
    ) {
        val user = currentUser.value ?: return
        val uid = user.uid.ifBlank { user.id }
        viewModelScope.launch {
            val cleanName = customerName.trim()
            val cleanPhone = customerPhone.trim()
            val cleanDistrict = customerDistrict.trim()
            val cleanAddr = customerAddress.trim()
            val fullAddress = if (cleanDistrict.isNotBlank() && !cleanAddr.contains(cleanDistrict, ignoreCase = true)) {
                "$cleanAddr, জেলা: $cleanDistrict"
            } else {
                cleanAddr
            }

            var seq = 100 + orders.value.size + 1
            while (orders.value.any { it.invoiceNumber == "INV-2026-$seq" }) {
                seq++
            }
            val inv = "INV-2026-$seq"

            val safeQty = quantity.coerceAtLeast(1)
            val totalCost = (productCostPerUnit * safeQty).coerceAtLeast(0.0)
            val cod = (productAmount - discount + deliveryCharge).coerceAtLeast(0.0)

            var cust = customers.value.find { it.phone == cleanPhone }
            if (cust == null) {
                val newCust = Customer(
                    id = "cust_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                    userId = uid,
                    name = cleanName,
                    phone = cleanPhone,
                    address = cleanAddr,
                    city = cleanDistrict.ifBlank { "Dhaka" },
                    createdBy = uid
                )
                repository.addCustomer(newCust).onSuccess { created ->
                    cust = created
                }
            }

            val orderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val order = Order(
                id = orderId,
                userId = uid,
                invoiceNumber = inv,
                customerId = cust?.id ?: "cust_unknown",
                customerName = cleanName,
                customerPhone = cleanPhone,
                customerAddress = fullAddress,
                productSummary = "${productName.trim().ifBlank { "অর্ডার আইটেম" }} (${safeQty}x)",
                productPrice = productAmount,
                productCost = totalCost,
                discount = discount,
                deliveryCharge = deliveryCharge,
                codAmount = cod,
                createdBy = uid,
                createdByName = user.fullName,
                status = OrderStatus.NEW,
                orderDateMillis = System.currentTimeMillis()
            )

            val createRes = repository.createOrder(order)
            if (createRes.isFailure) {
                val err = createRes.exceptionOrNull()?.message ?: "অর্ডার তৈরি ব্যর্থ হয়েছে"
                _actionMessage.value = err
                onComplete?.invoke(false, err)
                return@launch
            }

            if (sendToCourierImmediately) {
                _isCourierLoading.value = true
                val courierRes = repository.sendOrderToSteadfast(orderId)
                _isCourierLoading.value = false
                courierRes.onSuccess { ship ->
                    val msg = "অর্ডার $inv তৈরি হয়েছে এবং Steadfast কুরিয়ারে পাঠানো হয়েছে! (Consignment: ${ship.consignmentId})"
                    _actionMessage.value = msg
                    onComplete?.invoke(true, msg)
                }.onFailure { err ->
                    val msg = "অর্ডার $inv তৈরি হয়েছে, তবে কুরিয়ারে পাঠানো যায়নি: ${err.message}"
                    _actionMessage.value = msg
                    onComplete?.invoke(true, msg)
                }
            } else {
                val msg = "অর্ডার $inv সফলভাবে তৈরি হয়েছে!"
                _actionMessage.value = msg
                onComplete?.invoke(true, msg)
            }
        }
    }

    fun updateOrder(order: Order) {
        viewModelScope.launch {
            repository.updateOrder(order).onSuccess {
                _actionMessage.value = "অর্ডার ${order.invoiceNumber} আপডেট করা হয়েছে!"
            }.onFailure {
                _actionMessage.value = it.message ?: "অর্ডার আপডেট ব্যর্থ হয়েছে"
            }
        }
    }

    fun deleteOrder(orderId: String) {
        viewModelScope.launch {
            repository.deleteOrder(orderId).onSuccess {
                _actionMessage.value = "অর্ডার সফলভাবে মুছে ফেলা হয়েছে!"
            }.onFailure {
                _actionMessage.value = it.message ?: "অর্ডার ডিলিট ব্যর্থ হয়েছে"
            }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus).onSuccess {
                _actionMessage.value = "Order status updated to ${newStatus.displayName}"
            }.onFailure {
                _actionMessage.value = it.message ?: "স্ট্যাটাস আপডেট ব্যর্থ"
            }
        }
    }

    fun sendToSteadfast(orderId: String) {
        viewModelScope.launch {
            _isCourierLoading.value = true
            val result = repository.sendOrderToSteadfast(orderId)
            _isCourierLoading.value = false
            result.onSuccess {
                _actionMessage.value = "Parcel booked with Steadfast! Consignment: ${it.consignmentId}"
            }.onFailure {
                _actionMessage.value = "Courier booking failed: ${it.message}"
            }
        }
    }

    // --- Transactions ---

    fun addTransaction(type: TransactionType, category: String, amount: Double, desc: String) {
        val user = currentUser.value ?: return
        val uid = user.uid.ifBlank { user.id }
        viewModelScope.launch {
            val txn = Transaction(
                id = "txn_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                userId = uid,
                transactionCode = "TXN-${(100 + transactions.value.size + 1)}",
                type = type,
                category = category,
                amount = amount,
                description = desc,
                createdBy = uid
            )
            repository.addTransaction(txn).onSuccess {
                _actionMessage.value = "$category recorded: ৳$amount"
            }.onFailure {
                _actionMessage.value = it.message ?: "লেনদেন সংরক্ষণ ব্যর্থ"
            }
        }
    }

    fun deleteTransaction(transactionId: String) {
        viewModelScope.launch {
            repository.deleteTransaction(transactionId).onSuccess {
                _actionMessage.value = "লেনদেন মুছে ফেলা হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "লেনদেন ডিলিট ব্যর্থ"
            }
        }
    }

    // --- User & Admin Management ---

    fun createUser(
        name: String,
        phone: String,
        role: UserRole,
        pass: String,
        customUserIdCode: String? = null,
        monthlyTarget: Double = 50000.0,
        email: String = "",
        onResult: ((Boolean, String?, UserProfile?) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val res = repository.createUser(
                fullName = name,
                phone = phone,
                email = email,
                role = role,
                initialPass = pass,
                customUserIdCode = customUserIdCode,
                monthlyTarget = monthlyTarget
            )
            res.onSuccess { created ->
                _actionMessage.value = "ইউজার ${created.userIdCode} সফলভাবে তৈরি হয়েছে!"
                onResult?.invoke(true, null, created)
            }.onFailure { err ->
                _actionMessage.value = err.message ?: "ইউজার তৈরি ব্যর্থ হয়েছে"
                onResult?.invoke(false, err.message, null)
            }
        }
    }

    fun setUserAccountStatus(userId: String, status: AccountStatus) {
        viewModelScope.launch {
            repository.setUserAccountStatus(userId, status).onSuccess {
                _actionMessage.value = "ইউজারের স্ট্যাটাস ${status.labelBn} করা হয়েছে।"
            }.onFailure {
                _actionMessage.value = it.message ?: "স্ট্যাটাস পরিবর্তন ব্যর্থ হয়েছে"
            }
        }
    }

    fun toggleUserActive(userId: String) {
        viewModelScope.launch {
            repository.toggleUserActive(userId).onSuccess {
                _actionMessage.value = "ইউজার অ্যাক্সেস স্ট্যাটাস আপডেট হয়েছে।"
            }.onFailure {
                _actionMessage.value = it.message ?: "স্ট্যাটাস আপডেট ব্যর্থ"
            }
        }
    }

    fun deleteUser(userId: String) {
        viewModelScope.launch {
            repository.deleteUser(userId).onSuccess {
                _actionMessage.value = "ইউজার সফলভাবে মুছে ফেলা হয়েছে।"
            }.onFailure {
                _actionMessage.value = it.message ?: "ইউজার মুছে ফেলা যায়নি"
            }
        }
    }

    fun changePassword(newPass: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = repository.changeUserPassword(newPass)
            res.onSuccess {
                _actionMessage.value = "পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!"
                onResult(true, "পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে")
            }.onFailure {
                onResult(false, it.message ?: "পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে")
            }
        }
    }

    fun updateUserName(newName: String) {
        val user = currentUser.value ?: return
        val uid = user.uid.ifBlank { user.id }
        viewModelScope.launch {
            repository.updateUserName(uid, newName).onSuccess {
                _actionMessage.value = "আপনার নাম সফলভাবে পরিবর্তিত হয়েছে!"
            }.onFailure {
                _actionMessage.value = it.message ?: "নাম পরিবর্তন ব্যর্থ"
            }
        }
    }

    fun savePermissions(perms: UserPermissions) {
        viewModelScope.launch {
            repository.savePermissions(perms).onSuccess {
                _actionMessage.value = "Permissions updated & synced!"
            }.onFailure {
                _actionMessage.value = it.message ?: "পারমিশন সেভ ব্যর্থ"
            }
        }
    }

    fun setSalesTarget(userId: String, period: TargetPeriod, amount: Double) {
        viewModelScope.launch {
            repository.setSalesTarget(userId, period, amount).onSuccess {
                _actionMessage.value = "Sales target updated: ৳$amount"
            }.onFailure {
                _actionMessage.value = it.message ?: "টার্গেট আপডেট ব্যর্থ"
            }
        }
    }

    // --- Courier & Trackers ---

    fun updateSteadfastConfig(apiKey: String, secretKey: String, isSandbox: Boolean) {
        viewModelScope.launch {
            repository.updateSteadfastConfig(apiKey, secretKey, isSandbox).onSuccess {
                _actionMessage.value = "Steadfast settings updated (${if (isSandbox) "Sandbox" else "Production"})"
            }.onFailure {
                _actionMessage.value = it.message ?: "কুরিয়ার কনফিগ ব্যর্থ"
            }
        }
    }

    fun testSteadfastConnection(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            _isCourierLoading.value = true
            val result = repository.testSteadfastConnection()
            _isCourierLoading.value = false
            result.onSuccess {
                onResult(true, it)
            }.onFailure {
                onResult(false, it.message ?: "Connection test failed")
            }
        }
    }

    fun syncAllCourierShipments(
        showToastOnSuccess: Boolean = true,
        onResult: ((Boolean, String) -> Unit)? = null
    ) {
        viewModelScope.launch {
            _isCourierLoading.value = true
            val result = repository.syncAllShipmentsStatus()
            _isCourierLoading.value = false
            result.onSuccess { msg ->
                if (showToastOnSuccess) _actionMessage.value = msg
                onResult?.invoke(true, msg)
            }.onFailure { err ->
                val msg = err.message ?: "কুরিয়ার লাইভ আপডেট ব্যর্থ"
                if (showToastOnSuccess) _actionMessage.value = msg
                onResult?.invoke(false, msg)
            }
        }
    }

    fun syncSingleCourierShipment(
        shipmentId: String,
        onResult: ((Boolean, String) -> Unit)? = null
    ) {
        viewModelScope.launch {
            _isCourierLoading.value = true
            val result = repository.syncShipmentStatus(shipmentId)
            _isCourierLoading.value = false
            result.onSuccess { status ->
                val msg = "পার্সেল স্ট্যাটাস আপডেট হয়েছে: $status"
                _actionMessage.value = msg
                onResult?.invoke(true, msg)
            }.onFailure { err ->
                val msg = err.message ?: "স্ট্যাটাস আপডেট ব্যর্থ"
                _actionMessage.value = msg
                onResult?.invoke(false, msg)
            }
        }
    }

    fun trackCourierParcelDirect(code: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            _isCourierLoading.value = true
            val result = repository.trackSteadfastParcelDirect(code)
            _isCourierLoading.value = false
            result.onSuccess { msg ->
                onResult(true, msg)
            }.onFailure { err ->
                onResult(false, err.message ?: "পার্সেল ট্র্যাক করা যায়নি")
            }
        }
    }

    fun approveReturn(returnId: String) {
        viewModelScope.launch {
            repository.approveReturn(returnId).onSuccess {
                _actionMessage.value = "Return record approved and stock/loss adjusted."
            }.onFailure {
                _actionMessage.value = it.message ?: "রিটার্ন অনুমোদন ব্যর্থ"
            }
        }
    }

    fun updatePackaging(info: PackagingTrackingInfo) {
        viewModelScope.launch {
            repository.updatePackaging(info).onSuccess {
                _actionMessage.value = "প্যাকেজিং হিসাব সংরক্ষিত হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "আপডেট ব্যর্থ"
            }
        }
    }

    fun updateAdSpend(info: AdSpendInfo) {
        viewModelScope.launch {
            repository.updateAdSpend(info).onSuccess {
                _actionMessage.value = "এড ও বুস্টিং বাজেট আপডেট হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "আপডেট ব্যর্থ"
            }
        }
    }

    fun updateBoxInfo(info: BoxTrackingInfo) {
        viewModelScope.launch {
            repository.updateBoxInfo(info).onSuccess {
                _actionMessage.value = "বক্স স্টক ও খরচ সংরক্ষিত হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "আপডেট ব্যর্থ"
            }
        }
    }

    fun updateStickerInfo(info: StickerTrackingInfo) {
        viewModelScope.launch {
            repository.updateStickerInfo(info).onSuccess {
                _actionMessage.value = "স্টিকার স্টক ও হিসাব সংরক্ষিত হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "আপডেট ব্যর্থ"
            }
        }
    }

    // --- Customers & Returns ---

    fun addCustomerDirect(name: String, phone: String, address: String) {
        val uid = currentUser.value?.let { it.uid.ifBlank { it.id } } ?: return
        viewModelScope.launch {
            val cust = Customer(
                id = "cust_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                userId = uid,
                name = name,
                phone = phone,
                address = address,
                createdBy = uid
            )
            repository.addCustomer(cust).onSuccess {
                _actionMessage.value = "কাস্টমার সফলভাবে যোগ হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "কাস্টমার যোগ করা যায়নি"
            }
        }
    }

    fun updateCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.updateCustomer(customer).onSuccess {
                _actionMessage.value = "কাস্টমার তথ্য আপডেট করা হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "আপডেট ব্যর্থ"
            }
        }
    }

    fun deleteCustomer(customerId: String) {
        viewModelScope.launch {
            repository.deleteCustomer(customerId).onSuccess {
                _actionMessage.value = "কাস্টমার সফলভাবে মুছে ফেলা হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "ডিলিট ব্যর্থ"
            }
        }
    }

    fun updateReturnRecord(record: ReturnRecord) {
        viewModelScope.launch {
            repository.updateReturnRecord(record).onSuccess {
                _actionMessage.value = "রিটার্ন তথ্য আপডেট করা হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "আপডেট ব্যর্থ"
            }
        }
    }

    fun deleteReturnRecord(returnId: String) {
        viewModelScope.launch {
            repository.deleteReturnRecord(returnId).onSuccess {
                _actionMessage.value = "রিটার্ন রেকর্ড মুছে ফেলা হয়েছে"
            }.onFailure {
                _actionMessage.value = it.message ?: "ডিলিট ব্যর্থ"
            }
        }
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }

    fun approvePasswordReset(requestId: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            repository.approvePasswordReset(requestId).onSuccess { tempPass ->
                _actionMessage.value = "পাসওয়ার্ড রিসেট অনুমোদিত হয়েছে। অস্থায়ী পাসওয়ার্ড তৈরি হয়েছে।"
                onResult(true, tempPass)
            }.onFailure {
                _actionMessage.value = it.message ?: "অনুমোদন ব্যর্থ হয়েছে"
                onResult(false, null)
            }
        }
    }

    fun rejectPasswordReset(requestId: String) {
        viewModelScope.launch {
            repository.rejectPasswordReset(requestId).onSuccess {
                _actionMessage.value = "পাসওয়ার্ড রিসেট রিকোয়েস্ট প্রত্যাখ্যান করা হয়েছে।"
            }.onFailure {
                _actionMessage.value = it.message ?: "প্রত্যাখ্যান ব্যর্থ"
            }
        }
    }

    fun syncWithCloud() {
        viewModelScope.launch {
            _actionMessage.value = "Firebase Cloud Firestore-এর সাথে ডেটা সিঙ্ক হচ্ছে..."
            repository.syncWithCloud().onSuccess {
                _actionMessage.value = it
            }.onFailure {
                _actionMessage.value = it.message ?: "সিঙ্ক ব্যর্থ হয়েছে"
            }
        }
    }

    private fun getDateRangeForFilter(filter: DateFilterType): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis
        return when (filter) {
            DateFilterType.TODAY -> {
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                Pair(cal.timeInMillis, now)
            }
            DateFilterType.YESTERDAY -> {
                cal.add(Calendar.DAY_OF_YEAR, -1)
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                val start = cal.timeInMillis
                cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59)
                Pair(start, cal.timeInMillis)
            }
            DateFilterType.LAST_7_DAYS -> {
                Pair(now - (7L * 86400000L), now)
            }
            DateFilterType.THIS_MONTH -> {
                cal.set(Calendar.DAY_OF_MONTH, 1)
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                Pair(cal.timeInMillis, now)
            }
            DateFilterType.LAST_MONTH -> {
                cal.add(Calendar.MONTH, -1)
                cal.set(Calendar.DAY_OF_MONTH, 1)
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
                val start = cal.timeInMillis
                cal.add(Calendar.MONTH, 1)
                cal.add(Calendar.DAY_OF_MONTH, -1)
                cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59)
                Pair(start, cal.timeInMillis)
            }
            DateFilterType.ALL -> Pair(0L, Long.MAX_VALUE)
        }
    }
}
