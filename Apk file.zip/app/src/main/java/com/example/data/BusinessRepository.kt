package com.example.data

import android.content.Context
import android.util.Log
import com.example.R
import com.example.auth.FirebaseAuthManager
import com.example.auth.configureAppCheckForSecondaryApp
import com.example.courier.SteadfastCourierService
import com.example.localization.AppLanguage
import com.example.model.*
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import com.google.firebase.functions.functions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

class BusinessRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val functions: FirebaseFunctions,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        auth = Firebase.auth,
        functions = Firebase.functions
    )

    companion object {
        private const val TAG = "BusinessRepository"
        const val BOOTSTRAPPED_SUPER_ADMIN_EMAIL = "mdk56750@gmail.com"
        private const val COLLECTION_USERS = "users"
        private const val COLLECTION_PERMISSIONS = "user_permissions"
        private const val COLLECTION_ORDERS = "orders"
        private const val COLLECTION_CUSTOMERS = "customers"
        private const val COLLECTION_TRANSACTIONS = "transactions"
        private const val COLLECTION_RETURNS = "returns"
        private const val COLLECTION_SHIPMENTS = "shipments"
        private const val COLLECTION_PRODUCTS = "products"
        private const val COLLECTION_TARGETS = "sales_targets"
        private const val COLLECTION_RESET_REQUESTS = "password_reset_requests"
        private const val COLLECTION_AUDIT_LOGS = "audit_logs"
        private const val COLLECTION_TRACKERS = "operational_trackers"
        private const val COLLECTION_ADMIN_SETTINGS = "admin_settings"
        private const val COLLECTION_ADMIN_SLOTS = "admin_slots"
        private const val COLLECTION_LOGIN_DIRECTORY = "login_directory"
        private const val DOC_SECONDARY_ADMIN_SLOT = "secondary_super_admin"
        private const val SECONDARY_PROVISIONER_APP_NAME = "SalesTrackSecondaryUserProvisioner"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val authManager = FirebaseAuthManager(auth)
    private val courierService = SteadfastCourierService()

    // Session & Auth state
    private val _authInitializing = MutableStateFlow(true)
    val authInitializing: StateFlow<Boolean> = _authInitializing.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _userPermissions = MutableStateFlow(UserPermissions.defaultUserPermissions(""))
    val userPermissions: StateFlow<UserPermissions> = _userPermissions.asStateFlow()

    private val _currentLanguage = MutableStateFlow(AppLanguage.BANGLA)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Core Data Stores (strictly synchronized from Cloud Firestore)
    private val _users = MutableStateFlow<List<UserProfile>>(emptyList())
    val users: StateFlow<List<UserProfile>> = _users.asStateFlow()

    private val _allPermissions = MutableStateFlow<Map<String, UserPermissions>>(emptyMap())
    val allPermissions: StateFlow<Map<String, UserPermissions>> = _allPermissions.asStateFlow()

    private val _customers = MutableStateFlow<List<Customer>>(emptyList())
    val customers: StateFlow<List<Customer>> = _customers.asStateFlow()

    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _transactions = MutableStateFlow<List<Transaction>>(emptyList())
    val transactions: StateFlow<List<Transaction>> = _transactions.asStateFlow()

    private val _shipments = MutableStateFlow<List<SteadfastShipment>>(emptyList())
    val shipments: StateFlow<List<SteadfastShipment>> = _shipments.asStateFlow()

    private val _returns = MutableStateFlow<List<ReturnRecord>>(emptyList())
    val returns: StateFlow<List<ReturnRecord>> = _returns.asStateFlow()

    private val _salesTargets = MutableStateFlow<List<SalesTarget>>(emptyList())
    val salesTargets: StateFlow<List<SalesTarget>> = _salesTargets.asStateFlow()

    private val _steadfastConfig = MutableStateFlow(
        SteadfastConfig(apiKey = "", secretKey = "", isSandbox = true, isConnected = true)
    )
    val steadfastConfig: StateFlow<SteadfastConfig> = _steadfastConfig.asStateFlow()

    private val _packagingInfo = MutableStateFlow(PackagingTrackingInfo())
    val packagingInfo: StateFlow<PackagingTrackingInfo> = _packagingInfo.asStateFlow()

    private val _adSpendInfo = MutableStateFlow(AdSpendInfo())
    val adSpendInfo: StateFlow<AdSpendInfo> = _adSpendInfo.asStateFlow()

    private val _boxInfo = MutableStateFlow(BoxTrackingInfo())
    val boxInfo: StateFlow<BoxTrackingInfo> = _boxInfo.asStateFlow()

    private val _stickerInfo = MutableStateFlow(StickerTrackingInfo())
    val stickerInfo: StateFlow<StickerTrackingInfo> = _stickerInfo.asStateFlow()

    private val _cloudSyncConfig = MutableStateFlow(
        CloudSyncConfig(
            projectId = db.app.options.projectId ?: "gen-lang-client-0493994891",
            databaseId = db.firestoreSettings.let {
                "ai-studio-android-salestra-7ce3324f-5938-425c-96db-3cec18b439de"
            },
            isCloudConnected = false
        )
    )
    val cloudSyncConfig: StateFlow<CloudSyncConfig> = _cloudSyncConfig.asStateFlow()

    private val _passwordResetRequests = MutableStateFlow<List<PasswordResetRequest>>(emptyList())
    val passwordResetRequests: StateFlow<List<PasswordResetRequest>> = _passwordResetRequests.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditLogs: StateFlow<List<AuditLog>> = _auditLogs.asStateFlow()

    // Active listener registrations
    @Volatile private var profileListener: ListenerRegistration? = null
    @Volatile private var permissionListener: ListenerRegistration? = null
    private val dataListeners = java.util.concurrent.CopyOnWriteArrayList<ListenerRegistration>()
    @Volatile private var syncedUid: String? = null
    @Volatile private var syncedRole: UserRole? = null

    private val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        val user = firebaseAuth.currentUser
        if (user == null) {
            clearSessionData()
            _authInitializing.value = false
        } else {
            attachUserProfileListener(user)
        }
    }

    init {
        auth.addAuthStateListener(authStateListener)
    }

    fun cleanup() {
        auth.removeAuthStateListener(authStateListener)
        clearSessionData()
    }

    @Synchronized
    private fun clearSessionData() {
        profileListener?.remove()
        profileListener = null
        permissionListener?.remove()
        permissionListener = null
        detachDataListeners()
        syncedUid = null
        syncedRole = null

        _currentUser.value = null
        _userPermissions.value = UserPermissions.defaultUserPermissions("")
        _users.value = emptyList()
        _allPermissions.value = emptyMap()
        _customers.value = emptyList()
        _products.value = emptyList()
        _orders.value = emptyList()
        _transactions.value = emptyList()
        _shipments.value = emptyList()
        _returns.value = emptyList()
        _salesTargets.value = emptyList()
        _passwordResetRequests.value = emptyList()
        _auditLogs.value = emptyList()
        _cloudSyncConfig.value = _cloudSyncConfig.value.copy(isCloudConnected = false)
    }

    @Synchronized
    private fun detachDataListeners() {
        val snapshot = dataListeners.toList()
        dataListeners.clear()
        snapshot.forEach { it.remove() }
    }

    private fun attachUserProfileListener(firebaseUser: FirebaseUser) {
        if (syncedUid == firebaseUser.uid && profileListener != null) return

        profileListener?.remove()
        profileListener = null
        permissionListener?.remove()
        permissionListener = null
        detachDataListeners()
        syncedUid = firebaseUser.uid
        syncedRole = null

        val userDocRef = db.collection(COLLECTION_USERS).document(firebaseUser.uid)
        profileListener = userDocRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                handleFirestoreError(error, OperationType.GET, userDocRef.path, auth)
                _authError.value = "প্রোফাইল লোড করা যায়নি: ${error.localizedMessage}"
                _authInitializing.value = false
                return@addSnapshotListener
            }

            if (snapshot == null || !snapshot.exists()) {
                val email = firebaseUser.email?.lowercase() ?: ""
                if (email == BOOTSTRAPPED_SUPER_ADMIN_EMAIL && firebaseUser.isEmailVerified) {
                    scope.launch {
                        bootstrapPrimaryOwnerProfile(firebaseUser)
                    }
                } else {
                    _authError.value = "আপনার অ্যাকাউন্ট অনুমোদিত নয়। পাবলিক রেজিস্ট্রেশন বন্ধ রয়েছে—অ্যাডমিনের সাথে যোগাযোগ করুন।"
                    _authInitializing.value = false
                    scope.launch { authManager.signOut() }
                }
                return@addSnapshotListener
            }

            val profile = snapshot.toObject(
                UserProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )?.let { p ->
                if (p.uid.isBlank()) p.copy(uid = snapshot.id) else p
            }

            if (profile == null) {
                _authInitializing.value = false
                return@addSnapshotListener
            }

            if (!profile.isActive || profile.status != AccountStatus.ACTIVE) {
                _authError.value = when (profile.status) {
                    AccountStatus.SUSPENDED -> "আপনার অ্যাকাউন্টটি অ্যাডমিন কর্তৃক সাসপেন্ড (Suspended) করা হয়েছে।"
                    AccountStatus.DEACTIVATED -> "আপনার অ্যাকাউন্টটি নিষ্ক্রিয় (Deactivated) রয়েছে। প্রাইমারি অ্যাডমিনের সাথে যোগাযোগ করুন।"
                    else -> "আপনার অ্যাকাউন্টটি সক্রিয় নয়।"
                }
                _authInitializing.value = false
                scope.launch { authManager.signOut() }
                return@addSnapshotListener
            }

            _authError.value = null
            _currentUser.value = profile
            _authInitializing.value = false
            _cloudSyncConfig.value = _cloudSyncConfig.value.copy(
                isCloudConnected = true,
                lastSyncTime = System.currentTimeMillis()
            )

            if (syncedRole != profile.role) {
                syncedRole = profile.role
                attachRoleScopedListeners(profile)
            }
        }
    }

    private suspend fun bootstrapPrimaryOwnerProfile(firebaseUser: FirebaseUser) {
        try {
            val callableResult = runCatching {
                functions.getHttpsCallable("bootstrapSuperAdmin")
                    .call(
                        mapOf(
                            "fullName" to (firebaseUser.displayName ?: "Primary Super Admin"),
                            "phone" to (firebaseUser.phoneNumber ?: ""),
                            "userIdCode" to "ADM-001"
                        )
                    ).await()
            }

            if (callableResult.isSuccess) return

            val fnError = callableResult.exceptionOrNull()
            val canFallbackToClient = (fnError as? FirebaseFunctionsException)?.code in setOf(
                FirebaseFunctionsException.Code.NOT_FOUND,
                FirebaseFunctionsException.Code.UNAVAILABLE,
                FirebaseFunctionsException.Code.UNIMPLEMENTED
            )

            if (!canFallbackToClient) {
                Log.w(TAG, "bootstrapSuperAdmin failed: ${fnError?.message}")
                return
            }

            // Rules permit only allowlisted email (mdk56750@gmail.com) to create initial PRIMARY_SUPER_ADMIN
            val uid = firebaseUser.uid
            val email = firebaseUser.email ?: BOOTSTRAPPED_SUPER_ADMIN_EMAIL
            val fullName = firebaseUser.displayName?.takeIf { it.isNotBlank() } ?: "Primary Super Admin"
            val now = FieldValue.serverTimestamp()

            val userMap = mapOf(
                "uid" to uid,
                "userIdCode" to "ADM-001",
                "email" to email,
                "fullName" to fullName,
                "phone" to (firebaseUser.phoneNumber ?: ""),
                "role" to UserRole.PRIMARY_SUPER_ADMIN.name,
                "status" to AccountStatus.ACTIVE.name,
                "isActive" to true,
                "mustChangePasswordOnFirstLogin" to false,
                "monthlySalesTarget" to 100000.0,
                "createdAt" to now,
                "updatedAt" to now
            )
            val permsMap = buildPermissionsMap(UserPermissions.adminPermissions(uid))

            val batch = db.batch()
            batch.set(db.collection(COLLECTION_USERS).document(uid), userMap)
            batch.set(db.collection(COLLECTION_PERMISSIONS).document(uid), permsMap)
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "$COLLECTION_USERS/${firebaseUser.uid}", auth)
            _authError.value = "সুপার অ্যাডমিন প্রোফাইল তৈরি ব্যর্থ: ${e.localizedMessage}"
            _authInitializing.value = false
        }
    }

    private fun attachRoleScopedListeners(profile: UserProfile) {
        permissionListener?.remove()
        detachDataListeners()

        val uid = profile.uid
        val isAdmin = profile.role.isAdmin

        // 1. Own Permissions Listener
        val permRef = db.collection(COLLECTION_PERMISSIONS).document(uid)
        permissionListener = permRef.addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.GET, permRef.path, auth)
                return@addSnapshotListener
            }
            val perms = snap?.toObject(
                UserPermissions::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: if (isAdmin) UserPermissions.adminPermissions(uid) else UserPermissions.defaultUserPermissions(uid)
            _userPermissions.value = perms.copy(userId = uid)
        }

        // 2. Shared Products Catalog Listener
        dataListeners += db.collection(COLLECTION_PRODUCTS).addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_PRODUCTS, auth)
                return@addSnapshotListener
            }
            _products.value = snap?.toObjects(
                Product::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: emptyList()
        }

        // 3. Shared Operational Trackers Listener
        dataListeners += db.collection(COLLECTION_TRACKERS).addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_TRACKERS, auth)
                return@addSnapshotListener
            }
            snap?.documents?.forEach { doc ->
                when (doc.id) {
                    "packaging" -> _packagingInfo.value = PackagingTrackingInfo(
                        totalExpense = doc.getDouble("totalExpense") ?: 0.0,
                        totalPiecesUsed = (doc.getLong("totalPiecesUsed") ?: 0L).toInt(),
                        stockRemainingPieces = (doc.getLong("stockRemainingPieces") ?: 0L).toInt(),
                        perPieceCost = doc.getDouble("perPieceCost") ?: 0.0
                    )
                    "ad_spend" -> _adSpendInfo.value = AdSpendInfo(
                        totalDollarsSpent = doc.getDouble("totalDollarsSpent") ?: 0.0,
                        dailyBudgetDollars = doc.getDouble("dailyBudgetDollars") ?: 0.0,
                        activeAdsCount = (doc.getLong("activeAdsCount") ?: 0L).toInt(),
                        weeklyBudgetDollars = doc.getDouble("weeklyBudgetDollars") ?: 0.0,
                        monthlyBudgetDollars = doc.getDouble("monthlyBudgetDollars") ?: 0.0,
                        dollarRateBdt = doc.getDouble("dollarRateBdt") ?: 122.0
                    )
                    "box" -> _boxInfo.value = BoxTrackingInfo(
                        totalExpense = doc.getDouble("totalExpense") ?: 0.0,
                        totalBoxesStock = (doc.getLong("totalBoxesStock") ?: 0L).toInt(),
                        totalBoxesUsed = (doc.getLong("totalBoxesUsed") ?: 0L).toInt(),
                        perPieceCost = doc.getDouble("perPieceCost") ?: 0.0
                    )
                    "sticker" -> _stickerInfo.value = StickerTrackingInfo(
                        totalExpense = doc.getDouble("totalExpense") ?: 0.0,
                        totalStickersStock = (doc.getLong("totalStickersStock") ?: 0L).toInt(),
                        totalStickersUsed = (doc.getLong("totalStickersUsed") ?: 0L).toInt(),
                        perPieceCost = doc.getDouble("perPieceCost") ?: 0.0
                    )
                }
            }
        }

        // 4. Orders (All for Admins, userId-scoped for Users)
        val ordersQuery = if (isAdmin) {
            db.collection(COLLECTION_ORDERS)
        } else {
            db.collection(COLLECTION_ORDERS).whereEqualTo("userId", uid)
        }
        dataListeners += ordersQuery.addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_ORDERS, auth)
                return@addSnapshotListener
            }
            val list = snap?.toObjects(
                Order::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: emptyList()
            _orders.value = list.sortedByDescending { it.orderDateMillis }
            markSynced()
        }

        // 5. Customers
        val customersQuery = if (isAdmin) {
            db.collection(COLLECTION_CUSTOMERS)
        } else {
            db.collection(COLLECTION_CUSTOMERS).whereEqualTo("userId", uid)
        }
        dataListeners += customersQuery.addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_CUSTOMERS, auth)
                return@addSnapshotListener
            }
            val list = snap?.toObjects(
                Customer::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: emptyList()
            _customers.value = list.sortedByDescending { it.createdAtMillis }
        }

        // 6. Transactions
        val txnsQuery = if (isAdmin) {
            db.collection(COLLECTION_TRANSACTIONS)
        } else {
            db.collection(COLLECTION_TRANSACTIONS).whereEqualTo("userId", uid)
        }
        dataListeners += txnsQuery.addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_TRANSACTIONS, auth)
                return@addSnapshotListener
            }
            val list = snap?.toObjects(
                Transaction::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: emptyList()
            _transactions.value = list.sortedByDescending { it.dateMillis }
        }

        // 7. Returns
        val returnsQuery = if (isAdmin) {
            db.collection(COLLECTION_RETURNS)
        } else {
            db.collection(COLLECTION_RETURNS).whereEqualTo("userId", uid)
        }
        dataListeners += returnsQuery.addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_RETURNS, auth)
                return@addSnapshotListener
            }
            val list = snap?.toObjects(
                ReturnRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: emptyList()
            _returns.value = list.sortedByDescending { it.dateMillis }
        }

        // 8. Shipments
        val shipmentsQuery = if (isAdmin) {
            db.collection(COLLECTION_SHIPMENTS)
        } else {
            db.collection(COLLECTION_SHIPMENTS).whereEqualTo("userId", uid)
        }
        dataListeners += shipmentsQuery.addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_SHIPMENTS, auth)
                return@addSnapshotListener
            }
            val list = snap?.toObjects(
                SteadfastShipment::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: emptyList()
            _shipments.value = list.sortedByDescending { it.lastSyncedMillis }
        }

        // 9. Sales Targets
        val targetsQuery = if (isAdmin) {
            db.collection(COLLECTION_TARGETS)
        } else {
            db.collection(COLLECTION_TARGETS).whereEqualTo("userId", uid)
        }
        dataListeners += targetsQuery.addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_TARGETS, auth)
                return@addSnapshotListener
            }
            _salesTargets.value = snap?.toObjects(
                SalesTarget::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: emptyList()
        }

        // 10. Password Reset Requests (Admins see all; Users see only own)
        val resetsQuery = if (isAdmin) {
            db.collection(COLLECTION_RESET_REQUESTS)
        } else {
            db.collection(COLLECTION_RESET_REQUESTS).whereEqualTo("userId", uid)
        }
        dataListeners += resetsQuery.addSnapshotListener { snap, err ->
            if (err != null) {
                handleFirestoreError(err, OperationType.LIST, COLLECTION_RESET_REQUESTS, auth)
                return@addSnapshotListener
            }
            val list = snap?.toObjects(
                PasswordResetRequest::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: emptyList()
            _passwordResetRequests.value = list.sortedByDescending { it.requestTimeMillis }
        }

        // 11. Admin-only collections
        if (isAdmin) {
            dataListeners += db.collection(COLLECTION_USERS).addSnapshotListener { snap, err ->
                if (err != null) {
                    handleFirestoreError(err, OperationType.LIST, COLLECTION_USERS, auth)
                    return@addSnapshotListener
                }
                _users.value = snap?.toObjects(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: emptyList()
            }

            dataListeners += db.collection(COLLECTION_PERMISSIONS).addSnapshotListener { snap, err ->
                if (err != null) {
                    handleFirestoreError(err, OperationType.LIST, COLLECTION_PERMISSIONS, auth)
                    return@addSnapshotListener
                }
                val permsList = snap?.toObjects(
                    UserPermissions::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: emptyList()
                _allPermissions.value = permsList.associateBy { it.userId.ifBlank { it.id } }
            }

            dataListeners += db.collection(COLLECTION_AUDIT_LOGS).addSnapshotListener { snap, err ->
                if (err != null) {
                    handleFirestoreError(err, OperationType.LIST, COLLECTION_AUDIT_LOGS, auth)
                    return@addSnapshotListener
                }
                val logs = snap?.toObjects(
                    AuditLog::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: emptyList()
                _auditLogs.value = logs.sortedByDescending { it.timestampMillis }
            }

            val configRef = db.collection(COLLECTION_ADMIN_SETTINGS).document("steadfast")
            dataListeners += configRef.addSnapshotListener { snap, err ->
                if (err != null) {
                    handleFirestoreError(err, OperationType.GET, configRef.path, auth)
                    return@addSnapshotListener
                }
                if (snap != null && snap.exists()) {
                    _steadfastConfig.value = SteadfastConfig(
                        apiKey = snap.getString("apiKey") ?: "",
                        secretKey = snap.getString("secretKey") ?: "",
                        isSandbox = snap.getBoolean("isSandbox") ?: true,
                        isConnected = snap.getBoolean("isConnected") ?: true,
                        updatedAt = snap.getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    )
                }
            }
        } else {
            _users.value = listOf(profile)
        }
    }

    private fun markSynced() {
        _cloudSyncConfig.value = _cloudSyncConfig.value.copy(
            isCloudConnected = true,
            lastSyncTime = System.currentTimeMillis()
        )
    }

    // --- Authentication ---

    suspend fun login(identifier: String, password: String): Result<UserProfile> = withContext(ioDispatcher) {
        _authError.value = null
        val trimmed = identifier.trim()
        if (trimmed.isBlank() || password.isBlank()) {
            return@withContext Result.failure(Exception("ইউজার আইডি/ইমেইল এবং পাসওয়ার্ড দিন!"))
        }

        val resolvedEmail = if (!trimmed.contains("@")) {
            val codeUpper = trimmed.uppercase()
            val directoryEmail = if (codeUpper.matches(Regex("^[A-Za-z0-9_-]{1,128}$"))) {
                runCatching {
                    db.collection(COLLECTION_LOGIN_DIRECTORY)
                        .document(codeUpper)
                        .get()
                        .await()
                        .getString("email")
                }.getOrNull()?.takeIf { it.isNotBlank() }
            } else {
                null
            }

            when {
                directoryEmail != null -> directoryEmail.lowercase()
                codeUpper == "ADM-001" -> BOOTSTRAPPED_SUPER_ADMIN_EMAIL
                else -> {
                    val remoteEmail = runCatching {
                        val res = functions.getHttpsCallable("resolveLoginEmail")
                            .call(mapOf("identifier" to trimmed))
                            .await()
                        @Suppress("UNCHECKED_CAST")
                        (res.getData() as? Map<String, Any?>)?.get("email") as? String
                    }.getOrNull()
                    remoteEmail?.takeIf { it.isNotBlank() }?.lowercase()
                        ?: FirebaseAuthManager.normalizeIdentifierToEmail(trimmed)
                }
            }
        } else {
            trimmed.lowercase()
        }

        var authResult = authManager.signInWithEmail(resolvedEmail, password)

        // Legacy fallback only if ADM-001 was manually provisioned in Firebase Auth as adm-001@salestrack.app
        val syntheticAdminEmail = FirebaseAuthManager.normalizeIdentifierToEmail("ADM-001")
        if (authResult.isFailure &&
            trimmed.equals("ADM-001", ignoreCase = true) &&
            resolvedEmail == BOOTSTRAPPED_SUPER_ADMIN_EMAIL &&
            resolvedEmail != syntheticAdminEmail
        ) {
            val err = authResult.exceptionOrNull()
            if (err is FirebaseAuthInvalidCredentialsException || err is FirebaseAuthInvalidUserException) {
                val fallbackResult = authManager.signInWithEmail(syntheticAdminEmail, password)
                if (fallbackResult.isSuccess) {
                    authResult = fallbackResult
                }
            }
        }

        if (authResult.isFailure) {
            val err = authResult.exceptionOrNull()
            return@withContext Result.failure(
                Exception(mapAuthErrorMessage(err, trimmed))
            )
        }

        val firebaseUser = authResult.getOrThrow()
        return@withContext verifyAndLoadProfileAfterAuth(firebaseUser)
    }

    suspend fun loginWithGoogle(activityContext: Context): Result<UserProfile> {
        _authError.value = null
        val authResult = authManager.signInWithGoogle(activityContext)
        if (authResult.isFailure) {
            return Result.failure(authResult.exceptionOrNull() ?: Exception("Google Sign-In failed"))
        }
        return verifyAndLoadProfileAfterAuth(authResult.getOrThrow())
    }

    private suspend fun verifyAndLoadProfileAfterAuth(firebaseUser: FirebaseUser): Result<UserProfile> {
        val docRef = db.collection(COLLECTION_USERS).document(firebaseUser.uid)
        return try {
            var snap = docRef.get().await()
            if (!snap.exists()) {
                val email = firebaseUser.email?.lowercase() ?: ""
                if (email == BOOTSTRAPPED_SUPER_ADMIN_EMAIL && firebaseUser.isEmailVerified) {
                    bootstrapPrimaryOwnerProfile(firebaseUser)
                    snap = docRef.get().await()
                }
            }

            if (!snap.exists()) {
                authManager.signOut()
                return Result.failure(
                    Exception("আপনার অ্যাকাউন্ট পাওয়া যায়নি। পাবলিক রেজিস্ট্রেশন বন্ধ—অ্যাডমিনকে দিয়ে অ্যাকাউন্ট তৈরি করান।")
                )
            }

            val profile = snap.toObject(
                UserProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )?.let { if (it.uid.isBlank()) it.copy(uid = snap.id) else it }
                ?: run {
                    authManager.signOut()
                    return Result.failure(Exception("ইউজার প্রোফাইল ডেটা অকার্যকর!"))
                }

            if (!profile.isActive || profile.status != AccountStatus.ACTIVE) {
                authManager.signOut()
                val msg = when (profile.status) {
                    AccountStatus.SUSPENDED -> "আপনার অ্যাকাউন্টটি অ্যাডমিন কর্তৃক সাসপেন্ড (Suspended) করা হয়েছে।"
                    AccountStatus.DEACTIVATED -> "আপনার অ্যাকাউন্টটি নিষ্ক্রিয় (Deactivated) রয়েছে। প্রাইমারি অ্যাডমিনের অনুমোদন প্রয়োজন।"
                    else -> "আপনার অ্যাকাউন্টটি সক্রিয় নয়।"
                }
                return Result.failure(Exception(msg))
            }

            logAuditInternal("User Login", profile.uid, profile.fullName, profile.uid, "Signed in (${profile.userIdCode})")
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path, auth)
            Result.failure(e)
        }
    }

    private fun mapAuthErrorMessage(err: Throwable?, attemptedIdentifier: String = ""): String {
        val msg = err?.message ?: ""
        return when {
            err is FirebaseAuthInvalidCredentialsException ||
            err is FirebaseAuthInvalidUserException ||
            msg.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ||
            msg.contains("wrong-password", ignoreCase = true) ||
            msg.contains("user-not-found", ignoreCase = true) ||
            msg.contains("invalid-credential", ignoreCase = true) ||
            msg.contains("incorrect, malformed", ignoreCase = true) -> {
                if (attemptedIdentifier.equals("ADM-001", ignoreCase = true) ||
                    attemptedIdentifier.equals(BOOTSTRAPPED_SUPER_ADMIN_EMAIL, ignoreCase = true)
                ) {
                    "ভুল পাসওয়ার্ড অথবা $BOOTSTRAPPED_SUPER_ADMIN_EMAIL অ্যাকাউন্টে এখনো Email/Password সেট করা হয়নি। প্রাইমারি অ্যাডমিন হিসেবে নিচের 'Google দিয়ে সাইন-ইন' বাটন ব্যবহার করুন অথবা সঠিক পাসওয়ার্ড দিন।"
                } else {
                    "ভুল ইউজার আইডি/ইমেইল অথবা পাসওয়ার্ড! (অ্যাকাউন্ট তৈরি না হয়ে থাকলে অ্যাডমিন প্যানেল থেকে তৈরি করুন)"
                }
            }
            msg.contains("USER_DISABLED", ignoreCase = true) ||
            msg.contains("user-disabled", ignoreCase = true) ->
                "এই অ্যাকাউন্টটি অ্যাডমিন কর্তৃক নিষ্ক্রিয় বা সাসপেন্ড করা হয়েছে।"
            msg.contains("App Check", ignoreCase = true) ||
            msg.contains("appcheck", ignoreCase = true) ||
            msg.contains("attestation", ignoreCase = true) ->
                "Firebase Console-এ App Check Enforcement চালু থাকায় লগইন আটকে গেছে। অনুগ্রহ করে Firebase Console → App Check-এ Authentication এবং Cloud Firestore 'Unenforced' করুন।"
            msg.contains("network", ignoreCase = true) ->
                "ইন্টারনেট সংযোগ ব্যর্থ! অনুগ্রহ করে নেটওয়ার্ক চেক করুন।"
            else -> err?.localizedMessage ?: "লগইন ব্যর্থ হয়েছে"
        }
    }

    suspend fun logout(context: Context? = null) {
        val current = _currentUser.value
        if (current != null) {
            runCatching {
                logAuditInternal("User Logout", current.uid, current.fullName, current.uid, "Signed out")
            }
        }
        authManager.signOut(context)
        clearSessionData()
    }

    fun clearAuthError() {
        _authError.value = null
    }

    fun switchLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    // --- Financial Calculations (Golden Rules) ---

    fun calculateMetrics(startDateMillis: Long = 0, endDateMillis: Long = Long.MAX_VALUE): DashboardMetrics {
        val filteredOrders = _orders.value.filter { it.orderDateMillis in startDateMillis..endDateMillis }
        val filteredTransactions = _transactions.value.filter { it.dateMillis in startDateMillis..endDateMillis }

        val totalOrders = filteredOrders.size
        val pendingOrders = filteredOrders.count {
            it.status == OrderStatus.PENDING || it.status == OrderStatus.NEW || it.status == OrderStatus.PROCESSING
        }
        val deliveredOrdersList = filteredOrders.filter { it.status == OrderStatus.DELIVERED }
        val deliveredOrders = deliveredOrdersList.size
        val cancelledOrders = filteredOrders.count { it.status == OrderStatus.CANCELLED }
        val returnedOrders = filteredOrders.count { it.status == OrderStatus.RETURNED }

        val recognizedRevenue = deliveredOrdersList.sumOf { it.productPrice - it.discount }
        val totalSales = recognizedRevenue
        val cogsAmount = deliveredOrdersList.sumOf { it.productCost }

        val totalIncome = filteredTransactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val totalExpenses = filteredTransactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }

        val adCostAmount = filteredTransactions.filter { it.category == "Advertising Cost" }.sumOf { it.amount }
        val courierExpense = filteredTransactions.filter { it.category == "Courier Charge" }.sumOf { it.amount }
        val packagingExpense = filteredTransactions.filter { it.category == "Packaging Cost" }.sumOf { it.amount }

        val operatingExpenses = filteredTransactions
            .filter { it.type == TransactionType.EXPENSE && it.category != "Product Purchase Cost" }
            .sumOf { it.amount }
        val totalCost = cogsAmount + operatingExpenses
        val totalProfit = recognizedRevenue - totalCost

        return DashboardMetrics(
            totalCost = totalCost,
            totalProfit = totalProfit,
            totalOrders = totalOrders,
            totalUsers = _users.value.size,
            totalCustomers = _customers.value.size,
            totalSales = totalSales,
            totalIncome = totalIncome,
            totalExpenses = totalExpenses,
            pendingOrders = pendingOrders,
            deliveredOrders = deliveredOrders,
            cancelledOrders = cancelledOrders,
            returnedOrders = returnedOrders,
            recognizedRevenue = recognizedRevenue,
            cogsAmount = cogsAmount,
            adCostAmount = adCostAmount,
            courierExpense = courierExpense,
            packagingExpense = packagingExpense
        )
    }

    fun getUserMetrics(userId: String): DashboardMetrics {
        val userOrders = _orders.value.filter { it.userId == userId || it.createdBy == userId }
        val deliveredOrdersList = userOrders.filter { it.status == OrderStatus.DELIVERED }

        val totalSales = deliveredOrdersList.sumOf { it.productPrice - it.discount }
        val cogsAmount = deliveredOrdersList.sumOf { it.productCost }

        return DashboardMetrics(
            totalSales = totalSales,
            totalCost = cogsAmount,
            totalProfit = totalSales - cogsAmount,
            totalOrders = userOrders.size,
            pendingOrders = userOrders.count { it.status == OrderStatus.PENDING || it.status == OrderStatus.NEW },
            deliveredOrders = deliveredOrdersList.size,
            cancelledOrders = userOrders.count { it.status == OrderStatus.CANCELLED },
            returnedOrders = userOrders.count { it.status == OrderStatus.RETURNED },
            recognizedRevenue = totalSales
        )
    }

    fun getUserTargetProgress(userId: String): UserTargetProgress? {
        val user = _users.value.find { it.uid == userId || it.id == userId } ?: _currentUser.value ?: return null
        val target = _salesTargets.value.find { it.userId == userId }
        val targetAmount = target?.targetAmount ?: user.monthlySalesTarget

        val userDeliveredSales = _orders.value
            .filter { (it.userId == userId || it.createdBy == userId) && it.status == OrderStatus.DELIVERED }
            .sumOf { it.productPrice - it.discount }

        val remaining = (targetAmount - userDeliveredSales).coerceAtLeast(0.0)
        val percentage = if (targetAmount > 0) (userDeliveredSales / targetAmount) * 100.0 else 0.0

        return UserTargetProgress(
            user = user,
            targetAmount = targetAmount,
            achievedSales = userDeliveredSales,
            remainingTarget = remaining,
            achievementPercentage = percentage.coerceAtMost(100.0),
            rank = 1
        )
    }

    // --- Order Operations ---

    suspend fun createOrder(order: Order): Result<Order> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid
            ?: return@withContext Result.failure(IllegalStateException("অর্ডার তৈরির আগে লগইন করুন।"))
        val isAdmin = _currentUser.value?.role?.isAdmin == true
        if (!isAdmin && !_userPermissions.value.canCreateOrders) {
            return@withContext Result.failure(
                IllegalStateException("আপনার অর্ডার তৈরি করার অনুমতি নেই। সুপার অ্যাডমিনের অনুমতি নিন।")
            )
        }

        if (_orders.value.any { it.invoiceNumber == order.invoiceNumber }) {
            return@withContext Result.failure(Exception("Invoice number ${order.invoiceNumber} already exists!"))
        }

        val orderId = order.id.ifBlank { "ord_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection(COLLECTION_ORDERS).document(orderId)

        val payload = mapOf<String, Any?>(
            "userId" to uid,
            "invoiceNumber" to order.invoiceNumber,
            "customerId" to order.customerId,
            "customerName" to order.customerName,
            "customerPhone" to order.customerPhone,
            "customerAddress" to order.customerAddress,
            "productSummary" to order.productSummary,
            "productPrice" to order.productPrice,
            "productCost" to order.productCost,
            "discount" to order.discount,
            "deliveryCharge" to order.deliveryCharge,
            "codAmount" to order.codAmount,
            "createdBy" to uid,
            "createdByName" to (_currentUser.value?.fullName ?: order.createdByName),
            "assignedTo" to order.assignedTo,
            "status" to order.status.name,
            "consignmentId" to order.consignmentId,
            "trackingCode" to order.trackingCode,
            "orderDateMillis" to order.orderDateMillis,
            "updatedAtMillis" to System.currentTimeMillis(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }.mapValues { it.value!! }

        return@withContext try {
            docRef.set(payload).await()
            val customer = _customers.value.find { it.id == order.customerId }
            if (customer != null && customer.id.isNotBlank()) {
                runCatching {
                    db.collection(COLLECTION_CUSTOMERS).document(customer.id)
                        .update(
                            mapOf(
                                "totalOrders" to (customer.totalOrders + 1),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                }
            }
            Result.success(order.copy(id = orderId, userId = uid, createdBy = uid))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateOrder(order: Order): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_ORDERS).document(order.id)
        val updates = mapOf<String, Any?>(
            "customerName" to order.customerName,
            "customerPhone" to order.customerPhone,
            "customerAddress" to order.customerAddress,
            "productSummary" to order.productSummary,
            "productPrice" to order.productPrice,
            "productCost" to order.productCost,
            "discount" to order.discount,
            "deliveryCharge" to order.deliveryCharge,
            "codAmount" to order.codAmount,
            "status" to order.status.name,
            "updatedAtMillis" to System.currentTimeMillis(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }.mapValues { it.value!! }

        return@withContext try {
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteOrder(orderId: String): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_ORDERS).document(orderId)
        return@withContext try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: OrderStatus): Result<Unit> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid
            ?: return@withContext Result.failure(IllegalStateException("Not authenticated"))
        val existingOrder = _orders.value.find { it.id == orderId }
        val docRef = db.collection(COLLECTION_ORDERS).document(orderId)

        return@withContext try {
            docRef.update(
                mapOf(
                    "status" to newStatus.name,
                    "updatedAtMillis" to System.currentTimeMillis(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            if (existingOrder != null && newStatus == OrderStatus.DELIVERED && existingOrder.status != OrderStatus.DELIVERED) {
                val txn = Transaction(
                    id = "txn_${UUID.randomUUID().toString().replace("-", "").take(16)}",
                    userId = existingOrder.userId.ifBlank { uid },
                    transactionCode = "TXN-${System.currentTimeMillis().toString().takeLast(6)}",
                    type = TransactionType.INCOME,
                    category = "Product Sales",
                    amount = existingOrder.codAmount,
                    relatedOrderId = existingOrder.id,
                    description = "Payment collected for ${existingOrder.invoiceNumber}",
                    createdBy = uid
                )
                addTransaction(txn)
            }

            if (existingOrder != null && newStatus == OrderStatus.RETURNED && existingOrder.status != OrderStatus.RETURNED) {
                val returnId = "ret_${UUID.randomUUID().toString().replace("-", "").take(16)}"
                val retRef = db.collection(COLLECTION_RETURNS).document(returnId)
                val retMap = mapOf(
                    "userId" to existingOrder.userId.ifBlank { uid },
                    "orderId" to existingOrder.id,
                    "invoiceNumber" to existingOrder.invoiceNumber,
                    "customerName" to existingOrder.customerName,
                    "reason" to "Returned by customer upon delivery attempt",
                    "status" to "Requested",
                    "costAdjustment" to existingOrder.productCost,
                    "deliveryChargeLoss" to existingOrder.deliveryCharge,
                    "approvedBy" to uid,
                    "dateMillis" to System.currentTimeMillis(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                retRef.set(retMap).await()
            }

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun sendOrderToSteadfast(orderId: String): Result<SteadfastShipment> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid
            ?: return@withContext Result.failure(IllegalStateException("Not authenticated"))
        val isAdmin = _currentUser.value?.role?.isAdmin == true
        if (!isAdmin && !_userPermissions.value.canCreateCourierOrders) {
            return@withContext Result.failure(
                IllegalStateException("আপনার কুরিয়ারে অর্ডার পাঠানোর অনুমতি নেই। সুপার অ্যাডমিনের অনুমতি নিন।")
            )
        }
        val order = _orders.value.find { it.id == orderId }
            ?: runCatching {
                db.collection(COLLECTION_ORDERS).document(orderId).get().await()
                    .toObject(Order::class.java)
            }.getOrNull()
            ?: return@withContext Result.failure(Exception("Order not found!"))

        // Non-admin sellers cannot read admin_settings/steadfast secrets on client,
        // so use the server Cloud Function when available to dispatch with live credentials.
        if (!isAdmin) {
            val fnRes = runCatching {
                functions.getHttpsCallable("dispatchOrderToSteadfast")
                    .call(mapOf("orderId" to orderId))
                    .await()
                    .data as? Map<*, *>
            }
            if (fnRes.isSuccess) {
                val data = fnRes.getOrNull()
                if (data != null) {
                    return@withContext Result.success(
                        SteadfastShipment(
                            id = data["id"] as? String ?: "",
                            userId = data["userId"] as? String ?: uid,
                            orderId = orderId,
                            invoiceNumber = data["invoiceNumber"] as? String ?: order.invoiceNumber,
                            consignmentId = data["consignmentId"] as? String ?: "",
                            trackingCode = data["trackingCode"] as? String ?: "",
                            codAmount = (data["codAmount"] as? Number)?.toDouble() ?: order.codAmount,
                            deliveryCharge = (data["deliveryCharge"] as? Number)?.toDouble() ?: 120.0,
                            status = data["status"] as? String ?: "in_review",
                            isSandbox = (data["isSandbox"] as? Boolean) ?: true,
                            lastSyncedMillis = (data["lastSyncedMillis"] as? Number)?.toLong() ?: System.currentTimeMillis()
                        )
                    )
                }
            } else {
                val err = fnRes.exceptionOrNull()
                val code = (err as? FirebaseFunctionsException)?.code
                val canFallback = code in setOf(
                    FirebaseFunctionsException.Code.NOT_FOUND,
                    FirebaseFunctionsException.Code.UNAVAILABLE,
                    FirebaseFunctionsException.Code.UNIMPLEMENTED
                )
                if (!canFallback) {
                    return@withContext Result.failure(
                        Exception((err as? Exception)?.let { formatFunctionsError(it, "কুরিয়ার বুকিং ব্যর্থ") } ?: "কুরিয়ার বুকিং ব্যর্থ")
                    )
                }
            }
        }

        val result = courierService.createParcel(
            config = _steadfastConfig.value,
            orderId = order.id,
            invoice = order.invoiceNumber,
            recipientName = order.customerName,
            recipientPhone = order.customerPhone,
            recipientAddress = order.customerAddress,
            codAmount = order.codAmount
        )

        val shipment = result.getOrElse { return@withContext Result.failure(it) }
        val shipId = shipment.id.ifBlank { "ship_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val shipRef = db.collection(COLLECTION_SHIPMENTS).document(shipId)
        val shipPayload = mapOf(
            "userId" to uid,
            "orderId" to order.id,
            "invoiceNumber" to shipment.invoiceNumber,
            "consignmentId" to shipment.consignmentId,
            "trackingCode" to shipment.trackingCode,
            "codAmount" to shipment.codAmount,
            "deliveryCharge" to shipment.deliveryCharge,
            "status" to shipment.status,
            "isSandbox" to shipment.isSandbox,
            "lastSyncedMillis" to shipment.lastSyncedMillis,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        return@withContext try {
            shipRef.set(shipPayload).await()
            db.collection(COLLECTION_ORDERS).document(orderId).update(
                mapOf(
                    "consignmentId" to shipment.consignmentId,
                    "trackingCode" to shipment.trackingCode,
                    "status" to OrderStatus.SHIPPED.name,
                    "updatedAtMillis" to System.currentTimeMillis(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(shipment.copy(id = shipId, userId = uid))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, shipRef.path, auth)
            Result.failure(e)
        }
    }

    // --- Customer Operations ---

    suspend fun addCustomer(customer: Customer): Result<Customer> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid
            ?: return@withContext Result.failure(IllegalStateException("Not authenticated"))
        if (_customers.value.any { it.phone == customer.phone }) {
            return@withContext Result.failure(Exception("Customer with phone ${customer.phone} already exists!"))
        }

        val custId = customer.id.ifBlank { "cust_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection(COLLECTION_CUSTOMERS).document(custId)
        val payload = mapOf(
            "userId" to uid,
            "name" to customer.name,
            "phone" to customer.phone,
            "address" to customer.address,
            "city" to customer.city,
            "notes" to customer.notes,
            "totalOrders" to customer.totalOrders,
            "deliveredOrders" to customer.deliveredOrders,
            "returnedOrders" to customer.returnedOrders,
            "createdBy" to uid,
            "createdAtMillis" to customer.createdAtMillis,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        return@withContext try {
            docRef.set(payload).await()
            Result.success(customer.copy(id = custId, userId = uid, createdBy = uid))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateCustomer(customer: Customer): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_CUSTOMERS).document(customer.id)
        return@withContext try {
            docRef.update(
                mapOf(
                    "name" to customer.name,
                    "phone" to customer.phone,
                    "address" to customer.address,
                    "city" to customer.city,
                    "notes" to customer.notes,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteCustomer(customerId: String): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_CUSTOMERS).document(customerId)
        return@withContext try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }

    // --- Transactions / Ledger ---

    suspend fun addTransaction(transaction: Transaction): Result<Unit> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid
            ?: return@withContext Result.failure(IllegalStateException("Not authenticated"))
        val txnId = transaction.id.ifBlank { "txn_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection(COLLECTION_TRANSACTIONS).document(txnId)
        val payload = mapOf<String, Any?>(
            "userId" to transaction.userId.ifBlank { uid },
            "transactionCode" to transaction.transactionCode,
            "type" to transaction.type.name,
            "category" to transaction.category,
            "amount" to transaction.amount,
            "relatedOrderId" to transaction.relatedOrderId,
            "description" to transaction.description,
            "createdBy" to uid,
            "dateMillis" to transaction.dateMillis,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }.mapValues { it.value!! }

        return@withContext try {
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteTransaction(transactionId: String): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_TRANSACTIONS).document(transactionId)
        return@withContext try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateReturnRecord(record: ReturnRecord): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_RETURNS).document(record.id)
        return@withContext try {
            docRef.update(
                mapOf(
                    "reason" to record.reason,
                    "status" to record.status,
                    "costAdjustment" to record.costAdjustment,
                    "deliveryChargeLoss" to record.deliveryChargeLoss,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun deleteReturnRecord(returnId: String): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_RETURNS).document(returnId)
        return@withContext try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun approveReturn(returnId: String): Result<Unit> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid ?: ""
        val docRef = db.collection(COLLECTION_RETURNS).document(returnId)
        return@withContext try {
            docRef.update(
                mapOf(
                    "status" to "Approved & Cost Adjusted",
                    "approvedBy" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    // --- User & Permission Management (Privileged Cloud Functions + Firestore) ---

    suspend fun createUser(
        fullName: String,
        phone: String,
        email: String = "",
        role: UserRole,
        initialPass: String,
        customUserIdCode: String? = null,
        monthlyTarget: Double = 50000.0
    ): Result<UserProfile> = withContext(ioDispatcher) {
        try {
            val payload = hashMapOf<String, Any>(
                "fullName" to fullName.trim(),
                "phone" to phone.trim(),
                "role" to role.name,
                "password" to initialPass,
                "monthlySalesTarget" to monthlyTarget,
                "mustChangePasswordOnFirstLogin" to true
            )
            if (!customUserIdCode.isNullOrBlank()) {
                payload["userIdCode"] = customUserIdCode.trim().uppercase()
            }
            if (email.isNotBlank()) {
                payload["email"] = email.trim().lowercase()
            }

            val res = functions.getHttpsCallable("createManagedUser").call(payload).await()
            val data = res.getData() as? Map<*, *>
            val created = UserProfile(
                id = (data?.get("uid") as? String) ?: "",
                uid = (data?.get("uid") as? String) ?: "",
                userIdCode = (data?.get("userIdCode") as? String) ?: (customUserIdCode ?: ""),
                email = (data?.get("email") as? String) ?: email,
                fullName = (data?.get("fullName") as? String) ?: fullName,
                phone = (data?.get("phone") as? String) ?: phone,
                role = role,
                status = AccountStatus.ACTIVE,
                isActive = true,
                mustChangePasswordOnFirstLogin = (data?.get("mustChangePasswordOnFirstLogin") as? Boolean) ?: true,
                monthlySalesTarget = (data?.get("monthlySalesTarget") as? Number)?.toDouble() ?: monthlyTarget
            )
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val code = (e as? FirebaseFunctionsException)?.code
            val isEmulator = auth.app.options.apiKey == "fake-api-key-for-emulator"
            val hasConnectFailure = generateSequence<Throwable>(e) { it.cause }
                .any { it is java.net.ConnectException }
            val shouldUseSparkFallback = code == FirebaseFunctionsException.Code.NOT_FOUND ||
                code == FirebaseFunctionsException.Code.UNAVAILABLE ||
                code == FirebaseFunctionsException.Code.UNIMPLEMENTED ||
                hasConnectFailure ||
                (isEmulator && code !in setOf(
                    FirebaseFunctionsException.Code.PERMISSION_DENIED,
                    FirebaseFunctionsException.Code.ALREADY_EXISTS,
                    FirebaseFunctionsException.Code.INVALID_ARGUMENT,
                    FirebaseFunctionsException.Code.FAILED_PRECONDITION
                ))
            if (shouldUseSparkFallback) {
                createUserViaSecondaryApp(
                    fullName = fullName,
                    phone = phone,
                    email = email,
                    role = role,
                    initialPass = initialPass,
                    customUserIdCode = customUserIdCode,
                    monthlyTarget = monthlyTarget
                )
            } else {
                Log.e(TAG, "createManagedUser callable failed", e)
                Result.failure(Exception(formatFunctionsError(e, "ইউজার তৈরি ব্যর্থ হয়েছে")))
            }
        }
    }

    private suspend fun createUserViaSecondaryApp(
        fullName: String,
        phone: String,
        email: String,
        role: UserRole,
        initialPass: String,
        customUserIdCode: String?,
        monthlyTarget: Double
    ): Result<UserProfile> {
        val adminUid = auth.currentUser?.uid
            ?: return Result.failure(Exception("অ্যাকাউন্ট তৈরি করতে সুপার অ্যাডমিন হিসেবে লগইন থাকতে হবে।"))

        val cleanName = fullName.trim()
        val cleanPhone = phone.trim()
        if (cleanName.isBlank() || cleanPhone.isBlank() || initialPass.length < 6) {
            return Result.failure(Exception("নাম, ফোন নম্বর এবং কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন!"))
        }
        if (cleanName.length > 120 || cleanPhone.length > 30) {
            return Result.failure(Exception("নাম বা ফোন নম্বরের দৈর্ঘ্য সীমা অতিক্রম করেছে।"))
        }
        if (role != UserRole.USER && role != UserRole.SECONDARY_SUPER_ADMIN) {
            return Result.failure(Exception("অকার্যকর অ্যাকাউন্ট রোল! নতুন প্রাইমারি সুপার অ্যাডমিন তৈরি করা যাবে না।"))
        }

        return try {
            val adminSnap = db.collection(COLLECTION_USERS).document(adminUid).get().await()
            val adminProfile = adminSnap.toObject(
                UserProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )?.let { if (it.uid.isBlank()) it.copy(uid = adminSnap.id) else it }
                ?: return Result.failure(Exception("অ্যাডমিন প্রোফাইল পাওয়া যায়নি।"))

            if (!adminProfile.isActive || adminProfile.status != AccountStatus.ACTIVE || !adminProfile.role.isAdmin) {
                return Result.failure(Exception("শুধুমাত্র সক্রিয় সুপার অ্যাডমিন নতুন অ্যাকাউন্ট তৈরি করতে পারবেন।"))
            }

            if (role == UserRole.SECONDARY_SUPER_ADMIN) {
                if (adminProfile.role != UserRole.PRIMARY_SUPER_ADMIN) {
                    return Result.failure(Exception("শুধুমাত্র প্রাইমারি সুপার অ্যাডমিন ২য় সুপার অ্যাডমিন তৈরি করতে পারবেন।"))
                }
                val superAdminsSnap = db.collection(COLLECTION_USERS)
                    .whereIn(
                        "role",
                        listOf(UserRole.PRIMARY_SUPER_ADMIN.name, UserRole.SECONDARY_SUPER_ADMIN.name)
                    )
                    .get()
                    .await()
                val slotSnap = db.collection(COLLECTION_ADMIN_SLOTS)
                    .document(DOC_SECONDARY_ADMIN_SLOT)
                    .get()
                    .await()
                if (superAdminsSnap.size() >= 2 || slotSnap.exists()) {
                    return Result.failure(Exception("সর্বোচ্চ ২ জন সুপার অ্যাডমিন (১ জন প্রাইমারি + ১ জন সেকেন্ডারি) তৈরি করা যাবে।"))
                }
            }

            val prefix = if (role == UserRole.SECONDARY_SUPER_ADMIN) "ADM" else "USR"
            val userIdCode: String = if (!customUserIdCode.isNullOrBlank()) {
                val candidate = customUserIdCode.trim().uppercase()
                if (!candidate.matches(Regex("^[A-Z0-9_-]{2,64}$"))) {
                    return Result.failure(Exception("ইউজার আইডিতে কেবল ইংরেজি অক্ষর, সংখ্যা, '-' বা '_' ব্যবহার করুন (কমপক্ষে ২ অক্ষর)।"))
                }
                val dupSnap = db.collection(COLLECTION_USERS)
                    .whereEqualTo("userIdCode", candidate)
                    .limit(1)
                    .get()
                    .await()
                if (!dupSnap.isEmpty) {
                    return Result.failure(Exception("ইউজার আইডি '$candidate' আগে থেকেই ব্যবহৃত হয়েছে।"))
                }
                candidate
            } else {
                var generated = "$prefix-${(100..999).random()}"
                for (attempt in 1..8) {
                    val dupSnap = db.collection(COLLECTION_USERS)
                        .whereEqualTo("userIdCode", generated)
                        .limit(1)
                        .get()
                        .await()
                    if (dupSnap.isEmpty) break
                    generated = if (attempt < 5) {
                        "$prefix-${(100..999).random()}"
                    } else {
                        "$prefix-${(1000..9999).random()}"
                    }
                }
                generated
            }

            val authEmail = if (email.isNotBlank()) {
                email.trim().lowercase()
            } else {
                FirebaseAuthManager.normalizeIdentifierToEmail(userIdCode)
            }
            if (!authEmail.contains("@") || !authEmail.contains(".") || authEmail.length !in 3..160) {
                return Result.failure(Exception("সঠিক ইমেইল ঠিকানা দিন।"))
            }

            val primaryApp = auth.app
            val appContext = primaryApp.applicationContext
            val existingSecondary = FirebaseApp.getApps(appContext)
                .firstOrNull { it.name == SECONDARY_PROVISIONER_APP_NAME }
            val secondaryApp = existingSecondary ?: FirebaseApp.initializeApp(
                appContext,
                primaryApp.options,
                SECONDARY_PROVISIONER_APP_NAME
            ).also { createdApp ->
                val isEmulator = primaryApp.options.apiKey == "fake-api-key-for-emulator"
                if (!isEmulator) {
                    configureAppCheckForSecondaryApp(appContext, primaryApp, createdApp)
                }
                val createdAuth = FirebaseAuth.getInstance(createdApp)
                if (isEmulator) {
                    createdAuth.useEmulator("127.0.0.1", 9099)
                }
            }
            val secondaryAuth = FirebaseAuth.getInstance(secondaryApp)
            runCatching { secondaryAuth.signOut() }

            try {
                val authResult = secondaryAuth.createUserWithEmailAndPassword(authEmail, initialPass).await()
                val newAuthUser = authResult.user
                    ?: return Result.failure(Exception("Firebase Auth অ্যাকাউন্ট তৈরি ব্যর্থ হয়েছে।"))
                val newUid = newAuthUser.uid

                runCatching {
                    val profileReq = UserProfileChangeRequest.Builder()
                        .setDisplayName(cleanName)
                        .build()
                    newAuthUser.updateProfile(profileReq).await()
                }

                val isAdminRole = role == UserRole.SECONDARY_SUPER_ADMIN
                val safeTarget = if (monthlyTarget.isFinite() && monthlyTarget >= 0.0) monthlyTarget else 50000.0
                val nowMillis = System.currentTimeMillis()
                val serverNow = FieldValue.serverTimestamp()

                val userDoc = mapOf(
                    "uid" to newUid,
                    "userIdCode" to userIdCode,
                    "email" to authEmail,
                    "fullName" to cleanName,
                    "phone" to cleanPhone,
                    "role" to role.name,
                    "status" to AccountStatus.ACTIVE.name,
                    "isActive" to true,
                    "mustChangePasswordOnFirstLogin" to true,
                    "monthlySalesTarget" to safeTarget,
                    "createdAt" to serverNow,
                    "updatedAt" to serverNow
                )
                val defaultPerms = if (isAdminRole) {
                    UserPermissions.adminPermissions(newUid)
                } else {
                    UserPermissions.defaultUserPermissions(newUid)
                }
                val permsMap = buildPermissionsMap(defaultPerms)
                val targetMap = mapOf(
                    "userId" to newUid,
                    "period" to TargetPeriod.MONTHLY.name,
                    "targetAmount" to safeTarget,
                    "startDate" to nowMillis,
                    "endDate" to (nowMillis + 30L * 86400000L),
                    "createdAt" to serverNow,
                    "updatedAt" to serverNow
                )
                val actorName = adminProfile.fullName.ifBlank { "Super Admin" }.take(120)
                val auditMap = mapOf(
                    "action" to "User Created",
                    "performedBy" to adminUid,
                    "performedByName" to actorName,
                    "targetUserId" to newUid,
                    "details" to "Created ${role.name} account $cleanName ($userIdCode / $authEmail)".take(500),
                    "timestampMillis" to nowMillis,
                    "createdAt" to serverNow
                )

                val batch = db.batch()
                batch.set(db.collection(COLLECTION_USERS).document(newUid), userDoc)
                batch.set(db.collection(COLLECTION_PERMISSIONS).document(newUid), permsMap)
                batch.set(db.collection(COLLECTION_TARGETS).document("target_$newUid"), targetMap)
                batch.set(db.collection(COLLECTION_AUDIT_LOGS).document(), auditMap)
                if (isAdminRole) {
                    batch.set(
                        db.collection(COLLECTION_ADMIN_SLOTS).document(DOC_SECONDARY_ADMIN_SLOT),
                        mapOf("uid" to newUid, "createdAt" to serverNow)
                    )
                }
                if (authEmail != FirebaseAuthManager.normalizeIdentifierToEmail(userIdCode)) {
                    batch.set(
                        db.collection(COLLECTION_LOGIN_DIRECTORY).document(userIdCode),
                        mapOf("email" to authEmail, "updatedAt" to serverNow)
                    )
                }

                try {
                    batch.commit().await()
                } catch (fsErr: Exception) {
                    // Roll back orphaned Firebase Auth user if Firestore persistence fails
                    runCatching { newAuthUser.delete().await() }
                    throw fsErr
                }

                Result.success(
                    UserProfile(
                        id = newUid,
                        uid = newUid,
                        userIdCode = userIdCode,
                        email = authEmail,
                        fullName = cleanName,
                        phone = cleanPhone,
                        role = role,
                        status = AccountStatus.ACTIVE,
                        isActive = true,
                        mustChangePasswordOnFirstLogin = true,
                        monthlySalesTarget = safeTarget
                    )
                )
            } finally {
                runCatching { secondaryAuth.signOut() }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: FirebaseAuthUserCollisionException) {
            Result.failure(Exception("এই ইমেইল বা ইউজার আইডি আগে থেকেই Firebase Authentication-এ নিবন্ধিত রয়েছে।"))
        } catch (e: FirebaseAuthWeakPasswordException) {
            Result.failure(Exception("পাসওয়ার্ডটি অত্যন্ত দুর্বল। কমপক্ষে ৬ অক্ষরের শক্তিশালী পাসওয়ার্ড দিন।"))
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            Result.failure(Exception("ইমেইল ঠিকানা সঠিক নয়।"))
        } catch (e: Exception) {
            Log.e(TAG, "Secondary FirebaseApp user provisioning failed", e)
            val msg = e.localizedMessage ?: "ইউজার তৈরি ব্যর্থ হয়েছে"
            val friendly = when {
                msg.contains("App Check", ignoreCase = true) ||
                msg.contains("appcheck", ignoreCase = true) ->
                    "Firebase Console → App Check-এ Authentication এবং Firestore 'Unenforced' করুন।"
                msg.contains("PERMISSION_DENIED", ignoreCase = true) ->
                    "Firestore নিরাপত্তা নিয়ম অনুযায়ী অনুমতি পাওয়া যায়নি।"
                else -> msg
            }
            Result.failure(Exception(friendly))
        }
    }

    suspend fun setUserAccountStatus(targetUid: String, newStatus: AccountStatus): Result<Unit> = withContext(ioDispatcher) {
        val target = _users.value.find { it.uid == targetUid || it.id == targetUid }
        if (target?.role == UserRole.PRIMARY_SUPER_ADMIN) {
            return@withContext Result.failure(Exception("প্রাইমারি সুপার অ্যাডমিনের স্ট্যাটাস পরিবর্তন করা যাবে না!"))
        }

        return@withContext try {
            functions.getHttpsCallable("updateUserAccountStatus")
                .call(mapOf("targetUid" to targetUid, "status" to newStatus.name))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val code = (e as? FirebaseFunctionsException)?.code
            if (code == FirebaseFunctionsException.Code.NOT_FOUND || code == FirebaseFunctionsException.Code.UNAVAILABLE) {
                val docRef = db.collection(COLLECTION_USERS).document(targetUid)
                try {
                    val isActive = newStatus == AccountStatus.ACTIVE
                    docRef.update(
                        mapOf(
                            "status" to newStatus.name,
                            "isActive" to isActive,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                    val actor = _currentUser.value
                    if (actor != null) {
                        logAuditInternal(
                            "User Status: ${newStatus.name}",
                            actor.uid,
                            actor.fullName,
                            targetUid,
                            "Updated account status of ${target?.userIdCode ?: targetUid} to ${newStatus.name}"
                        )
                    }
                    Result.success(Unit)
                } catch (fsErr: Exception) {
                    handleFirestoreError(fsErr, OperationType.UPDATE, docRef.path, auth)
                    Result.failure(fsErr)
                }
            } else {
                Result.failure(Exception(formatFunctionsError(e, "স্ট্যাটাস আপডেট ব্যর্থ")))
            }
        }
    }

    suspend fun toggleUserActive(userId: String): Result<Unit> {
        val target = _users.value.find { it.uid == userId || it.id == userId }
            ?: return Result.failure(Exception("ইউজার পাওয়া যায়নি!"))
        val nextStatus = if (target.isActive && target.status == AccountStatus.ACTIVE) {
            AccountStatus.DEACTIVATED
        } else {
            AccountStatus.ACTIVE
        }
        return setUserAccountStatus(userId, nextStatus)
    }

    suspend fun deleteUser(userId: String): Result<Boolean> = withContext(ioDispatcher) {
        val targetUser = _users.value.find { it.uid == userId || it.id == userId }
        if (targetUser?.role == UserRole.PRIMARY_SUPER_ADMIN) {
            return@withContext Result.failure(Exception("প্রাইমারি সুপার এডমিন একাউন্ট মুছে ফেলা যাবে না!"))
        }
        if (_currentUser.value?.uid == userId || auth.currentUser?.uid == userId) {
            return@withContext Result.failure(Exception("নিজের একাউন্ট মুছে ফেলা যাবে না!"))
        }

        return@withContext try {
            functions.getHttpsCallable("deleteManagedUser")
                .call(mapOf("targetUid" to userId))
                .await()
            Result.success(true)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val code = (e as? FirebaseFunctionsException)?.code
            val isEmulator = auth.app.options.apiKey == "fake-api-key-for-emulator"
            val hasConnectFailure = generateSequence<Throwable>(e) { it.cause }
                .any { it is java.net.ConnectException }
            val shouldUseSparkFallback = code == FirebaseFunctionsException.Code.NOT_FOUND ||
                code == FirebaseFunctionsException.Code.UNAVAILABLE ||
                code == FirebaseFunctionsException.Code.UNIMPLEMENTED ||
                hasConnectFailure ||
                (isEmulator && code !in setOf(
                    FirebaseFunctionsException.Code.PERMISSION_DENIED,
                    FirebaseFunctionsException.Code.INVALID_ARGUMENT,
                    FirebaseFunctionsException.Code.FAILED_PRECONDITION
                ))
            if (shouldUseSparkFallback) {
                try {
                    val batch = db.batch()
                    batch.delete(db.collection(COLLECTION_USERS).document(userId))
                    batch.delete(db.collection(COLLECTION_PERMISSIONS).document(userId))
                    batch.delete(db.collection(COLLECTION_TARGETS).document("target_$userId"))
                    if (!targetUser?.userIdCode.isNullOrBlank()) {
                        batch.delete(db.collection(COLLECTION_LOGIN_DIRECTORY).document(targetUser!!.userIdCode))
                    }
                    val actor = _currentUser.value
                    if (actor != null) {
                        val auditRef = db.collection(COLLECTION_AUDIT_LOGS).document()
                        batch.set(
                            auditRef,
                            mapOf(
                                "action" to "User Deleted",
                                "performedBy" to actor.uid,
                                "performedByName" to actor.fullName,
                                "targetUserId" to userId,
                                "details" to "Deleted user ${targetUser?.fullName ?: userId} (${targetUser?.userIdCode ?: userId})".take(500),
                                "timestampMillis" to System.currentTimeMillis(),
                                "createdAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                    batch.commit().await()
                    Result.success(true)
                } catch (fsErr: Exception) {
                    handleFirestoreError(fsErr, OperationType.WRITE, COLLECTION_USERS, auth)
                    Result.failure(Exception(formatFunctionsError(e, "ইউজার ডিলিট ব্যর্থ: ${fsErr.localizedMessage}")))
                }
            } else {
                Result.failure(Exception(formatFunctionsError(e, "ইউজার ডিলিট ব্যর্থ")))
            }
        }
    }

    suspend fun changeUserPassword(newPass: String): Result<Boolean> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid
            ?: return@withContext Result.failure(Exception("ইউজার লগইন করা নেই!"))
        val authRes = authManager.updateCurrentUserPassword(newPass)
        if (authRes.isFailure) {
            return@withContext Result.failure(
                authRes.exceptionOrNull() ?: Exception("পাসওয়ার্ড পরিবর্তন ব্যর্থ হয়েছে")
            )
        }

        val docRef = db.collection(COLLECTION_USERS).document(uid)
        return@withContext try {
            docRef.update(
                mapOf(
                    "mustChangePasswordOnFirstLogin" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            val actor = _currentUser.value
            if (actor != null) {
                logAuditInternal("Password Changed", uid, actor.fullName, uid, "User changed own password")
            }
            Result.success(true)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun updateUserName(userId: String, newName: String): Result<Boolean> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_USERS).document(userId)
        return@withContext try {
            docRef.update(
                mapOf(
                    "fullName" to newName.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(true)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun savePermissions(permissions: UserPermissions): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_PERMISSIONS).document(permissions.userId)
        return@withContext try {
            docRef.set(buildPermissionsMap(permissions)).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun setSalesTarget(userId: String, period: TargetPeriod, amount: Double): Result<Unit> = withContext(ioDispatcher) {
        val now = System.currentTimeMillis()
        val docRef = db.collection(COLLECTION_TARGETS).document("target_$userId")
        val payload = mapOf(
            "userId" to userId,
            "period" to period.name,
            "targetAmount" to amount,
            "startDate" to now,
            "endDate" to (now + 30L * 86400000L),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return@withContext try {
            docRef.set(payload).await()
            db.collection(COLLECTION_USERS).document(userId)
                .update(
                    mapOf(
                        "monthlySalesTarget" to amount,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    // --- Password Recovery Requests (Admin Approval System) ---

    suspend fun requestPasswordReset(
        identifier: String,
        mobileNumber: String,
        reason: String = "পাসওয়ার্ড ভুলে গেছি"
    ): Result<String> = withContext(ioDispatcher) {
        return@withContext try {
            val res = functions.getHttpsCallable("requestPasswordReset")
                .call(
                    mapOf(
                        "identifier" to identifier.trim(),
                        "mobileNumber" to mobileNumber.trim(),
                        "reason" to reason.trim()
                    )
                ).await()
            val data = res.getData() as? Map<*, *>
            val requestId = (data?.get("requestId") as? String) ?: ""
            Result.success(requestId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(Exception(formatFunctionsError(e, "পাসওয়ার্ড রিসেট আবেদন ব্যর্থ")))
        }
    }

    suspend fun approvePasswordReset(requestId: String): Result<String> = withContext(ioDispatcher) {
        return@withContext try {
            val res = functions.getHttpsCallable("approvePasswordReset")
                .call(mapOf("requestId" to requestId))
                .await()
            val data = res.getData() as? Map<*, *>
            val tempPass = (data?.get("tempPassword") as? String)
                ?: return@withContext Result.failure(Exception("Temporary password missing from backend response"))
            Result.success(tempPass)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(Exception(formatFunctionsError(e, "অনুমোদন ব্যর্থ হয়েছে")))
        }
    }

    suspend fun rejectPasswordReset(requestId: String, reason: String = "অ্যাডমিন কর্তৃক প্রত্যাখ্যাত"): Result<Unit> = withContext(ioDispatcher) {
        return@withContext try {
            functions.getHttpsCallable("rejectPasswordReset")
                .call(mapOf("requestId" to requestId, "rejectionReason" to reason))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val code = (e as? FirebaseFunctionsException)?.code
            if (code == FirebaseFunctionsException.Code.NOT_FOUND || code == FirebaseFunctionsException.Code.UNAVAILABLE) {
                val docRef = db.collection(COLLECTION_RESET_REQUESTS).document(requestId)
                try {
                    val admin = _currentUser.value
                    docRef.update(
                        mapOf(
                            "status" to ResetRequestStatus.REJECTED.name,
                            "approvedBy" to (admin?.uid ?: ""),
                            "approvedByName" to (admin?.fullName ?: "Admin"),
                            "rejectionReason" to reason,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                    Result.success(Unit)
                } catch (fsErr: Exception) {
                    handleFirestoreError(fsErr, OperationType.UPDATE, docRef.path, auth)
                    Result.failure(fsErr)
                }
            } else {
                Result.failure(Exception(formatFunctionsError(e, "প্রত্যাখ্যান ব্যর্থ")))
            }
        }
    }

    // --- Courier & Operational Trackers ---

    suspend fun updateSteadfastConfig(apiKey: String, secretKey: String, isSandbox: Boolean): Result<Unit> = withContext(ioDispatcher) {
        val currentUser = _currentUser.value
        if (currentUser == null || !currentUser.role.isAdmin) {
            return@withContext Result.failure(Exception("শুধুমাত্র সুপার অ্যাডমিন কুরিয়ার API সেটিংস পরিবর্তন করতে পারবেন।"))
        }
        val cleanKey = apiKey.trim()
        val cleanSecret = secretKey.trim()
        if (!isSandbox && (cleanKey.isBlank() || cleanSecret.isBlank())) {
            return@withContext Result.failure(Exception("লাইভ মোড চালু করতে API Key এবং Secret Key উভয়ই দিন!"))
        }

        val docRef = db.collection(COLLECTION_ADMIN_SETTINGS).document("steadfast")
        val payload = mapOf(
            "apiKey" to cleanKey,
            "secretKey" to cleanSecret,
            "isSandbox" to isSandbox,
            "isConnected" to true,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return@withContext try {
            docRef.set(payload).await()
            _steadfastConfig.value = SteadfastConfig(
                apiKey = cleanKey,
                secretKey = cleanSecret,
                isSandbox = isSandbox,
                isConnected = true
            )
            runCatching {
                logAuditInternal(
                    "Steadfast Config Updated",
                    currentUser.uid,
                    currentUser.fullName,
                    "",
                    "Updated courier mode to ${if (isSandbox) "SANDBOX" else "LIVE PRODUCTION"}"
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun testSteadfastConnection(): Result<String> {
        return courierService.testConnection(_steadfastConfig.value)
    }

    suspend fun syncShipmentStatus(shipmentId: String): Result<String> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid
            ?: return@withContext Result.failure(IllegalStateException("Not authenticated"))
        val ship = _shipments.value.find { it.id == shipmentId }
            ?: runCatching {
                db.collection(COLLECTION_SHIPMENTS).document(shipmentId).get().await()
                    .toObject(SteadfastShipment::class.java)
            }.getOrNull()
            ?: return@withContext Result.failure(Exception("পার্সেল রেকর্ড পাওয়া যায়নি।"))

        val config = _steadfastConfig.value
        val useSandbox = ship.isSandbox || config.isSandbox || 
            ship.consignmentId.startsWith("SF-", ignoreCase = true) || 
            ship.trackingCode.startsWith("TRK-", ignoreCase = true)
        val statusResult = courierService.fetchLiveStatus(
            consignmentId = ship.consignmentId,
            trackingCode = ship.trackingCode,
            invoiceNumber = ship.invoiceNumber,
            isSandbox = useSandbox,
            config = config,
            currentStatus = ship.status
        )
        val newStatus = statusResult.getOrElse { return@withContext Result.failure(it) }
        val nowMillis = System.currentTimeMillis()
        val shipRef = db.collection(COLLECTION_SHIPMENTS).document(shipmentId)

        return@withContext try {
            shipRef.update(
                mapOf(
                    "status" to newStatus,
                    "lastSyncedMillis" to nowMillis,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val mappedOrderStatus = mapSteadfastStatusToOrderStatus(newStatus)
            val existingOrder = _orders.value.find { it.id == ship.orderId }
            val isAdmin = _currentUser.value?.role?.isAdmin == true
            val canUserUpdateOrder = existingOrder != null &&
                existingOrder.userId == uid &&
                existingOrder.status != OrderStatus.DELIVERED &&
                existingOrder.status != OrderStatus.CANCELLED
            if (ship.orderId.isNotBlank() &&
                mappedOrderStatus != null &&
                existingOrder != null &&
                existingOrder.status != mappedOrderStatus &&
                (isAdmin || canUserUpdateOrder)
            ) {
                updateOrderStatus(ship.orderId, mappedOrderStatus)
            }

            Result.success(newStatus)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, shipRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun syncAllShipmentsStatus(): Result<String> = withContext(ioDispatcher) {
        if (auth.currentUser == null) {
            return@withContext Result.failure(IllegalStateException("Not authenticated"))
        }
        val allShipments = _shipments.value
        if (allShipments.isEmpty()) {
            return@withContext Result.success(
                "কোনো কুরিয়ার পার্সেল পাওয়া যায়নি। Orders ট্যাব থেকে পার্সেল পাঠান অথবা Consignment ID দিয়ে লাইভ ট্র্যাক করুন।"
            )
        }
        val config = _steadfastConfig.value
        val hasLiveTargets = allShipments.any { !it.isSandbox }
        if (!config.isSandbox && hasLiveTargets && (config.apiKey.isBlank() || config.secretKey.isBlank())) {
            return@withContext Result.failure(IllegalStateException("লাইভ আপডেটের জন্য API Key ও Secret Key দিন!"))
        }

        val activeTargets = allShipments.filter { !isFinalSteadfastStatus(it.status) }
        val targets = if (activeTargets.isNotEmpty()) activeTargets else allShipments

        val latestStatusById = allShipments.associate { it.id to it.status }.toMutableMap()
        var syncedCount = 0
        var failedCount = 0
        var lastErrorMsg: String? = null

        for (ship in targets) {
            val res = syncShipmentStatus(ship.id)
            res.onSuccess { updatedStatus ->
                latestStatusById[ship.id] = updatedStatus
                syncedCount++
            }.onFailure { err ->
                failedCount++
                lastErrorMsg = err.message
            }
        }

        if (syncedCount == 0 && failedCount > 0) {
            return@withContext Result.failure(
                Exception(lastErrorMsg ?: "পার্সেল স্ট্যাটাস আপডেট করা যায়নি।")
            )
        }

        val pendingCount = latestStatusById.values.count { isSteadfastPending(it) }
        val inTransitCount = latestStatusById.values.count { isSteadfastInTransit(it) }
        val deliveredCount = latestStatusById.values.count { isSteadfastDelivered(it) }
        val cancelledCount = latestStatusById.values.count { isSteadfastCancelledOrReturned(it) }

        val summary = buildString {
            append("লাইভ আপডেট সম্পন্ন ($syncedCount/${targets.size}) — ")
            append("Pending: $pendingCount • In Transit: $inTransitCount • Delivered: $deliveredCount")
            if (cancelledCount > 0) append(" • Return/Cancel: $cancelledCount")
            if (failedCount > 0) append(" • ব্যর্থ: $failedCount")
        }
        Result.success(summary)
    }

    suspend fun trackSteadfastParcelDirect(code: String): Result<String> = withContext(ioDispatcher) {
        val clean = code.trim()
        if (clean.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Consignment ID, Tracking Code বা Invoice লিখুন!"))
        }
        val matched = _shipments.value.find {
            it.consignmentId.equals(clean, ignoreCase = true) ||
                it.trackingCode.equals(clean, ignoreCase = true) ||
                it.invoiceNumber.equals(clean, ignoreCase = true)
        }
        if (matched != null) {
            return@withContext syncShipmentStatus(matched.id).map { newStatus ->
                "পার্সেল ${matched.consignmentId} (${matched.invoiceNumber}) বর্তমান স্ট্যাটাস: ${formatSteadfastStatusLabel(newStatus)}"
            }
        }

        val config = _steadfastConfig.value
        val result = courierService.fetchLiveStatus(
            consignmentId = clean,
            trackingCode = clean,
            invoiceNumber = clean,
            isSandbox = config.isSandbox,
            config = config
        )
        result.map { rawStatus ->
            "ট্র্যাকিং ($clean) লাইভ স্ট্যাটাস: ${formatSteadfastStatusLabel(rawStatus)}"
        }
    }

    private fun mapSteadfastStatusToOrderStatus(rawStatus: String): OrderStatus? {
        return when (rawStatus.trim().lowercase()) {
            "in_review", "pending", "hold", "unknown" -> OrderStatus.PENDING
            "in_transit", "shipped", "out_for_delivery" -> OrderStatus.IN_TRANSIT
            "delivered", "partial_delivered", "delivered_approval_pending", "partial_delivered_approval_pending" -> OrderStatus.DELIVERED
            "cancelled", "cancelled_approval_pending" -> OrderStatus.CANCELLED
            "returned" -> OrderStatus.RETURNED
            else -> null
        }
    }

    private fun isFinalSteadfastStatus(status: String): Boolean {
        val s = status.trim().lowercase()
        return s == "delivered" || s == "cancelled" || s == "returned"
    }

    private fun isSteadfastPending(status: String): Boolean {
        return when (status.trim().lowercase()) {
            "in_review", "pending", "hold", "unknown" -> true
            else -> false
        }
    }

    private fun isSteadfastInTransit(status: String): Boolean {
        return when (status.trim().lowercase()) {
            "in_transit", "shipped", "out_for_delivery" -> true
            else -> false
        }
    }

    private fun isSteadfastDelivered(status: String): Boolean {
        return when (status.trim().lowercase()) {
            "delivered", "partial_delivered", "delivered_approval_pending", "partial_delivered_approval_pending" -> true
            else -> false
        }
    }

    private fun isSteadfastCancelledOrReturned(status: String): Boolean {
        return when (status.trim().lowercase()) {
            "cancelled", "cancelled_approval_pending", "returned" -> true
            else -> false
        }
    }

    private fun formatSteadfastStatusLabel(status: String): String {
        return when (status.trim().lowercase()) {
            "in_review" -> "In Review (Pending)"
            "pending" -> "Pending"
            "hold" -> "On Hold (Pending)"
            "in_transit", "shipped", "out_for_delivery" -> "In Transit"
            "delivered", "delivered_approval_pending" -> "Delivered"
            "partial_delivered", "partial_delivered_approval_pending" -> "Partial Delivered"
            "cancelled", "cancelled_approval_pending" -> "Cancelled"
            "returned" -> "Returned"
            else -> status
        }
    }

    suspend fun updatePackaging(info: PackagingTrackingInfo): Result<Unit> = writeTracker(
        docId = "packaging",
        payload = mapOf(
            "trackerType" to "PACKAGING",
            "totalExpense" to info.totalExpense,
            "totalPiecesUsed" to info.totalPiecesUsed,
            "stockRemainingPieces" to info.stockRemainingPieces,
            "perPieceCost" to info.perPieceCost,
            "updatedAt" to FieldValue.serverTimestamp()
        )
    )

    suspend fun updateAdSpend(info: AdSpendInfo): Result<Unit> = writeTracker(
        docId = "ad_spend",
        payload = mapOf(
            "trackerType" to "AD_SPEND",
            "totalDollarsSpent" to info.totalDollarsSpent,
            "dailyBudgetDollars" to info.dailyBudgetDollars,
            "activeAdsCount" to info.activeAdsCount,
            "weeklyBudgetDollars" to info.weeklyBudgetDollars,
            "monthlyBudgetDollars" to info.monthlyBudgetDollars,
            "dollarRateBdt" to info.dollarRateBdt,
            "updatedAt" to FieldValue.serverTimestamp()
        )
    )

    suspend fun updateBoxInfo(info: BoxTrackingInfo): Result<Unit> = writeTracker(
        docId = "box",
        payload = mapOf(
            "trackerType" to "BOX",
            "totalExpense" to info.totalExpense,
            "totalBoxesStock" to info.totalBoxesStock,
            "totalBoxesUsed" to info.totalBoxesUsed,
            "perPieceCost" to info.perPieceCost,
            "updatedAt" to FieldValue.serverTimestamp()
        )
    )

    suspend fun updateStickerInfo(info: StickerTrackingInfo): Result<Unit> = writeTracker(
        docId = "sticker",
        payload = mapOf(
            "trackerType" to "STICKER",
            "totalExpense" to info.totalExpense,
            "totalStickersStock" to info.totalStickersStock,
            "totalStickersUsed" to info.totalStickersUsed,
            "perPieceCost" to info.perPieceCost,
            "updatedAt" to FieldValue.serverTimestamp()
        )
    )

    private suspend fun writeTracker(docId: String, payload: Map<String, Any>): Result<Unit> = withContext(ioDispatcher) {
        val docRef = db.collection(COLLECTION_TRACKERS).document(docId)
        return@withContext try {
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    suspend fun syncWithCloud(): Result<String> = withContext(ioDispatcher) {
        val uid = auth.currentUser?.uid
            ?: return@withContext Result.failure(Exception("সিঙ্ক করতে আগে লগইন করুন!"))
        return@withContext try {
            db.collection(COLLECTION_USERS).document(uid).get().await()
            markSynced()
            Result.success("Firebase Cloud Firestore রিয়েল-টাইম ডেটাবেস সফলভাবে সিঙ্ক হয়েছে (সব ডিভাইস আপডেট)")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "$COLLECTION_USERS/$uid", auth)
            Result.failure(e)
        }
    }

    private suspend fun logAuditInternal(
        action: String,
        performedBy: String,
        performedByName: String,
        targetUserId: String,
        details: String
    ) {
        val logRef = db.collection(COLLECTION_AUDIT_LOGS).document()
        val payload = mapOf(
            "action" to action,
            "performedBy" to performedBy,
            "performedByName" to performedByName,
            "targetUserId" to targetUserId,
            "details" to details,
            "timestampMillis" to System.currentTimeMillis(),
            "createdAt" to FieldValue.serverTimestamp()
        )
        runCatching { logRef.set(payload).await() }
            .onFailure { handleFirestoreError(it, OperationType.CREATE, logRef.path, auth) }
    }

    private fun buildPermissionsMap(p: UserPermissions): Map<String, Any> = mapOf(
        "userId" to p.userId,
        "canViewDashboard" to p.canViewDashboard,
        "canViewTotalSales" to p.canViewTotalSales,
        "canViewTotalCost" to p.canViewTotalCost,
        "canViewTotalProfit" to p.canViewTotalProfit,
        "canViewOrders" to p.canViewOrders,
        "canCreateOrders" to p.canCreateOrders,
        "canEditOrders" to p.canEditOrders,
        "canDeleteOrders" to p.canDeleteOrders,
        "canViewCustomers" to p.canViewCustomers,
        "canAddCustomers" to p.canAddCustomers,
        "canViewIncome" to p.canViewIncome,
        "canAddIncome" to p.canAddIncome,
        "canViewExpenses" to p.canViewExpenses,
        "canAddExpenses" to p.canAddExpenses,
        "canViewCourier" to p.canViewCourier,
        "canCreateCourierOrders" to p.canCreateCourierOrders,
        "canViewReturnOrders" to p.canViewReturnOrders,
        "canViewReports" to p.canViewReports,
        "canExportReports" to p.canExportReports,
        "updatedAt" to FieldValue.serverTimestamp()
    )

    private fun formatFunctionsError(e: Exception, fallback: String): String {
        val fn = e as? FirebaseFunctionsException
        return when (fn?.code) {
            FirebaseFunctionsException.Code.NOT_FOUND,
            FirebaseFunctionsException.Code.UNAVAILABLE ->
                "Firebase Cloud Functions এখনো ডিপ্লয় করা হয়নি। অনুগ্রহ করে `firebase deploy --only functions` চালান।"
            else -> fn?.message ?: e.localizedMessage ?: fallback
        }
    }
}
