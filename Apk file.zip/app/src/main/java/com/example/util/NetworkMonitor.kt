package com.example.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ConnectionType(val labelBn: String, val labelEn: String) {
    CELLULAR("মোবাইল ডাটা লাইভ (Online)", "Mobile Data (Online)"),
    WIFI("ওয়াই-ফাই লাইভ (Online)", "Wi-Fi (Online)"),
    OFFLINE("ইন্টারনেট সংযোগ নেই (Offline)", "No Internet (Offline)")
}

class NetworkMonitor(context: Context) {
    private val connectivityManager: ConnectivityManager? = try {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    } catch (e: Exception) {
        null
    }

    private val _connectionType = MutableStateFlow(checkCurrentConnection())
    val connectionType: StateFlow<ConnectionType> = _connectionType.asStateFlow()

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _connectionType.value = checkCurrentConnection()
        }

        override fun onLost(network: Network) {
            _connectionType.value = checkCurrentConnection()
        }

        override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities
        ) {
            _connectionType.value = checkCurrentConnection()
        }
    }

    init {
        try {
            val cm = connectivityManager
            if (cm != null) {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(request, networkCallback)
            }
        } catch (e: Exception) {
            _connectionType.value = checkCurrentConnection()
        }
    }

    private fun checkCurrentConnection(): ConnectionType {
        return try {
            val cm = connectivityManager ?: return ConnectionType.CELLULAR
            val activeNetwork = cm.activeNetwork ?: return ConnectionType.CELLULAR
            val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return ConnectionType.CELLULAR
            when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> ConnectionType.CELLULAR
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> ConnectionType.WIFI
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> ConnectionType.CELLULAR
                else -> ConnectionType.OFFLINE
            }
        } catch (e: Exception) {
            ConnectionType.CELLULAR
        }
    }
}
