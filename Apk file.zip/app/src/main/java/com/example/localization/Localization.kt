package com.example.localization

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class AppLanguage {
    BANGLA, ENGLISH
}

val LocalAppLanguage = compositionLocalOf { AppLanguage.BANGLA }

object AppStrings {
    fun get(lang: AppLanguage = AppLanguage.BANGLA): Strings {
        return if (lang == AppLanguage.BANGLA) StringsBn else StringsEn
    }
}

interface Strings {
    val appTitle: String
    val loginTitle: String
    val loginSubtitle: String
    val userIdLabel: String
    val passwordLabel: String
    val loginButton: String
    val quickAdminLogin: String
    val quickUserLogin: String
    val inactiveUserError: String
    val invalidCredentialsError: String
    val logout: String

    // Navigation
    val navDashboard: String
    val navOrders: String
    val navFinance: String
    val navCourier: String
    val navCustomers: String
    val navUsers: String
    val navReturns: String
    val navReports: String
    val navSettings: String

    // Dashboard Stats
    val totalSales: String
    val totalCost: String
    val totalProfit: String
    val totalOrders: String
    val totalUsers: String
    val totalCustomers: String
    val totalIncome: String
    val totalExpenses: String
    val pendingOrders: String
    val deliveredOrders: String
    val cancelledOrders: String
    val returnedOrders: String

    // Target
    val salesTarget: String
    val targetAchieved: String
    val remainingTarget: String
    val achievementRate: String
    val myPerformanceRank: String

    // Filters
    val filterToday: String
    val filterYesterday: String
    val filterLast7Days: String
    val filterThisMonth: String
    val filterLastMonth: String
    val filterAll: String

    // Orders
    val ordersTitle: String
    val createOrder: String
    val invoiceNo: String
    val customerName: String
    val customerPhone: String
    val customerAddress: String
    val productDetails: String
    val productPrice: String
    val deliveryCharge: String
    val discount: String
    val codAmount: String
    val orderStatus: String
    val sendToSteadfast: String

    // Finance
    val netProfitFormula: String
    val addIncome: String
    val addExpense: String
    val recognizedRevenue: String
    val cogsCost: String
    val adCost: String
    val courierCost: String
    val packagingCost: String
    val operationalCost: String

    // Courier
    val steadfastTitle: String
    val sandboxMode: String
    val productionMode: String
    val apiKey: String
    val secretKey: String
    val testConnection: String
    val consignmentId: String
    val trackingCode: String
    val trackParcel: String

    // User Management
    val userManagementTitle: String
    val createUser: String
    val activeStatus: String
    val inactiveStatus: String
    val permissionsTitle: String
    val savePermissions: String
}

object StringsBn : Strings {
    override val appTitle = "সেলসট্র্যাক প্রো"
    override val loginTitle = "ব্যবসায়িক অ্যাকাউন্টে প্রবেশ করুন"
    override val loginSubtitle = "সেলস, অর্ডার এবং আর্থিক ব্যবস্থাপনা প্ল্যাটফর্ম"
    override val userIdLabel = "ইউজার আইডি (যেমন: ADM-001)"
    override val passwordLabel = "পাসওয়ার্ড"
    override val loginButton = "লগইন করুন"
    override val quickAdminLogin = "অ্যাডমিন ডেমো লগইন"
    override val quickUserLogin = "সেলস ইউজার ডেমো লগইন"
    override val inactiveUserError = "অ্যাকাউন্ট নিষ্ক্রিয়! অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।"
    override val invalidCredentialsError = "ভুল ইউজার আইডি বা পাসওয়ার্ড!"
    override val logout = "লগআউট"

    override val navDashboard = "ড্যাশবোর্ড"
    override val navOrders = "অর্ডার"
    override val navFinance = "আয় ও ব্যয়"
    override val navCourier = "কুরিয়ার"
    override val navCustomers = "কাস্টমার"
    override val navUsers = "ইউজার তালিকা"
    override val navReturns = "রিটার্নস"
    override val navReports = "রিপোর্ট"
    override val navSettings = "সেটিংস"

    override val totalSales = "মোট বিক্রি"
    override val totalCost = "পণ্য খরচ"
    override val totalProfit = "নেট প্রফিট"
    override val totalOrders = "মোট অর্ডার"
    override val totalUsers = "মোট কর্মী"
    override val totalCustomers = "কাস্টমার সংখ্যা"
    override val totalIncome = "মোট আয়"
    override val totalExpenses = "মোট ব্যয়"
    override val pendingOrders = "পেন্ডিং অর্ডার"
    override val deliveredOrders = "ডেলিভার্ড অর্ডার"
    override val cancelledOrders = "ক্যানসেলড"
    override val returnedOrders = "রিটার্নড"

    override val salesTarget = "সেলস টার্গেট"
    override val targetAchieved = "অর্জিত বিক্রি"
    override val remainingTarget = "অবশিষ্ট টার্গেট"
    override val achievementRate = "টার্গেট অর্জন"
    override val myPerformanceRank = "পারফরম্যান্স র‍্যাঙ্ক"

    override val filterToday = "আজ"
    override val filterYesterday = "গতকাল"
    override val filterLast7Days = "গত ৭ দিন"
    override val filterThisMonth = "চলতি মাস"
    override val filterLastMonth = "গত মাস"
    override val filterAll = "সব সময়"

    override val ordersTitle = "অর্ডার ব্যবস্থাপনা"
    override val createOrder = "নতুন অর্ডার তৈরি"
    override val invoiceNo = "ইনভয়েস নং"
    override val customerName = "গ্রাহকের নাম"
    override val customerPhone = "ফোন নম্বর"
    override val customerAddress = "ডেলিভারি ঠিকানা"
    override val productDetails = "পণ্যের বিবরণ"
    override val productPrice = "পণ্যের দাম"
    override val deliveryCharge = "ডেলিভারি চার্জ"
    override val discount = "ডিসকাউন্ট"
    override val codAmount = "সিওডি (COD) টাকা"
    override val orderStatus = "অর্ডার স্ট্যাটাস"
    override val sendToSteadfast = "Steadfast কুরিয়ারে বুকিং করুন"

    override val netProfitFormula = "নেট লাভ = ডেলিভার্ড বিক্রয় - মোট খরচ"
    override val addIncome = "নতুন আয় যোগ করুন"
    override val addExpense = "নতুন ব্যয় যোগ করুন"
    override val recognizedRevenue = "ডেলিভার্ড রাজস্ব"
    override val cogsCost = "পণ্য ক্রয়ের খরচ"
    override val adCost = "বিজ্ঞাপন খরচ"
    override val courierCost = "কুরিয়ার খরচ"
    override val packagingCost = "প্যাকেজিং খরচ"
    override val operationalCost = "অফিস ও অন্যান্য ব্যয়"

    override val steadfastTitle = "Steadfast কুরিয়ার ট্র্যাকিং"
    override val sandboxMode = "স্যান্ডবক্স মোড (নিরাপদ ডেমো)"
    override val productionMode = "লাইভ প্রোডাকশন মোড"
    override val apiKey = "মার্চেন্ট API Key"
    override val secretKey = "মার্চেন্ট Secret Key"
    override val testConnection = "কানেকশন টেস্ট করুন"
    override val consignmentId = "কনসাইনমেন্ট আইডি"
    override val trackingCode = "ট্র্যাকিং কোড"
    override val trackParcel = "পার্সেল ট্র্যাক করুন"

    override val userManagementTitle = "ইউজার ও পারমিশন কন্ট্রোল"
    override val createUser = "নতুন ইউজার তৈরি করুন"
    override val activeStatus = "সক্রিয়"
    override val inactiveStatus = "নিষ্ক্রিয়"
    override val permissionsTitle = "ব্যবহারকারীর অনুমতিসমূহ"
    override val savePermissions = "অনুমতি সংরক্ষণ করুন"
}

object StringsEn : Strings {
    override val appTitle = "SalesTrack Pro"
    override val loginTitle = "Sign In to Business Account"
    override val loginSubtitle = "Sales, Order, Finance & Courier Management"
    override val userIdLabel = "User ID (e.g. ADM-001)"
    override val passwordLabel = "Password"
    override val loginButton = "Sign In"
    override val quickAdminLogin = "Quick Admin Demo"
    override val quickUserLogin = "Quick Sales User Demo"
    override val inactiveUserError = "Account is inactive! Please contact Admin."
    override val invalidCredentialsError = "Invalid User ID or Password!"
    override val logout = "Logout"

    override val navDashboard = "Dashboard"
    override val navOrders = "Orders"
    override val navFinance = "Finance"
    override val navCourier = "Courier"
    override val navCustomers = "Customers"
    override val navUsers = "Users"
    override val navReturns = "Returns"
    override val navReports = "Reports"
    override val navSettings = "Settings"

    override val totalSales = "Total Sales"
    override val totalCost = "Product Cost"
    override val totalProfit = "Net Profit"
    override val totalOrders = "Total Orders"
    override val totalUsers = "Staff Members"
    override val totalCustomers = "Customers"
    override val totalIncome = "Total Income"
    override val totalExpenses = "Total Expenses"
    override val pendingOrders = "Pending"
    override val deliveredOrders = "Delivered"
    override val cancelledOrders = "Cancelled"
    override val returnedOrders = "Returned"

    override val salesTarget = "Sales Target"
    override val targetAchieved = "Achieved Sales"
    override val remainingTarget = "Remaining Target"
    override val achievementRate = "Achievement"
    override val myPerformanceRank = "Performance Rank"

    override val filterToday = "Today"
    override val filterYesterday = "Yesterday"
    override val filterLast7Days = "Last 7 Days"
    override val filterThisMonth = "This Month"
    override val filterLastMonth = "Last Month"
    override val filterAll = "All Time"

    override val ordersTitle = "Order Management"
    override val createOrder = "Create Order"
    override val invoiceNo = "Invoice #"
    override val customerName = "Customer Name"
    override val customerPhone = "Phone Number"
    override val customerAddress = "Delivery Address"
    override val productDetails = "Product Details"
    override val productPrice = "Product Price"
    override val deliveryCharge = "Delivery Charge"
    override val discount = "Discount"
    override val codAmount = "COD Amount"
    override val orderStatus = "Order Status"
    override val sendToSteadfast = "Book with Steadfast Courier"

    override val netProfitFormula = "Net Profit = Delivered Revenue - Total Expenses"
    override val addIncome = "Add Income"
    override val addExpense = "Add Expense"
    override val recognizedRevenue = "Delivered Revenue"
    override val cogsCost = "Product Purchase Cost"
    override val adCost = "Advertising Cost"
    override val courierCost = "Courier Cost"
    override val packagingCost = "Packaging Cost"
    override val operationalCost = "Operational Cost"

    override val steadfastTitle = "Steadfast Courier Hub"
    override val sandboxMode = "Sandbox Mode (Safe Demo)"
    override val productionMode = "Live Production Mode"
    override val apiKey = "Merchant API Key"
    override val secretKey = "Merchant Secret Key"
    override val testConnection = "Test Connection"
    override val consignmentId = "Consignment ID"
    override val trackingCode = "Tracking Code"
    override val trackParcel = "Track Parcel"

    override val userManagementTitle = "User & Permission Control"
    override val createUser = "Create New User"
    override val activeStatus = "Active"
    override val inactiveStatus = "Inactive"
    override val permissionsTitle = "User Permissions"
    override val savePermissions = "Save Permissions"
}
