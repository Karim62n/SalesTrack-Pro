package com.example.courier

import android.util.Log
import com.example.model.SteadfastConfig
import com.example.model.SteadfastShipment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

data class SteadfastCreateOrderRequest(
    val invoice: String,
    val recipient_name: String,
    val recipient_phone: String,
    val recipient_address: String,
    val cod_amount: Double,
    val note: String? = null
)

data class SteadfastOrderResponse(
    val status: Int,
    val message: String,
    val consignment: SteadfastConsignmentData?
)

data class SteadfastConsignmentData(
    val consignment_id: String,
    val invoice: String,
    val tracking_code: String,
    val recipient_name: String,
    val recipient_phone: String,
    val recipient_address: String,
    val cod_amount: Double,
    val status: String
)

class SteadfastCourierService {

    companion object {
        private const val BASE_URL = "https://portal.packzy.com/api/v1"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun createParcel(
        config: SteadfastConfig,
        orderId: String,
        invoice: String,
        recipientName: String,
        recipientPhone: String,
        recipientAddress: String,
        codAmount: Double
    ): Result<SteadfastShipment> {
        if (config.isSandbox) {
            delay(500)
            val rnd = (100000..999999).random()
            val consignmentId = "SF-$rnd"
            val trackingCode = "TRK-${invoice.replace("-", "")}-$rnd"

            val shipment = SteadfastShipment(
                id = UUID.randomUUID().toString(),
                orderId = orderId,
                invoiceNumber = invoice,
                consignmentId = consignmentId,
                trackingCode = trackingCode,
                codAmount = codAmount,
                deliveryCharge = 120.0,
                status = "in_review",
                isSandbox = true,
                lastSyncedMillis = System.currentTimeMillis()
            )
            return Result.success(shipment)
        }

        if (config.apiKey.isBlank() || config.secretKey.isBlank()) {
            return Result.failure(IllegalStateException("লাইভ মোডের জন্য API Key ও Secret Key দিন!"))
        }

        return withContext(Dispatchers.IO) {
            try {
                val payload = JSONObject().apply {
                    put("invoice", invoice)
                    put("recipient_name", recipientName)
                    put("recipient_phone", recipientPhone)
                    put("recipient_address", recipientAddress)
                    put("cod_amount", codAmount)
                    put("note", "SalesTrack Order $invoice")
                }.toString()

                val request = Request.Builder()
                    .url("$BASE_URL/create_order")
                    .header("Api-Key", config.apiKey.trim())
                    .header("Secret-Key", config.secretKey.trim())
                    .header("Content-Type", "application/json")
                    .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(
                            Exception("Steadfast API error (${response.code}): ${extractErrorMessage(raw)}")
                        )
                    }

                    val json = JSONObject(raw)
                    val apiStatus = json.optInt("status", 0)
                    val consignment = json.optJSONObject("consignment")
                    if (apiStatus != 200 || consignment == null) {
                        return@withContext Result.failure(
                            Exception(json.optString("message", "Steadfast order creation failed"))
                        )
                    }

                    val consignmentId = consignment.optString("consignment_id", "")
                    val trackingCode = consignment.optString("tracking_code", "")
                    val status = consignment.optString("status", "in_review")

                    Result.success(
                        SteadfastShipment(
                            id = UUID.randomUUID().toString(),
                            orderId = orderId,
                            invoiceNumber = invoice,
                            consignmentId = consignmentId,
                            trackingCode = trackingCode,
                            codAmount = codAmount,
                            deliveryCharge = 120.0,
                            status = status,
                            isSandbox = false,
                            lastSyncedMillis = System.currentTimeMillis()
                        )
                    )
                }
            } catch (e: Exception) {
                Result.failure(Exception("Steadfast লাইভ সার্ভার সংযোগ ব্যর্থ: ${e.localizedMessage}"))
            }
        }
    }

    suspend fun testConnection(config: SteadfastConfig): Result<String> {
        if (config.isSandbox) {
            delay(400)
            return Result.success("Sandbox API connection is active (Safe Demo Mode).")
        }
        val key = config.apiKey.trim()
        val secret = config.secretKey.trim()
        if (key.length < 8 || secret.length < 8) {
            return Result.failure(IllegalArgumentException("সঠিক API Key ও Secret Key দিন (কমপক্ষে ৮ অক্ষর)।"))
        }

        return withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url("$BASE_URL/get_balance")
                    .header("Api-Key", key)
                    .header("Secret-Key", secret)
                    .header("Content-Type", "application/json")
                    .get()
                    .build()

                client.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(
                            Exception("Steadfast যাচাই ব্যর্থ (${response.code}): ${extractErrorMessage(raw)}")
                        )
                    }
                    val json = JSONObject(raw)
                    val status = json.optInt("status", 0)
                    if (status == 200) {
                        val balance = json.optDouble("current_balance", 0.0)
                        Result.success("Steadfast লাইভ কানেকশন সফল! Current Balance: ৳${String.format("%.2f", balance)}")
                    } else {
                        Result.failure(Exception(json.optString("message", "Invalid Steadfast credentials")))
                    }
                }
            } catch (e: Exception) {
                Result.failure(Exception("Steadfast কানেকশন ত্রুটি: ${e.localizedMessage}"))
            }
        }
    }

    suspend fun syncTrackingStatus(
        consignmentId: String,
        isSandbox: Boolean,
        config: SteadfastConfig = SteadfastConfig(),
        trackingCode: String = "",
        invoiceNumber: String = "",
        currentStatus: String = "in_review"
    ): String {
        return fetchLiveStatus(
            consignmentId = consignmentId,
            trackingCode = trackingCode,
            invoiceNumber = invoiceNumber,
            isSandbox = isSandbox,
            config = config,
            currentStatus = currentStatus
        ).getOrElse { currentStatus }
    }

    suspend fun fetchLiveStatus(
        consignmentId: String,
        trackingCode: String = "",
        invoiceNumber: String = "",
        isSandbox: Boolean,
        config: SteadfastConfig,
        currentStatus: String = "in_review"
    ): Result<String> {
        val effectiveSandbox = isSandbox || 
            consignmentId.startsWith("SF-", ignoreCase = true) || 
            trackingCode.startsWith("TRK-", ignoreCase = true) ||
            consignmentId.isBlank()

        if (effectiveSandbox) {
            delay(300)
            val next = when (currentStatus.lowercase()) {
                "in_review" -> "pending"
                "pending" -> "in_transit"
                "in_transit" -> "delivered"
                else -> currentStatus.ifBlank { "in_review" }
            }
            return Result.success(next)
        }

        val key = config.apiKey.trim()
        val secret = config.secretKey.trim()
        if (key.isBlank() || secret.isBlank()) {
            return Result.failure(IllegalStateException("লাইভ ট্র্যাকিংয়ের জন্য API Key ও Secret Key দিন!"))
        }

        return withContext(Dispatchers.IO) {
            val endpoints = buildList {
                if (consignmentId.isNotBlank()) add("$BASE_URL/status_by_cid/${consignmentId.trim()}")
                if (trackingCode.isNotBlank()) add("$BASE_URL/status_by_trackingcode/${trackingCode.trim()}")
                if (invoiceNumber.isNotBlank()) add("$BASE_URL/status_by_invoice/${invoiceNumber.trim()}")
            }
            if (endpoints.isEmpty()) {
                return@withContext Result.failure(IllegalArgumentException("Consignment ID, Tracking Code বা Invoice দিন!"))
            }

            var lastError = "পার্সেল স্ট্যাটাস পাওয়া যায়নি।"
            for (url in endpoints) {
                try {
                    val request = Request.Builder()
                        .url(url)
                        .header("Api-Key", key)
                        .header("Secret-Key", secret)
                        .header("Content-Type", "application/json")
                        .get()
                        .build()

                    client.newCall(request).execute().use { response ->
                        val raw = response.body?.string().orEmpty()
                        if (response.isSuccessful) {
                            val json = JSONObject(raw)
                            val deliveryStatus = json.optString("delivery_status", "")
                            if (deliveryStatus.isNotBlank()) {
                                return@withContext Result.success(deliveryStatus.lowercase())
                            }
                            lastError = json.optString("message").ifBlank { "Empty delivery_status" }
                        } else {
                            val code = response.code
                            if (code == 401 || code == 403 || code == 404) {
                                Log.w("SteadfastApi", "Live status fetch returned HTTP $code for $url; falling back to current status.")
                                return@withContext Result.success(currentStatus.ifBlank { "in_review" })
                            }
                            lastError = "HTTP ${code}: ${extractErrorMessage(raw)}"
                        }
                    }
                } catch (e: Exception) {
                    lastError = e.localizedMessage ?: "Network error"
                }
            }
            Result.failure(Exception(lastError))
        }
    }

    private fun extractErrorMessage(rawBody: String): String {
        return try {
            val json = JSONObject(rawBody)
            json.optString("message").ifBlank { rawBody.take(120) }
        } catch (_: Exception) {
            rawBody.ifBlank { "Unauthorized or network error" }.take(120)
        }
    }
}
