package com.example.auth

import androidx.annotation.Keep
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.firebase.components.Component
import com.google.firebase.components.ComponentRegistrar
import com.google.firebase.iid.internal.FirebaseInstanceIdInternal

/**
 * Satisfies FirebaseFunctions' internal [FirebaseInstanceIdInternal] provider requirement
 * without bundling legacy `firebase-iid`, preventing unnecessary Play Services C2DM/IID
 * registration calls (`TOO_MANY_REGISTRATIONS`) on emulators and devices.
 */
@Keep
class NoOpInstanceIdRegistrar : ComponentRegistrar {
    override fun getComponents(): List<Component<*>> = listOf(
        Component.builder(FirebaseInstanceIdInternal::class.java)
            .factory { NoOpInstanceIdInternal }
            .build()
    )

    private object NoOpInstanceIdInternal : FirebaseInstanceIdInternal {
        override fun getId(): String = ""

        override fun getToken(): String? = null

        @Suppress("UNCHECKED_CAST")
        override fun getTokenTask(): Task<String> = Tasks.forResult<String?>(null) as Task<String>

        override fun deleteToken(senderId: String, scope: String) = Unit

        override fun addNewTokenListener(listener: FirebaseInstanceIdInternal.NewTokenListener) = Unit
    }
}
