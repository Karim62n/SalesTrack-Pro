package com.example.auth

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirebaseAuthManager(
    private val auth: FirebaseAuth
) {
    companion object {
        private const val TAG = "FirebaseAuthManager"
        const val DEFAULT_EMAIL_DOMAIN = "salestrack.app"
        private val EMAIL_FORMAT_REGEX = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")

        fun normalizeIdentifierToEmail(identifier: String): String {
            val trimmed = identifier.trim()
            if (trimmed.isBlank()) return ""
            if (trimmed.contains("@")) return trimmed.lowercase()
            val safeCode = trimmed.lowercase().replace(Regex("[^a-z0-9._-]"), "")
            return "$safeCode@$DEFAULT_EMAIL_DOMAIN"
        }
    }

    fun authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun signInWithIdentifierAndPassword(
        identifier: String,
        password: String
    ): Result<FirebaseUser> {
        val email = normalizeIdentifierToEmail(identifier)
        return signInWithEmail(email, password)
    }

    suspend fun signInWithEmail(
        email: String,
        password: String
    ): Result<FirebaseUser> {
        val normalized = email.trim().lowercase()
        if (normalized.isBlank() || password.isBlank()) {
            return Result.failure(IllegalArgumentException("ইউজার আইডি/ইমেইল এবং পাসওয়ার্ড দিন!"))
        }
        if (!EMAIL_FORMAT_REGEX.matches(normalized)) {
            return Result.failure(IllegalArgumentException("সঠিক ইমেইল বা ইউজার আইডি দিন!"))
        }
        return try {
            val result = auth.signInWithEmailAndPassword(normalized, password).await()
            val user = result.user ?: return Result.failure(IllegalStateException("Authentication returned null user"))
            Result.success(user)
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            Log.w(TAG, "Invalid credentials for $normalized: ${e.message}")
            Result.failure(e)
        } catch (e: FirebaseAuthInvalidUserException) {
            Log.w(TAG, "Account not found/disabled for $normalized: ${e.message}")
            Result.failure(e)
        } catch (e: Exception) {
            Log.e(TAG, "Email/Password sign-in failed for $normalized", e)
            Result.failure(e)
        }
    }

    suspend fun signInWithGoogle(activityContext: Context): Result<FirebaseUser> {
        return try {
            val webClientId = activityContext.getString(R.string.default_web_client_id)
            val googleIdOption = GetSignInWithGoogleOption.Builder(webClientId).build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()
            val credentialManager = CredentialManager.create(activityContext)
            val result = credentialManager.getCredential(
                request = request,
                context = activityContext
            )
            val credential = result.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val firebaseCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
                val authResult = auth.signInWithCredential(firebaseCredential).await()
                val user = authResult.user ?: return Result.failure(IllegalStateException("Google Sign-In returned null user"))
                Result.success(user)
            } else {
                Result.failure(IllegalStateException("Unsupported credential type returned"))
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google Sign-In cancelled by user or credential provider unavailable", e)
            Result.failure(Exception("Google সাইন-ইন বাতিল হয়েছে। অনুগ্রহ করে অনুমোদিত Google অ্যাকাউন্ট নির্বাচন করুন।"))
        } catch (e: Exception) {
            Log.e(TAG, "Google Sign-In failed", e)
            Result.failure(e)
        }
    }

    suspend fun updateCurrentUserPassword(newPassword: String): Result<Unit> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("কোনো ইউজার লগইন করা নেই!"))
        return try {
            val hasPasswordProvider = user.providerData.any { it.providerId == EmailAuthProvider.PROVIDER_ID }
            val userEmail = user.email
            if (!hasPasswordProvider && !userEmail.isNullOrBlank()) {
                val cred = EmailAuthProvider.getCredential(userEmail, newPassword)
                user.linkWithCredential(cred).await()
            } else {
                user.updatePassword(newPassword).await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Password update failed", e)
            Result.failure(e)
        }
    }

    suspend fun signOut(context: Context? = null) {
        withContext(NonCancellable) {
            auth.signOut()
            if (context != null) {
                runCatching {
                    CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
                }.onFailure {
                    Log.w(TAG, "Failed to clear credential state", it)
                }
            }
        }
    }
}
