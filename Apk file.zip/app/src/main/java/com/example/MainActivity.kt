package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.configureAppCheck
import com.example.data.BusinessRepository
import com.example.localization.LocalAppLanguage
import com.example.ui.components.AppBottomNav
import com.example.ui.components.AppNavDestination
import com.example.ui.components.AppTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.util.NetworkMonitor
import com.example.viewmodel.MainViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.functions

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            val mainViewModel: MainViewModel = viewModel(
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]) {
                            "APPLICATION_KEY missing"
                        }
                        val databaseId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(databaseId)
                        val repo = BusinessRepository(
                            db = db,
                            auth = Firebase.auth,
                            functions = Firebase.functions
                        )
                        MainViewModel(repo, NetworkMonitor(app))
                    }
                }
            )

            val activityContext = LocalContext.current
            val authInitializing by mainViewModel.authInitializing.collectAsState()
            val currentLanguage by mainViewModel.currentLanguage.collectAsState()
            val currentUser by mainViewModel.currentUser.collectAsState()
            val strings by mainViewModel.strings.collectAsState()
            val actionMessage by mainViewModel.actionMessage.collectAsState()
            val connectionType by mainViewModel.connectionType.collectAsState()

            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(actionMessage) {
                actionMessage?.let {
                    snackbarHostState.showSnackbar(it)
                    mainViewModel.clearActionMessage()
                }
            }

            CompositionLocalProvider(LocalAppLanguage provides currentLanguage) {
                SalesTrackTheme {
                    if (authInitializing) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Navy900),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = BlueCyan)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = "Firebase Cloud সেশন যাচাই হচ্ছে...",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    } else if (currentUser == null) {
                        LoginScreen(
                            viewModel = mainViewModel,
                            strings = strings,
                            currentLanguage = currentLanguage
                        )
                    } else {
                        val activeUser = currentUser!!
                        var currentDestination by remember(activeUser.uid) {
                            mutableStateOf(AppNavDestination.DASHBOARD)
                        }
                        val isAdmin = activeUser.role.isAdmin

                        BackHandler(enabled = currentDestination != AppNavDestination.DASHBOARD) {
                            currentDestination = AppNavDestination.DASHBOARD
                        }

                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            topBar = {
                                AppTopBar(
                                    currentUser = activeUser,
                                    currentLanguage = currentLanguage,
                                    connectionType = connectionType,
                                    onSyncCloud = { mainViewModel.syncWithCloud() },
                                    onToggleLanguage = { mainViewModel.toggleLanguage() },
                                    onLogout = { mainViewModel.logout(activityContext) }
                                )
                            },
                            bottomBar = {
                                AppBottomNav(
                                    selectedDestination = currentDestination,
                                    onSelectDestination = { currentDestination = it },
                                    strings = strings,
                                    isAdmin = isAdmin
                                )
                            },
                            snackbarHost = { SnackbarHost(snackbarHostState) }
                        ) { innerPadding ->
                            val modifier = Modifier.padding(innerPadding)
                            when (currentDestination) {
                                AppNavDestination.DASHBOARD -> {
                                    if (isAdmin) {
                                        AdminDashboardScreen(
                                            viewModel = mainViewModel,
                                            strings = strings,
                                            modifier = modifier
                                        )
                                    } else {
                                        UserDashboardScreen(
                                            viewModel = mainViewModel,
                                            strings = strings,
                                            modifier = modifier
                                        )
                                    }
                                }
                                AppNavDestination.ORDERS -> {
                                    OrderManagementScreen(
                                        viewModel = mainViewModel,
                                        strings = strings,
                                        modifier = modifier
                                    )
                                }
                                AppNavDestination.FINANCE -> {
                                    FinanceScreen(
                                        viewModel = mainViewModel,
                                        strings = strings,
                                        modifier = modifier
                                    )
                                }
                                AppNavDestination.COURIER -> {
                                    SteadfastHubScreen(
                                        viewModel = mainViewModel,
                                        strings = strings,
                                        modifier = modifier
                                    )
                                }
                                AppNavDestination.MORE -> {
                                    MoreMenuScreen(
                                        viewModel = mainViewModel,
                                        strings = strings,
                                        modifier = modifier
                                    )
                                }
                            }
                        }

                        if (activeUser.mustChangePasswordOnFirstLogin) {
                            ForcePasswordChangeDialog(
                                user = activeUser,
                                onSavePassword = { newPass, onDone ->
                                    mainViewModel.changePassword(newPass) { success, msg ->
                                        onDone(success, msg ?: "")
                                    }
                                },
                                onLogout = { mainViewModel.logout(activityContext) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ForcePasswordChangeDialog(
    user: com.example.model.UserProfile,
    onSavePassword: (String, (Boolean, String) -> Unit) -> Unit,
    onLogout: () -> Unit
) {
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { /* non-dismissible */ },
        properties = androidx.compose.ui.window.DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        ),
        title = {
            Text(
                text = "🔐 পাসওয়ার্ড পরিবর্তন আবশ্যক",
                fontWeight = FontWeight.Bold,
                color = Slate900
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "হ্যালো ${user.fullName} (${user.userIdCode}), আপনার অ্যাকাউন্টে অস্থায়ী পাসওয়ার্ড কার্যকর রয়েছে। নিরাপত্তার স্বার্থে অবিলম্বে নতুন স্থায়ী পাসওয়ার্ড সেট করুন (কমপক্ষে ৬ অক্ষর)।",
                    fontSize = 12.sp,
                    color = Slate600
                )
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it; errorMsg = null },
                    label = { Text("নতুন পাসওয়ার্ড (New Password)") },
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it; errorMsg = null },
                    label = { Text("পাসওয়ার্ড নিশ্চিত করুন (Confirm Password)") },
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                )

                if (errorMsg != null) {
                    Text(
                        text = errorMsg ?: "",
                        color = LossRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPassword.length < 6) {
                        errorMsg = "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে!"
                        return@Button
                    }
                    if (newPassword != confirmPassword) {
                        errorMsg = "উভয় পাসওয়ার্ড মিলছে না!"
                        return@Button
                    }
                    isSaving = true
                    onSavePassword(newPassword) { success, msg ->
                        isSaving = false
                        if (!success) {
                            errorMsg = msg
                        }
                    }
                },
                enabled = !isSaving,
                colors = ButtonDefaults.buttonColors(containerColor = Navy900)
            ) {
                Text("নতুন পাসওয়ার্ড সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onLogout) {
                Text("লগআউট")
            }
        }
    )
}
