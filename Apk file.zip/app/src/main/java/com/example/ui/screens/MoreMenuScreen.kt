package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Strings
import com.example.model.*
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

enum class SubScreen {
    MENU, USER_MANAGEMENT, PASSWORD_RESETS, AUDIT_LOGS, CUSTOMERS, RETURNS, REPORTS, SETTINGS
}

@Composable
fun MoreMenuScreen(
    viewModel: MainViewModel,
    strings: Strings,
    modifier: Modifier = Modifier
) {
    var activeSubScreen by remember { mutableStateOf(SubScreen.MENU) }

    BackHandler(enabled = activeSubScreen != SubScreen.MENU) {
        activeSubScreen = SubScreen.MENU
    }
    val currentUser by viewModel.currentUser.collectAsState()
    val isAdmin = currentUser?.role?.isAdmin == true
    val passwordResetRequests by viewModel.passwordResetRequests.collectAsState()
    val pendingResetsCount = passwordResetRequests.count { it.status == ResetRequestStatus.PENDING }

    when (activeSubScreen) {
        SubScreen.MENU -> {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(Slate50)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Business Administration & Modules",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Slate900
                )
                Spacer(modifier = Modifier.height(16.dp))

                if (isAdmin) {
                    MenuItemCard(
                        title = strings.userManagementTitle,
                        subtitle = "Primary & Secondary Admins, Sales staff, sales targets & 18 permissions",
                        icon = Icons.Default.AdminPanelSettings,
                        iconColor = Navy900,
                        onClick = { activeSubScreen = SubScreen.USER_MANAGEMENT }
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Password Reset Approval Hub
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        onClick = { activeSubScreen = SubScreen.PASSWORD_RESETS },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("password_resets_menu_card")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(AmberGold.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Password,
                                    contentDescription = null,
                                    tint = AmberGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "পাসওয়ার্ড রিসেট সেন্টার",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Slate900
                                    )
                                    if (pendingResetsCount > 0) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Surface(
                                            color = LossRed,
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                text = "$pendingResetsCount পেন্ডিং",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = "ইউজার রিকোয়েস্ট অনুমোদন ও ওয়ান-টাইম পাসওয়ার্ড প্রদান",
                                    fontSize = 12.sp,
                                    color = Slate600
                                )
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Slate400)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    // Audit Logs
                    MenuItemCard(
                        title = "Security & Audit Logs",
                        subtitle = "লগইন, পাসওয়ার্ড রিসেট, রোল পরিবর্তন ও সিস্টেম হিস্ট্রি ট্র্যাকিং",
                        icon = Icons.Default.Security,
                        iconColor = BlueCyan,
                        onClick = { activeSubScreen = SubScreen.AUDIT_LOGS }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                MenuItemCard(
                    title = "Customer Directory",
                    subtitle = "Client profiles, order history & repeat buyer tags",
                    icon = Icons.Default.Contacts,
                    iconColor = Blue600,
                    onClick = { activeSubScreen = SubScreen.CUSTOMERS }
                )
                Spacer(modifier = Modifier.height(10.dp))

                MenuItemCard(
                    title = "Return Management Center",
                    subtitle = "Customer return approvals, reasons & inventory restocking",
                    icon = Icons.Default.AssignmentReturn,
                    iconColor = LossRed,
                    onClick = { activeSubScreen = SubScreen.RETURNS }
                )
                Spacer(modifier = Modifier.height(10.dp))

                MenuItemCard(
                    title = "Business Reports & Export",
                    subtitle = "Daily, monthly & courier performance reports",
                    icon = Icons.Default.Assessment,
                    iconColor = DeliveredBlue,
                    onClick = { activeSubScreen = SubScreen.REPORTS }
                )
                Spacer(modifier = Modifier.height(10.dp))

                MenuItemCard(
                    title = "System Settings & Language",
                    subtitle = "Bilingual language selector & database connectivity",
                    icon = Icons.Default.Settings,
                    iconColor = Slate700,
                    onClick = { activeSubScreen = SubScreen.SETTINGS }
                )
            }
        }
        SubScreen.USER_MANAGEMENT -> {
            UserManagementView(
                viewModel = viewModel,
                strings = strings,
                onBack = { activeSubScreen = SubScreen.MENU }
            )
        }
        SubScreen.PASSWORD_RESETS -> {
            PasswordResetsView(
                viewModel = viewModel,
                onBack = { activeSubScreen = SubScreen.MENU }
            )
        }
        SubScreen.AUDIT_LOGS -> {
            AuditLogsView(
                viewModel = viewModel,
                onBack = { activeSubScreen = SubScreen.MENU }
            )
        }
        SubScreen.CUSTOMERS -> {
            CustomerDirectoryView(
                viewModel = viewModel,
                onBack = { activeSubScreen = SubScreen.MENU }
            )
        }
        SubScreen.RETURNS -> {
            ReturnManagementView(
                viewModel = viewModel,
                onBack = { activeSubScreen = SubScreen.MENU }
            )
        }
        SubScreen.REPORTS -> {
            ReportsView(
                viewModel = viewModel,
                onBack = { activeSubScreen = SubScreen.MENU }
            )
        }
        SubScreen.SETTINGS -> {
            SettingsView(
                viewModel = viewModel,
                strings = strings,
                onBack = { activeSubScreen = SubScreen.MENU }
            )
        }
    }
}

@Composable
fun MenuItemCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = iconColor.copy(alpha = 0.12f),
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(24.dp))
                }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, color = Slate900, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = subtitle, fontSize = 12.sp, color = Slate600)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Slate400)
        }
    }
}

// --- Subscreen: User Management ---
@Composable
fun UserManagementView(viewModel: MainViewModel, strings: Strings, onBack: () -> Unit) {
    val users by viewModel.users.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val allPermissions by viewModel.allPermissions.collectAsState()
    val isPrimaryAdmin = currentUser?.role == UserRole.PRIMARY_SUPER_ADMIN
    var showCreateUserDialog by remember { mutableStateOf(false) }
    var selectedUserForPerms by remember { mutableStateOf<UserProfile?>(null) }
    var selectedUserForTarget by remember { mutableStateOf<UserProfile?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text(strings.userManagementTitle, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Button(
                onClick = { showCreateUserDialog = true },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                modifier = Modifier.testTag("create_user_button")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add User", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(users, key = { it.uid.ifBlank { it.id } }) { user ->
                val targetUid = user.uid.ifBlank { user.id }
                val isTargetPrimaryAdmin = user.role == UserRole.PRIMARY_SUPER_ADMIN
                val isTargetSecondaryAdmin = user.role == UserRole.SECONDARY_SUPER_ADMIN
                val canManageThisUser = when {
                    isTargetPrimaryAdmin -> false // Primary Admin can NEVER be deactivated/suspended
                    currentUser?.role == UserRole.SECONDARY_SUPER_ADMIN && user.role.isAdmin -> false
                    else -> true
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(user.fullName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Slate900)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    if (isTargetPrimaryAdmin) {
                                        Surface(color = AmberGold.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp)) {
                                            Text("👑 OWNER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AmberGold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                        }
                                    } else if (isTargetSecondaryAdmin) {
                                        Surface(color = DeliveredBlue.copy(alpha = 0.2f), shape = RoundedCornerShape(6.dp)) {
                                            Text("🛡️ SECONDARY ADMIN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DeliveredBlue, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                        }
                                    }
                                }
                                Text("ID: ${user.userIdCode} • ${user.phone}", fontSize = 12.sp, color = Slate600)
                                if (user.email.isNotBlank()) {
                                    Text(user.email, fontSize = 11.sp, color = Slate500)
                                }
                                Text("Target: ৳${user.monthlySalesTarget.toInt()} • Role: ${user.role.displayName}", fontSize = 11.sp, color = Blue600, fontWeight = FontWeight.SemiBold)
                                if (user.mustChangePasswordOnFirstLogin) {
                                    Text("⚠️ প্রথমবার লগইন / পাসওয়ার্ড পরিবর্তন আবশ্যক", fontSize = 10.sp, color = AmberGold, fontWeight = FontWeight.Bold)
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = when (user.status) {
                                    AccountStatus.ACTIVE -> ProfitGreenLight
                                    AccountStatus.DEACTIVATED -> AmberGold.copy(alpha = 0.2f)
                                    AccountStatus.SUSPENDED -> LossRedLight
                                }
                            ) {
                                Text(
                                    text = user.status.labelEn.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (user.status) {
                                        AccountStatus.ACTIVE -> ProfitGreen
                                        AccountStatus.DEACTIVATED -> Slate900
                                        AccountStatus.SUSPENDED -> LossRed
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        if (canManageThisUser) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (user.status != AccountStatus.ACTIVE) {
                                    Button(
                                        onClick = { viewModel.setUserAccountStatus(targetUid, AccountStatus.ACTIVE) },
                                        colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) { Text("Activate", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                }
                                if (user.status != AccountStatus.DEACTIVATED) {
                                    OutlinedButton(
                                        onClick = { viewModel.setUserAccountStatus(targetUid, AccountStatus.DEACTIVATED) },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) { Text("Deactivate", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate800) }
                                }
                                if (user.status != AccountStatus.SUSPENDED) {
                                    Button(
                                        onClick = { viewModel.setUserAccountStatus(targetUid, AccountStatus.SUSPENDED) },
                                        colors = ButtonDefaults.buttonColors(containerColor = LossRed),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) { Text("Suspend", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                }
                            }
                        }

                        if (user.role == UserRole.USER || (isPrimaryAdmin && isTargetSecondaryAdmin)) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { selectedUserForPerms = user },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Permissions", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { selectedUserForTarget = user },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Set Target", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                if (canManageThisUser) {
                                    IconButton(
                                        onClick = { viewModel.deleteUser(targetUid) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete User", tint = LossRed, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateUserDialog) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var customUserIdCode by remember { mutableStateOf("") }
        var pass by remember { mutableStateOf("") }
        var targetText by remember { mutableStateOf("50000") }
        var role by remember { mutableStateOf(UserRole.USER) }
        var createError by remember { mutableStateOf<String?>(null) }
        var isCreating by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isCreating) showCreateUserDialog = false },
            title = { Text("Create New User Account", fontWeight = FontWeight.Bold, color = Slate900) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; createError = null },
                        label = { Text("Full Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it; createError = null },
                        label = { Text("Registered Mobile Number") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                    OutlinedTextField(
                        value = customUserIdCode,
                        onValueChange = { customUserIdCode = it; createError = null },
                        label = { Text("Custom User ID (e.g. USR-105)") },
                        placeholder = { Text("Leave blank for auto ID") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it; createError = null },
                        label = { Text("Email (Optional, auto-mapped if blank)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it; createError = null },
                        label = { Text("Password (min 6 chars)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = targetText,
                        onValueChange = { targetText = it },
                        label = { Text("Monthly Sales Target (৳)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    Text("Account Role:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = role == UserRole.USER, onClick = { role = UserRole.USER })
                        Text("Sales User", color = Slate900)

                        if (isPrimaryAdmin) {
                            Spacer(modifier = Modifier.width(12.dp))
                            RadioButton(selected = role == UserRole.SECONDARY_SUPER_ADMIN, onClick = { role = UserRole.SECONDARY_SUPER_ADMIN })
                            Text("Secondary Admin", color = Slate900)
                        }
                    }
                    if (!isPrimaryAdmin) {
                        Text("ℹ️ শুধুমাত্র Primary Super Admin নতুন Secondary Admin তৈরি করতে পারেন।", fontSize = 11.sp, color = Slate500)
                    }
                    if (createError != null) {
                        Text(createError!!, color = LossRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isBlank() || phone.isBlank() || pass.length < 6) {
                            createError = "নাম, ফোন নম্বর এবং কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন!"
                            return@Button
                        }
                        val target = targetText.toDoubleOrNull() ?: 50000.0
                        isCreating = true
                        createError = null
                        viewModel.createUser(
                            name = name,
                            phone = phone,
                            role = role,
                            pass = pass,
                            customUserIdCode = customUserIdCode.ifBlank { null },
                            monthlyTarget = target,
                            email = email
                        ) { ok, err, _ ->
                            isCreating = false
                            if (ok) {
                                showCreateUserDialog = false
                            } else {
                                createError = err ?: "Account creation failed"
                            }
                        }
                    },
                    enabled = !isCreating,
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text(if (isCreating) "Creating..." else "Create Account") }
            },
            dismissButton = {
                TextButton(
                    onClick = { if (!isCreating) showCreateUserDialog = false },
                    enabled = !isCreating
                ) { Text("Cancel") }
            }
        )
    }

    if (selectedUserForPerms != null) {
        val u = selectedUserForPerms!!
        val targetUid = u.uid.ifBlank { u.id }
        val currentPerms = allPermissions[targetUid] ?: UserPermissions.defaultUserPermissions(targetUid)
        var permsState by remember { mutableStateOf(currentPerms.copy(userId = targetUid)) }

        AlertDialog(
            onDismissRequest = { selectedUserForPerms = null },
            title = { Text("Permissions: ${u.fullName}", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    PermSwitch("View Dashboard", permsState.canViewDashboard) { permsState = permsState.copy(canViewDashboard = it) }
                    PermSwitch("View Total Sales", permsState.canViewTotalSales) { permsState = permsState.copy(canViewTotalSales = it) }
                    PermSwitch("View Total Cost", permsState.canViewTotalCost) { permsState = permsState.copy(canViewTotalCost = it) }
                    PermSwitch("View Total Profit", permsState.canViewTotalProfit) { permsState = permsState.copy(canViewTotalProfit = it) }
                    PermSwitch("অর্ডার তৈরি (Create Orders)", permsState.canCreateOrders) { permsState = permsState.copy(canCreateOrders = it) }
                    PermSwitch("অর্ডার এডিট (Edit Orders)", permsState.canEditOrders) { permsState = permsState.copy(canEditOrders = it) }
                    PermSwitch("অর্ডার ডিলিট (Delete Orders)", permsState.canDeleteOrders) { permsState = permsState.copy(canDeleteOrders = it) }
                    PermSwitch("কাস্টমার দেখা (View Customers)", permsState.canViewCustomers) { permsState = permsState.copy(canViewCustomers = it) }
                    PermSwitch("কাস্টমার যোগ (Add Customers)", permsState.canAddCustomers) { permsState = permsState.copy(canAddCustomers = it) }
                    PermSwitch("আয় দেখা (View Income)", permsState.canViewIncome) { permsState = permsState.copy(canViewIncome = it) }
                    PermSwitch("আয় যোগ (Add Income)", permsState.canAddIncome) { permsState = permsState.copy(canAddIncome = it) }
                    PermSwitch("খরচ দেখা (View Expenses)", permsState.canViewExpenses) { permsState = permsState.copy(canViewExpenses = it) }
                    PermSwitch("খরচ যোগ (Add Expenses)", permsState.canAddExpenses) { permsState = permsState.copy(canAddExpenses = it) }
                    PermSwitch("কুরিয়ার দেখা (View Courier)", permsState.canViewCourier) { permsState = permsState.copy(canViewCourier = it) }
                    PermSwitch("কুরিয়ারে অর্ডার পাঠানো (Send to Courier)", permsState.canCreateCourierOrders) { permsState = permsState.copy(canCreateCourierOrders = it) }
                    PermSwitch("View Return Orders", permsState.canViewReturnOrders) { permsState = permsState.copy(canViewReturnOrders = it) }
                    PermSwitch("View Reports", permsState.canViewReports) { permsState = permsState.copy(canViewReports = it) }
                    PermSwitch("Export Reports", permsState.canExportReports) { permsState = permsState.copy(canExportReports = it) }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.savePermissions(permsState)
                        selectedUserForPerms = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("Save Permissions") }
            },
            dismissButton = { TextButton(onClick = { selectedUserForPerms = null }) { Text("Cancel") } }
        )
    }

    if (selectedUserForTarget != null) {
        val u = selectedUserForTarget!!
        val targetUid = u.uid.ifBlank { u.id }
        var targetAmountText by remember { mutableStateOf(u.monthlySalesTarget.toInt().toString()) }
        AlertDialog(
            onDismissRequest = { selectedUserForTarget = null },
            title = { Text("Set Target: ${u.fullName}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Target Period: Monthly", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = targetAmountText,
                        onValueChange = { targetAmountText = it },
                        label = { Text("Target Amount ৳") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = targetAmountText.toDoubleOrNull() ?: 50000.0
                        viewModel.setSalesTarget(targetUid, TargetPeriod.MONTHLY, amt)
                        selectedUserForTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("Set Target") }
            },
            dismissButton = { TextButton(onClick = { selectedUserForTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun PermSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

// --- Subscreen: Customers ---
@Composable
fun CustomerDirectoryView(viewModel: MainViewModel, onBack: () -> Unit) {
    val customers by viewModel.customers.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isAdmin = currentUser?.role?.isAdmin == true

    var search by remember { mutableStateOf("") }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Customer Directory (${customers.size})", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Slate900)
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text("Search by name or phone...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(12.dp))
        val filtered = if (search.isBlank()) customers else customers.filter {
            it.name.contains(search, ignoreCase = true) || it.phone.contains(search)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { c ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(c.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Slate900)
                            if (c.totalOrders > 1) {
                                Surface(shape = RoundedCornerShape(6.dp), color = ProfitGreenLight) {
                                    Text("REPEAT BUYER", color = ProfitGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                        }
                        Text("Phone: ${c.phone} • City: ${c.city}", fontSize = 12.sp, color = Slate600)
                        Text("Address: ${c.address}", fontSize = 12.sp, color = Slate700)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Orders: ${c.totalOrders} | Delivered: ${c.deliveredOrders} | Returns: ${c.returnedOrders}", fontSize = 11.sp, color = Blue600, fontWeight = FontWeight.SemiBold)

                        if (isAdmin) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { customerToEdit = c },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("সম্পাদনা", fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { customerToDelete = c },
                                    colors = ButtonDefaults.buttonColors(containerColor = LossRed),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ডিলিট", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (customerToEdit != null) {
        val cust = customerToEdit!!
        var editName by remember { mutableStateOf(cust.name) }
        var editPhone by remember { mutableStateOf(cust.phone) }
        var editAddress by remember { mutableStateOf(cust.address) }
        var editCity by remember { mutableStateOf(cust.city) }

        AlertDialog(
            onDismissRequest = { customerToEdit = null },
            title = { Text("কাস্টমার তথ্য সম্পাদনা", fontWeight = FontWeight.Bold, color = Slate900) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Customer Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editPhone, onValueChange = { editPhone = it }, label = { Text("Phone") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editAddress, onValueChange = { editAddress = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editCity, onValueChange = { editCity = it }, label = { Text("City") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateCustomer(cust.copy(name = editName, phone = editPhone, address = editAddress, city = editCity))
                        customerToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("সংরক্ষণ করুন") }
            },
            dismissButton = { TextButton(onClick = { customerToEdit = null }) { Text("বাতিল") } }
        )
    }

    if (customerToDelete != null) {
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = { Text("কাস্টমার মুছে ফেলা", fontWeight = FontWeight.Bold, color = LossRed) },
            text = { Text("আপনি কি নিশ্চিত যে কাস্টমার ${customerToDelete!!.name} মুছে ফেলতে চান?", color = Slate800) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomer(customerToDelete!!.id)
                        customerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LossRed)
                ) { Text("ডিলিট করুন") }
            },
            dismissButton = { TextButton(onClick = { customerToDelete = null }) { Text("বাতিল") } }
        )
    }
}

// --- Subscreen: Returns ---
@Composable
fun ReturnManagementView(viewModel: MainViewModel, onBack: () -> Unit) {
    val returns by viewModel.returns.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isAdmin = currentUser?.role?.isAdmin == true

    var returnToEdit by remember { mutableStateOf<ReturnRecord?>(null) }
    var returnToDelete by remember { mutableStateOf<ReturnRecord?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Return Management Center", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Slate900)
        }
        Spacer(modifier = Modifier.height(12.dp))

        if (returns.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No return records currently logged.", color = Slate600)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(returns, key = { it.id }) { ret ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Invoice: ${ret.invoiceNumber}", fontWeight = FontWeight.Bold, color = Slate900)
                                Surface(shape = RoundedCornerShape(6.dp), color = LossRedLight) {
                                    Text(ret.status, color = LossRed, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                            Text("Customer: ${ret.customerName}", fontSize = 13.sp, color = Slate900)
                            Text("Reason: ${ret.reason}", fontSize = 12.sp, color = Slate700)
                            Text("Product Cost Adjustment: ৳${ret.costAdjustment.toInt()} | Courier Loss: ৳${ret.deliveryChargeLoss.toInt()}", fontSize = 12.sp, color = LossRed, fontWeight = FontWeight.SemiBold)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (ret.status == "Requested") {
                                    Button(
                                        onClick = { viewModel.approveReturn(ret.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Approve & Restock Inventory", fontSize = 12.sp)
                                    }
                                } else {
                                    Spacer(modifier = Modifier.width(1.dp))
                                }

                                if (isAdmin) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedButton(
                                            onClick = { returnToEdit = ret },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(2.dp))
                                            Text("এডিট", fontSize = 11.sp)
                                        }
                                        Button(
                                            onClick = { returnToDelete = ret },
                                            colors = ButtonDefaults.buttonColors(containerColor = LossRed),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(2.dp))
                                            Text("ডিলিট", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (returnToEdit != null) {
        val ret = returnToEdit!!
        var editReason by remember { mutableStateOf(ret.reason) }
        var editCostAdj by remember { mutableStateOf(ret.costAdjustment.toInt().toString()) }
        var editLoss by remember { mutableStateOf(ret.deliveryChargeLoss.toInt().toString()) }

        AlertDialog(
            onDismissRequest = { returnToEdit = null },
            title = { Text("রিটার্ন রেকর্ড এডিট", fontWeight = FontWeight.Bold, color = Slate900) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = editReason, onValueChange = { editReason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editCostAdj, onValueChange = { editCostAdj = it }, label = { Text("Product Cost Adjustment ৳") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = editLoss, onValueChange = { editLoss = it }, label = { Text("Courier Loss ৳") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cost = editCostAdj.toDoubleOrNull() ?: ret.costAdjustment
                        val loss = editLoss.toDoubleOrNull() ?: ret.deliveryChargeLoss
                        viewModel.updateReturnRecord(ret.copy(reason = editReason, costAdjustment = cost, deliveryChargeLoss = loss))
                        returnToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("সংরক্ষণ করুন") }
            },
            dismissButton = { TextButton(onClick = { returnToEdit = null }) { Text("বাতিল") } }
        )
    }

    if (returnToDelete != null) {
        AlertDialog(
            onDismissRequest = { returnToDelete = null },
            title = { Text("রিটার্ন রেকর্ড ডিলিট", fontWeight = FontWeight.Bold, color = LossRed) },
            text = { Text("আপনি কি নিশ্চিত যে এই রিটার্ন রেকর্ডটি মুছে ফেলতে চান?", color = Slate800) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteReturnRecord(returnToDelete!!.id)
                        returnToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LossRed)
                ) { Text("ডিলিট করুন") }
            },
            dismissButton = { TextButton(onClick = { returnToDelete = null }) { Text("বাতিল") } }
        )
    }
}

// --- Subscreen: Reports ---
@Composable
fun ReportsView(viewModel: MainViewModel, onBack: () -> Unit) {
    val metrics by viewModel.dashboardMetrics.collectAsState()
    var exportToast by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Business Reports & Exports", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Slate900)
        }
        Spacer(modifier = Modifier.height(16.dp))

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Monthly Executive Summary", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Slate900)
                Spacer(modifier = Modifier.height(10.dp))
                Text("• Total Orders Recorded: ${metrics.totalOrders}", color = Slate800)
                Text("• Total Delivered Orders: ${metrics.deliveredOrders}", color = Slate800)
                Text("• Gross Recognized Sales: ৳${metrics.totalSales.toInt()}", color = ProfitGreen, fontWeight = FontWeight.Bold)
                Text("• Total Operating & COGS Costs: ৳${metrics.totalCost.toInt()}", color = LossRed, fontWeight = FontWeight.Bold)
                Text("• Net Profit: ৳${metrics.totalProfit.toInt()}", color = if (metrics.totalProfit >= 0) ProfitGreen else LossRed, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { exportToast = "✓ Sales report exported as CSV!" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                    ) {
                        Text("Export CSV")
                    }
                    OutlinedButton(
                        onClick = { exportToast = "✓ Audit statement generated for PDF print!" },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Print PDF")
                    }
                }

                if (exportToast != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(exportToast!!, color = ProfitGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

// --- Subscreen: Settings ---
@Composable
fun SettingsView(viewModel: MainViewModel, strings: Strings, onBack: () -> Unit) {
    val lang by viewModel.currentLanguage.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    var urlCopiedToast by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text(strings.navSettings, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Slate900)
        }
        Spacer(modifier = Modifier.height(16.dp))

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Language & Interface (ভাষা পরিবর্তন)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Slate900)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Primary Language: ${if (lang == com.example.localization.AppLanguage.BANGLA) "বাংলা" else "English"}", color = Slate800)
                    Button(
                        onClick = { viewModel.toggleLanguage() },
                        colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                    ) {
                        Text("Switch to ${if (lang == com.example.localization.AppLanguage.BANGLA) "English" else "বাংলা"}")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Name Change Section
        val currentUser by viewModel.currentUser.collectAsState()
        var newNameInput by remember { mutableStateOf(currentUser?.fullName ?: "") }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Profile Settings (প্রোফাইল সেটিংস)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Slate900)
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = newNameInput,
                    onValueChange = { newNameInput = it },
                    label = { Text("নতুন নাম (New Name)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (newNameInput.isNotBlank()) {
                            viewModel.updateUserName(newNameInput)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("নাম পরিবর্তন করুন")
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Central Firebase Cloud Firestore & Sync Card
        val cloudConfig by viewModel.cloudSyncConfig.collectAsState()
        val connectionType by viewModel.connectionType.collectAsState()
        var showCloudConfigDialog by remember { mutableStateOf(false) }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("সেন্ট্রাল ক্লাউড ও রিয়েল-টাইম সিঙ্ক", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Navy900)
                        Text("সব ডিভাইসে তাৎক্ষণিক ডেটা সিঙ্ক (Firebase Firestore)", fontSize = 12.sp, color = Slate600)
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (cloudConfig.isCloudConnected) ProfitGreenLight else AmberGold.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = if (cloudConfig.isCloudConnected) "LIVE SYNC" else "CONNECTING",
                            color = if (cloudConfig.isCloudConnected) ProfitGreen else Slate900,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("• নেটওয়ার্ক স্ট্যাটাস: ${connectionType.labelBn}", fontSize = 13.sp, color = Slate800, fontWeight = FontWeight.SemiBold)
                Text("• সেন্ট্রাল ডাটাবেস: ${cloudConfig.syncStrategy}", fontSize = 12.sp, color = Slate700)
                Text("• প্রজেক্ট আইডি: ${cloudConfig.projectId}", fontSize = 12.sp, color = Blue600, fontWeight = FontWeight.SemiBold)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "• ক্লাউড সার্ভার URL: ${cloudConfig.serverUrl}",
                        fontSize = 11.sp,
                        color = Slate600,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(cloudConfig.serverUrl))
                            urlCopiedToast = true
                        },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (urlCopiedToast) "কপি হয়েছে!" else "URL Copy", fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.syncWithCloud() },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("সব ডাটা সিঙ্ক করুন", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { showCloudConfigDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ক্লাউড তথ্য", fontSize = 12.sp)
                    }
                }
            }
        }

        if (showCloudConfigDialog) {
            AlertDialog(
                onDismissRequest = { showCloudConfigDialog = false },
                title = { Text("Firebase Cloud Firestore Status", fontWeight = FontWeight.Bold, color = Slate900) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("অ্যাপটি Firebase Authentication, Cloud Firestore এবং Cloud Functions এর সাথে সরাসরি যুক্ত।", fontSize = 12.sp, color = Slate700)
                        Text("Project ID: ${cloudConfig.projectId}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                        Text("Database ID: ${cloudConfig.databaseId}", fontSize = 11.sp, color = Slate600)
                        Text("Security: Zero-trust Firestore Rules + Admin SDK Backend", fontSize = 12.sp, color = ProfitGreen, fontWeight = FontWeight.Bold)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showCloudConfigDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                    ) { Text("ঠিক আছে") }
                }
            )
        }
    }
}

// --- Subscreen: Password Reset Request Approval Center ---
@Composable
fun PasswordResetsView(viewModel: MainViewModel, onBack: () -> Unit) {
    val requests by viewModel.passwordResetRequests.collectAsState()
    var generatedTempPassToShow by remember { mutableStateOf<String?>(null) }
    val dateFormat = remember { java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text("পাসওয়ার্ড রিসেট সেন্টার", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Slate900)
                Text("ইউজার পাসওয়ার্ড রিকোয়েস্ট যাচাই ও অনুমোদন", fontSize = 12.sp, color = Slate600)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (requests.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("কোনো পাসওয়ার্ড রিসেট রিকোয়েস্ট পাওয়া যায়নি।", color = Slate500, fontSize = 14.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(requests, key = { it.id }) { req ->
                    val isPending = req.status == ResetRequestStatus.PENDING

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${req.userFullName} (${req.userIdCode})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Slate900
                                    )
                                    Text(
                                        text = "মোবাইল: ${req.mobileNumber}",
                                        fontSize = 12.sp,
                                        color = Slate600
                                    )
                                    Text(
                                        text = "আবেদনের সময়: ${dateFormat.format(java.util.Date(req.requestTimeMillis))}",
                                        fontSize = 11.sp,
                                        color = Slate500
                                    )
                                }

                                Surface(
                                    color = when (req.status) {
                                        ResetRequestStatus.PENDING -> AmberGold.copy(alpha = 0.15f)
                                        ResetRequestStatus.APPROVED -> ProfitGreenLight
                                        ResetRequestStatus.REJECTED -> LossRed.copy(alpha = 0.15f)
                                        ResetRequestStatus.USED -> Slate200
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = req.status.labelBn,
                                        color = when (req.status) {
                                            ResetRequestStatus.PENDING -> AmberGold
                                            ResetRequestStatus.APPROVED -> ProfitGreen
                                            ResetRequestStatus.REJECTED -> LossRed
                                            ResetRequestStatus.USED -> Slate700
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            if (req.status == ResetRequestStatus.APPROVED) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Surface(
                                    color = Slate100,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "অস্থায়ী পাসওয়ার্ড তৈরি ও প্রদান করা হয়েছে (নিরাপত্তার কারণে ডাটাবেসে সংরক্ষিত নয়)",
                                            fontSize = 11.sp,
                                            color = ProfitGreen,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "অনুমোদক: ${req.approvedByName ?: "Admin"}",
                                            fontSize = 11.sp,
                                            color = Slate500
                                        )
                                    }
                                }
                            }

                            if (isPending) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            viewModel.approvePasswordReset(req.id) { success, tempPass ->
                                                if (success) {
                                                    generatedTempPassToShow = tempPass
                                                }
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("অনুমোদন ও পাসওয়ার্ড তৈরি", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.rejectPasswordReset(req.id) },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LossRed),
                                        modifier = Modifier.weight(0.6f)
                                    ) {
                                        Text("বাতিল", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (generatedTempPassToShow != null) {
        AlertDialog(
            onDismissRequest = { generatedTempPassToShow = null },
            title = {
                Text(
                    text = "✅ অস্থায়ী পাসওয়ার্ড তৈরি হয়েছে",
                    fontWeight = FontWeight.Bold,
                    color = Slate900
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "ইউজারকে লগইন করার জন্য নিচের অস্থায়ী পাসওয়ার্ডটি প্রদান করুন:",
                        fontSize = 13.sp,
                        color = Slate700
                    )
                    Surface(
                        color = Slate100,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = generatedTempPassToShow ?: "",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Navy900,
                            modifier = Modifier
                                .padding(16.dp)
                                .align(Alignment.CenterHorizontally),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                    Text(
                        text = "🔒 ইউজার এই পাসওয়ার্ডটি দিয়ে লগইন করার সাথে সাথে সিস্টেম স্বয়ংক্রিয়ভাবে তাকে নতুন স্থায়ী পাসওয়ার্ড সেট করতে বাধ্য করবে।",
                        fontSize = 12.sp,
                        color = Slate600
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { generatedTempPassToShow = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) {
                    Text("ঠিক আছে")
                }
            }
        )
    }
}

// --- Subscreen: Security & Audit Logs ---
@Composable
fun AuditLogsView(viewModel: MainViewModel, onBack: () -> Unit) {
    val auditLogs by viewModel.auditLogs.collectAsState()
    val dateFormat = remember { java.text.SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", java.util.Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text("Security & Audit Logs", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Slate900)
                Text("নিরাপত্তা হিস্ট্রি, পাসওয়ার্ড রিসেট ও ইউজার অ্যাকশন ট্রেইল", fontSize = 12.sp, color = Slate600)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (auditLogs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("কোনো অডিট লগ রেকর্ড নেই।", color = Slate500, fontSize = 14.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(auditLogs, key = { it.id }) { log ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = when {
                                        log.action.contains("Login") -> BlueCyan.copy(alpha = 0.15f)
                                        log.action.contains("Reset Approved") -> ProfitGreenLight
                                        log.action.contains("Reset") -> AmberGold.copy(alpha = 0.15f)
                                        log.action.contains("Created") -> DeliveredBlue.copy(alpha = 0.15f)
                                        else -> Slate200
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = log.action,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = when {
                                            log.action.contains("Login") -> Navy900
                                            log.action.contains("Reset Approved") -> ProfitGreen
                                            log.action.contains("Reset") -> AmberGold
                                            log.action.contains("Created") -> DeliveredBlue
                                            else -> Slate800
                                        },
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                Text(
                                    text = dateFormat.format(java.util.Date(log.timestampMillis)),
                                    fontSize = 10.sp,
                                    color = Slate500
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = log.details,
                                fontSize = 13.sp,
                                color = Slate800,
                                fontWeight = FontWeight.Medium
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "সম্পন্নকারী: ${log.performedByName} (ID: ${log.performedBy})",
                                fontSize = 11.sp,
                                color = Slate500
                            )
                        }
                    }
                }
            }
        }
    }
}
