package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Strings
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.DateFilterType
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: MainViewModel,
    strings: Strings,
    modifier: Modifier = Modifier
) {
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val activeFilter by viewModel.currentDateFilter.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val users by viewModel.users.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val packagingInfo by viewModel.packagingInfo.collectAsState()
    val adSpendInfo by viewModel.adSpendInfo.collectAsState()
    val boxInfo by viewModel.boxInfo.collectAsState()
    val stickerInfo by viewModel.stickerInfo.collectAsState()
    val allPermissions by viewModel.allPermissions.collectAsState()
    val passwordResetRequests by viewModel.passwordResetRequests.collectAsState()
    val pendingResets = passwordResetRequests.filter { it.status == ResetRequestStatus.PENDING }
    var generatedTempPassDialog by remember { mutableStateOf<String?>(null) }

    // Dialog state for edit options
    var editPackagingDialog by remember { mutableStateOf(false) }
    var editAdSpendDialog by remember { mutableStateOf(false) }
    var editBoxDialog by remember { mutableStateOf(false) }
    var editStickerDialog by remember { mutableStateOf(false) }
    var userAccessDialog by remember { mutableStateOf<UserProfile?>(null) }
    var quickCustomerDialog by remember { mutableStateOf(false) }
    var showCreateSellerDialog by remember { mutableStateOf(false) }
    var preselectedCreateRole by remember { mutableStateOf(UserRole.USER) }
    var userToDelete by remember { mutableStateOf<UserProfile?>(null) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }

    // Toggle for 1 Week vs 2 Months Sales Graph
    var salesTimeframeTab by remember { mutableStateOf(0) } // 0: 1 Week Sales, 1: 2 Months Sales

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate50)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Page Title matching notebook: "Admin page"
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Admin page (অ্যাডমিন ড্যাশবোর্ড)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Slate900,
                    fontSize = 20.sp
                )
                Text(
                    text = "All Track ও বিজনেস কন্ট্রোল সেন্টার",
                    color = Slate600,
                    fontSize = 12.sp
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showChangePasswordDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(Icons.Default.VpnKey, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("পাসওয়ার্ড চেঞ্জ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ProfitGreenLight
                ) {
                    Text(
                        text = "Online DB Live",
                        color = ProfitGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        if (pendingResets.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            val firstPending = pendingResets.first()
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = AmberGold.copy(alpha = 0.12f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, AmberGold.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LockReset, contentDescription = null, tint = AmberGold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "পাসওয়ার্ড রিসেট রিকোয়েস্ট (${pendingResets.size} টি পেন্ডিং)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Slate900
                            )
                        }
                        Text(
                            text = "${firstPending.userFullName} (${firstPending.userIdCode}) • ফোন: ${firstPending.mobileNumber}",
                            fontSize = 12.sp,
                            color = Slate700
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.approvePasswordReset(firstPending.id) { success, tempPass ->
                                if (success) {
                                    generatedTempPassDialog = tempPass
                                }
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AmberGold)
                    ) {
                        Text("অনুমোদন", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate900)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SECTION 1: "All Track" (Matching Hand-drawn Circles in Notebook)
        Text(
            text = "All Track",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Navy900,
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 5 Circular Rings as drawn in the notebook:
        // 1. Total Cost
        // 2. Total Profit
        // 3. Total Order
        // 4. Total User
        // 5. Total Save Customer
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CircularDonutRing(
                title = "Total Cost",
                value = "৳${metrics.totalCost.toInt()}",
                percentage = 10,
                ringColor = PendingOrange,
                modifier = Modifier.width(108.dp)
            )

            CircularDonutRing(
                title = "Total Profit",
                value = "৳${metrics.totalProfit.toInt()}",
                percentage = 20,
                ringColor = ProfitGreen,
                modifier = Modifier.width(108.dp)
            )

            CircularDonutRing(
                title = "Total Order",
                value = "${metrics.totalOrders} Orders",
                percentage = 30,
                ringColor = Blue600,
                modifier = Modifier.width(108.dp)
            )

            CircularDonutRing(
                title = "Total User",
                value = "${metrics.totalUsers} Staff",
                percentage = 50,
                ringColor = ShippedPurple,
                modifier = Modifier.width(108.dp)
            )

            CircularDonutRing(
                title = "Total Save Customer",
                value = "${customers.size} Saved",
                percentage = 40,
                ringColor = DeliveredBlue,
                modifier = Modifier.width(112.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // SECTION 2: Header from Notebook: "= Edit option / কাস্টমার এর হিসাব ও তথ্য"
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "= Edit option / কাস্টমার এর হিসাব ও তথ্য",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Slate900,
                    fontSize = 16.sp
                )
                Text(
                    text = "প্যাকেজিং, এড খরচ, বক্স, স্টিকার, সেলস ও ইউজার অনুমতি",
                    color = Slate600,
                    fontSize = 12.sp
                )
            }
            TextButton(onClick = { quickCustomerDialog = true }) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("কাস্টমার যোগ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // ITEM 1: প্যাকেজিং খরচ (Packaging Cost)
        // [টোটাল কত টাকা খরচ হয়েছে দেখা যাবে, আর কত পিস জমা আছে বুঝবো]
        OperationalCard(
            title = "প্যাকেজিং খরচ (Packaging Cost)",
            primaryStat = "মোট খরচ: ৳${packagingInfo.totalExpense.toInt()}",
            secondaryStat = "ব্যবহৃত: ${packagingInfo.totalPiecesUsed} পিস | স্টকে জমা আছে: ${packagingInfo.stockRemainingPieces} পিস",
            extraDetail = "প্রতি পিস আনুমানিক খরচ: ৳${packagingInfo.perPieceCost}",
            icon = Icons.Default.Inventory2,
            iconTint = Navy900,
            onEdit = { editPackagingDialog = true }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // ITEM 2: এড খরচ ($) (Ad Cost)
        // [টোটাল কত ডলার খরচ হয়েছে, দৈনিক বাজেট ও মাসিক ও সপ্তাহ হিসেবে টোটাল বাজেট দিলে টোটাল দেখাবে]
        OperationalCard(
            title = "এড খরচ ($) (Ad & Boosting Spend)",
            primaryStat = "মোট খরচ: $${adSpendInfo.totalDollarsSpent.toInt()} (≈ ৳${(adSpendInfo.totalDollarsSpent * adSpendInfo.dollarRateBdt).toInt()})",
            secondaryStat = "দৈনিক বাজেট: $${adSpendInfo.dailyBudgetDollars} | সক্রিয় এডস: ${adSpendInfo.activeAdsCount} টি",
            extraDetail = "সাপ্তাহিক বাজেট: $${adSpendInfo.weeklyBudgetDollars} | মাসিক বাজেট: $${adSpendInfo.monthlyBudgetDollars}",
            icon = Icons.Default.Campaign,
            iconTint = Blue600,
            onEdit = { editAdSpendDialog = true }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // ITEM 3: বক্স খরচ (Box Cost)
        // [টোটাল কত খরচ ও টোটাল স্টক হিসাব দেখতে পারবো]
        OperationalCard(
            title = "বক্স খরচ (Packaging Box Cost)",
            primaryStat = "মোট খরচ: ৳${boxInfo.totalExpense.toInt()}",
            secondaryStat = "মোট বক্স স্টক: ${boxInfo.totalBoxesStock} টি | ব্যবহৃত: ${boxInfo.totalBoxesUsed} টি",
            extraDetail = "প্রতি পিস বক্সের দাম: ৳${boxInfo.perPieceCost}",
            icon = Icons.Default.AllInbox,
            iconTint = PendingOrange,
            onEdit = { editBoxDialog = true }
        )

        Spacer(modifier = Modifier.height(10.dp))

        // ITEM 4: স্টিকার খরচ (Sticker Cost)
        // [বক্স এর মতো সেম সিস্টেম থাকবে]
        OperationalCard(
            title = "স্টিকার খরচ (Sticker Cost)",
            primaryStat = "মোট খরচ: ৳${stickerInfo.totalExpense.toInt()}",
            secondaryStat = "স্টকে জমা স্টিকার: ${stickerInfo.totalStickersStock} টি | ব্যবহৃত: ${stickerInfo.totalStickersUsed} টি",
            extraDetail = "প্রতি পিস স্টিকারের দাম: ৳${stickerInfo.perPieceCost}",
            icon = Icons.Default.Label,
            iconTint = DeliveredBlue,
            onEdit = { editStickerDialog = true }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // ITEM 5: ১ সপ্তাহের সেল ও ২ মাসের সেল (Sales Timeframe with Graph)
        // [১ সপ্তাহের সেল ও ২ মাসের সেলস দেখতে পারবো, সাথে সেলস গ্রাফ দেখাবে]
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "১ সপ্তাহের সেল ও ২ মাসের সেল (Sales Graph)",
                        fontWeight = FontWeight.Bold,
                        color = Slate900,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Timeframe Selector Tabs
                TabRow(
                    selectedTabIndex = salesTimeframeTab,
                    containerColor = Slate100,
                    contentColor = Navy900,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = salesTimeframeTab == 0,
                        onClick = { salesTimeframeTab = 0 },
                        text = { Text("১ সপ্তাহের সেল (Weekly)", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    )
                    Tab(
                        selected = salesTimeframeTab == 1,
                        onClick = { salesTimeframeTab = 1 },
                        text = { Text("২ মাসের সেল (2 Months)", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                val activeOrders = remember(orders) {
                    orders.filter {
                        it.status != OrderStatus.CANCELLED && it.status != OrderStatus.RETURNED
                    }
                }
                val dayMs = 86_400_000L
                val nowMs = System.currentTimeMillis()

                if (salesTimeframeTab == 0) {
                    val dayFormat = remember { java.text.SimpleDateFormat("EEE", java.util.Locale.ENGLISH) }
                    val weekData = remember(activeOrders) {
                        (6 downTo 0).map { daysAgo ->
                            val start = nowMs - ((daysAgo + 1) * dayMs)
                            val end = nowMs - (daysAgo * dayMs)
                            val label = dayFormat.format(java.util.Date(end))
                            val sum = activeOrders
                                .filter { it.orderDateMillis in start..end }
                                .sumOf { (it.productPrice - it.discount).coerceAtLeast(0.0) }
                            Pair(label, sum)
                        }
                    }
                    val weeklyTotal = weekData.sumOf { it.second }
                    SalesBarChart(
                        title = "১ সপ্তাহের দৈনিক সেলস ট্রেন্ড",
                        dataPoints = weekData
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "এই সপ্তাহের মোট অর্ডার সেলস: ৳${weeklyTotal.toInt()}",
                        fontWeight = FontWeight.Bold,
                        color = ProfitGreen,
                        fontSize = 13.sp
                    )
                } else {
                    val weekMs = 7L * dayMs
                    val twoMonthsData = remember(activeOrders) {
                        (7 downTo 0).map { weeksAgo ->
                            val start = nowMs - ((weeksAgo + 1) * weekMs)
                            val end = nowMs - (weeksAgo * weekMs)
                            val label = "W${8 - weeksAgo}"
                            val sum = activeOrders
                                .filter { it.orderDateMillis in start..end }
                                .sumOf { (it.productPrice - it.discount).coerceAtLeast(0.0) }
                            Pair(label, sum)
                        }
                    }
                    val twoMonthTotal = twoMonthsData.sumOf { it.second }
                    SalesBarChart(
                        title = "বিগত ২ মাসের সপ্তাহভিত্তিক সেলস রিপোর্ট (8 Weeks)",
                        dataPoints = twoMonthsData
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "গত ২ মাসের সর্বমোট সেলস: ৳${twoMonthTotal.toInt()}",
                        fontWeight = FontWeight.Bold,
                        color = ProfitGreen,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // ITEM 5.5: Secondary Admin Approval & Control (Up to 2 Super Admins: 1 Primary + 1 Secondary)
        val secAdmins = users.filter { it.role == UserRole.SECONDARY_SUPER_ADMIN }
        val isPrimaryAdmin = currentUser?.role == UserRole.PRIMARY_SUPER_ADMIN
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Secondary Admin Control (সেকেন্ডারি এডমিন নিয়ন্ত্রণ)",
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "সর্বোচ্চ ২ জন সুপার এডমিন (১ Primary + ১ Secondary) অনুমোদিত",
                            fontSize = 11.sp,
                            color = Slate600
                        )
                    }
                    if (isPrimaryAdmin && secAdmins.isEmpty()) {
                        OutlinedButton(
                            onClick = {
                                preselectedCreateRole = UserRole.SECONDARY_SUPER_ADMIN
                                showCreateSellerDialog = true
                            },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("+ ২য় এডমিন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Icon(Icons.Default.SupervisorAccount, contentDescription = null, tint = Navy900)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (secAdmins.isEmpty()) {
                    Text(
                        text = "কোনো সেকেন্ডারি এডমিন যুক্ত করা হয়নি।",
                        fontSize = 12.sp,
                        color = Slate600,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                } else {
                    secAdmins.forEach { sec ->
                        val secUid = sec.uid.ifBlank { sec.id }
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(sec.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                                    Text("আইডি: ${sec.userIdCode} • ফোন: ${sec.phone}", fontSize = 11.sp, color = Slate700, fontWeight = FontWeight.SemiBold)
                                    if (sec.email.isNotBlank()) {
                                        Text(sec.email, fontSize = 11.sp, color = Slate500)
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when (sec.status) {
                                            AccountStatus.ACTIVE -> ProfitGreenLight
                                            AccountStatus.DEACTIVATED -> AmberGold.copy(alpha = 0.2f)
                                            AccountStatus.SUSPENDED -> LossRedLight
                                        },
                                        modifier = Modifier.padding(top = 4.dp)
                                    ) {
                                        Text(
                                            text = sec.status.labelBn,
                                            color = when (sec.status) {
                                                AccountStatus.ACTIVE -> ProfitGreen
                                                AccountStatus.DEACTIVATED -> Slate900
                                                AccountStatus.SUSPENDED -> LossRed
                                            },
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                if (isPrimaryAdmin) {
                                    IconButton(
                                        onClick = { userToDelete = sec },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Remove Secondary Admin",
                                            tint = LossRed,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }

                            if (isPrimaryAdmin) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (sec.status != AccountStatus.ACTIVE) {
                                        Button(
                                            onClick = { viewModel.setUserAccountStatus(secUid, AccountStatus.ACTIVE) },
                                            colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) { Text("সক্রিয় করুন", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                    }
                                    if (sec.status != AccountStatus.DEACTIVATED) {
                                        OutlinedButton(
                                            onClick = { viewModel.setUserAccountStatus(secUid, AccountStatus.DEACTIVATED) },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) { Text("নিষ্ক্রিয়", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate800) }
                                    }
                                    if (sec.status != AccountStatus.SUSPENDED) {
                                        Button(
                                            onClick = { viewModel.setUserAccountStatus(secUid, AccountStatus.SUSPENDED) },
                                            colors = ButtonDefaults.buttonColors(containerColor = LossRed),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) { Text("সাসপেন্ড", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                    }
                                }
                            }
                        }
                        if (sec != secAdmins.lastOrNull()) {
                            HorizontalDivider(color = Slate200)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // ITEM 6: User Access (ইউজার অনুমতি নিয়ন্ত্রণ)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "User Access (ইউজার অনুমতি ও আইডি নিয়ন্ত্রণ)",
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "সেলার একাউন্ট তৈরি, সক্রিয়/নিষ্ক্রিয়/সাসপেন্ড ও অনুমতি নির্ধারণ",
                            fontSize = 11.sp,
                            color = Slate600
                        )
                    }
                    Button(
                        onClick = {
                            preselectedCreateRole = UserRole.USER
                            showCreateSellerDialog = true
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ সেলার একাউন্ট", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val salesReps = users.filter { it.role == UserRole.USER }
                if (salesReps.isEmpty()) {
                    Text(
                        text = "কোনো সেলার একাউন্ট নেই। উপরের '+ সেলার একাউন্ট' বাটনে চাপ দিয়ে সেলার তৈরি করুন।",
                        fontSize = 12.sp,
                        color = Slate600,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                salesReps.forEach { rep ->
                    val repUid = rep.uid.ifBlank { rep.id }
                    val perms = allPermissions[repUid] ?: UserPermissions.defaultUserPermissions(repUid)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rep.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                                Text("ইউজার আইডি: ${rep.userIdCode} • ফোন: ${rep.phone}", fontSize = 11.sp, color = Slate700, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "স্ট্যাটাস: ${rep.status.labelBn} | অনুমতি: ${if (perms.canCreateOrders) "অর্ডার চালু" else "অর্ডার বন্ধ"}, ${if (perms.canCreateCourierOrders) "কুরিয়ার চালু" else "কুরিয়ার বন্ধ"}",
                                    fontSize = 11.sp,
                                    color = when (rep.status) {
                                        AccountStatus.ACTIVE -> Blue600
                                        AccountStatus.DEACTIVATED -> AmberGold
                                        AccountStatus.SUSPENDED -> LossRed
                                    }
                                )
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { userAccessDialog = rep },
                                    colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = Color.White),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("অনুমতি", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }

                                IconButton(
                                    onClick = { userToDelete = rep },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete Seller",
                                        tint = LossRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (rep.status != AccountStatus.ACTIVE) {
                                OutlinedButton(
                                    onClick = { viewModel.setUserAccountStatus(repUid, AccountStatus.ACTIVE) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("সক্রিয় (Activate)", fontSize = 10.sp, color = ProfitGreen, fontWeight = FontWeight.Bold) }
                            }
                            if (rep.status != AccountStatus.DEACTIVATED) {
                                OutlinedButton(
                                    onClick = { viewModel.setUserAccountStatus(repUid, AccountStatus.DEACTIVATED) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("নিষ্ক্রিয় (Deactivate)", fontSize = 10.sp, color = Slate700, fontWeight = FontWeight.Bold) }
                            }
                            if (rep.status != AccountStatus.SUSPENDED) {
                                OutlinedButton(
                                    onClick = { viewModel.setUserAccountStatus(repUid, AccountStatus.SUSPENDED) },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("সাসপেন্ড (Suspend)", fontSize = 10.sp, color = LossRed, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                    if (rep != salesReps.lastOrNull()) {
                        HorizontalDivider(color = Slate200)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // --- Edit Dialogs for Packaging, Ad Spend, Box, and Sticker ---

    // 1. Edit Packaging
    if (editPackagingDialog) {
        var expenseText by remember { mutableStateOf(packagingInfo.totalExpense.toInt().toString()) }
        var usedText by remember { mutableStateOf(packagingInfo.totalPiecesUsed.toString()) }
        var stockText by remember { mutableStateOf(packagingInfo.stockRemainingPieces.toString()) }
        var perPieceText by remember { mutableStateOf(packagingInfo.perPieceCost.toString()) }

        AlertDialog(
            onDismissRequest = { editPackagingDialog = false },
            title = { Text("প্যাকেজিং খরচ ও স্টক আপডেট", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = expenseText, onValueChange = { expenseText = it }, label = { Text("মোট প্যাকেজিং খরচ (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = usedText, onValueChange = { usedText = it }, label = { Text("ব্যবহৃত পিস (Used)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = stockText, onValueChange = { stockText = it }, label = { Text("স্টকে জমা পিস (Stock Remaining)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = perPieceText, onValueChange = { perPieceText = it }, label = { Text("প্রতি পিস খরচ (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val exp = expenseText.toDoubleOrNull() ?: packagingInfo.totalExpense
                        val used = usedText.toIntOrNull() ?: packagingInfo.totalPiecesUsed
                        val stock = stockText.toIntOrNull() ?: packagingInfo.stockRemainingPieces
                        val perP = perPieceText.toDoubleOrNull() ?: packagingInfo.perPieceCost
                        viewModel.updatePackaging(PackagingTrackingInfo(exp, used, stock, perP))
                        editPackagingDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("সংরক্ষণ করুন") }
            },
            dismissButton = { TextButton(onClick = { editPackagingDialog = false }) { Text("বাতিল") } }
        )
    }

    // 2. Edit Ad Spend ($)
    if (editAdSpendDialog) {
        var dollarsText by remember { mutableStateOf(adSpendInfo.totalDollarsSpent.toInt().toString()) }
        var dailyText by remember { mutableStateOf(adSpendInfo.dailyBudgetDollars.toString()) }
        var activeAdsText by remember { mutableStateOf(adSpendInfo.activeAdsCount.toString()) }
        var weeklyText by remember { mutableStateOf(adSpendInfo.weeklyBudgetDollars.toString()) }
        var monthlyText by remember { mutableStateOf(adSpendInfo.monthlyBudgetDollars.toString()) }

        AlertDialog(
            onDismissRequest = { editAdSpendDialog = false },
            title = { Text("এড খরচ ও বুস্টিং বাজেট আপডেট ($)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = dollarsText, onValueChange = { dollarsText = it }, label = { Text("মোট ডলার খরচ ($)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = dailyText, onValueChange = { dailyText = it }, label = { Text("দৈনিক বাজেট ($)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = weeklyText, onValueChange = { weeklyText = it }, label = { Text("সাপ্তাহিক বাজেট ($)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = monthlyText, onValueChange = { monthlyText = it }, label = { Text("মাসিক বাজেট ($)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = activeAdsText, onValueChange = { activeAdsText = it }, label = { Text("চালু এড সংখ্যা (Active Ads)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val d = dollarsText.toDoubleOrNull() ?: adSpendInfo.totalDollarsSpent
                        val day = dailyText.toDoubleOrNull() ?: adSpendInfo.dailyBudgetDollars
                        val wk = weeklyText.toDoubleOrNull() ?: adSpendInfo.weeklyBudgetDollars
                        val mo = monthlyText.toDoubleOrNull() ?: adSpendInfo.monthlyBudgetDollars
                        val act = activeAdsText.toIntOrNull() ?: adSpendInfo.activeAdsCount
                        viewModel.updateAdSpend(AdSpendInfo(d, day, act, wk, mo, adSpendInfo.dollarRateBdt))
                        editAdSpendDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("সংরক্ষণ করুন") }
            },
            dismissButton = { TextButton(onClick = { editAdSpendDialog = false }) { Text("বাতিল") } }
        )
    }

    // 3. Edit Box Info
    if (editBoxDialog) {
        var expenseText by remember { mutableStateOf(boxInfo.totalExpense.toInt().toString()) }
        var stockText by remember { mutableStateOf(boxInfo.totalBoxesStock.toString()) }
        var usedText by remember { mutableStateOf(boxInfo.totalBoxesUsed.toString()) }
        var perPieceText by remember { mutableStateOf(boxInfo.perPieceCost.toString()) }

        AlertDialog(
            onDismissRequest = { editBoxDialog = false },
            title = { Text("প্যাকেজিং বক্স খরচ ও স্টক আপডেট", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = expenseText, onValueChange = { expenseText = it }, label = { Text("মোট বক্স খরচ (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = stockText, onValueChange = { stockText = it }, label = { Text("মোট বক্স স্টক (Boxes in Stock)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = usedText, onValueChange = { usedText = it }, label = { Text("ব্যবহৃত বক্স (Boxes Used)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = perPieceText, onValueChange = { perPieceText = it }, label = { Text("প্রতি পিস বক্সের দাম (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val exp = expenseText.toDoubleOrNull() ?: boxInfo.totalExpense
                        val stock = stockText.toIntOrNull() ?: boxInfo.totalBoxesStock
                        val used = usedText.toIntOrNull() ?: boxInfo.totalBoxesUsed
                        val perP = perPieceText.toDoubleOrNull() ?: boxInfo.perPieceCost
                        viewModel.updateBoxInfo(BoxTrackingInfo(exp, stock, used, perP))
                        editBoxDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("সংরক্ষণ করুন") }
            },
            dismissButton = { TextButton(onClick = { editBoxDialog = false }) { Text("বাতিল") } }
        )
    }

    // 4. Edit Sticker Info
    if (editStickerDialog) {
        var expenseText by remember { mutableStateOf(stickerInfo.totalExpense.toInt().toString()) }
        var stockText by remember { mutableStateOf(stickerInfo.totalStickersStock.toString()) }
        var usedText by remember { mutableStateOf(stickerInfo.totalStickersUsed.toString()) }
        var perPieceText by remember { mutableStateOf(stickerInfo.perPieceCost.toString()) }

        AlertDialog(
            onDismissRequest = { editStickerDialog = false },
            title = { Text("স্টিকার খরচ ও স্টক আপডেট", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = expenseText, onValueChange = { expenseText = it }, label = { Text("মোট স্টিকার খরচ (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = stockText, onValueChange = { stockText = it }, label = { Text("স্টকে জমা স্টিকার (Stickers Remaining)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = usedText, onValueChange = { usedText = it }, label = { Text("ব্যবহৃত স্টিকার (Stickers Used)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = perPieceText, onValueChange = { perPieceText = it }, label = { Text("প্রতি পিস স্টিকারের দাম (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val exp = expenseText.toDoubleOrNull() ?: stickerInfo.totalExpense
                        val stock = stockText.toIntOrNull() ?: stickerInfo.totalStickersStock
                        val used = usedText.toIntOrNull() ?: stickerInfo.totalStickersUsed
                        val perP = perPieceText.toDoubleOrNull() ?: stickerInfo.perPieceCost
                        viewModel.updateStickerInfo(StickerTrackingInfo(exp, stock, used, perP))
                        editStickerDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("সংরক্ষণ করুন") }
            },
            dismissButton = { TextButton(onClick = { editStickerDialog = false }) { Text("বাতিল") } }
        )
    }

    // User Access Quick Dialog
    if (userAccessDialog != null) {
        val u = userAccessDialog!!
        val targetUid = u.uid.ifBlank { u.id }
        val currentPerms = allPermissions[targetUid] ?: UserPermissions.defaultUserPermissions(targetUid)
        var permsState by remember { mutableStateOf(currentPerms.copy(userId = targetUid)) }

        AlertDialog(
            onDismissRequest = { userAccessDialog = null },
            containerColor = Color.White,
            title = { Text("User Access: ${u.fullName}", fontWeight = FontWeight.Bold, color = Slate900) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("আপনি যা যা অনুমতি দিবেন সেলার তা ব্যবহার করতে পারবে:", fontSize = 12.sp, color = Slate600)
                    Spacer(modifier = Modifier.height(8.dp))
                    PermToggleRow("ড্যাশবোর্ড দেখার অনুমতি", permsState.canViewDashboard) { permsState = permsState.copy(canViewDashboard = it) }
                    PermToggleRow("মোট বিক্রি দেখার অনুমতি", permsState.canViewTotalSales) { permsState = permsState.copy(canViewTotalSales = it) }
                    PermToggleRow("মোট খরচ দেখার অনুমতি", permsState.canViewTotalCost) { permsState = permsState.copy(canViewTotalCost = it) }
                    PermToggleRow("মোট প্রফিট দেখার অনুমতি", permsState.canViewTotalProfit) { permsState = permsState.copy(canViewTotalProfit = it) }
                    PermToggleRow("অর্ডার তৈরি করার অনুমতি", permsState.canCreateOrders) { permsState = permsState.copy(canCreateOrders = it) }
                    PermToggleRow("কুরিয়ারে অর্ডার পাঠানোর অনুমতি", permsState.canCreateCourierOrders) { permsState = permsState.copy(canCreateCourierOrders = it) }
                    PermToggleRow("অর্ডার এডিট করার অনুমতি", permsState.canEditOrders) { permsState = permsState.copy(canEditOrders = it) }
                    PermToggleRow("কাস্টমার তালিকা ও যোগ", permsState.canViewCustomers) { permsState = permsState.copy(canViewCustomers = it, canAddCustomers = it) }
                    PermToggleRow("কুরিয়ার ট্র্যাকিং দেখার অনুমতি", permsState.canViewCourier) { permsState = permsState.copy(canViewCourier = it) }
                    PermToggleRow("রিটার্ন রিপোর্ট দেখার অনুমতি", permsState.canViewReturnOrders) { permsState = permsState.copy(canViewReturnOrders = it) }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.savePermissions(permsState)
                        userAccessDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("অনুমতি সেভ করুন", color = Color.White) }
            },
            dismissButton = { TextButton(onClick = { userAccessDialog = null }) { Text("বাতিল", color = Slate700) } }
        )
    }

    // Quick Add Customer Dialog
    if (quickCustomerDialog) {
        var custName by remember { mutableStateOf("") }
        var custPhone by remember { mutableStateOf("") }
        var custAddress by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { quickCustomerDialog = false },
            title = { Text("কাস্টমার তথ্য যোগ করুন", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = custName, onValueChange = { custName = it }, label = { Text("কাস্টমার নাম") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = custPhone, onValueChange = { custPhone = it }, label = { Text("ফোন নম্বর") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = custAddress, onValueChange = { custAddress = it }, label = { Text("ঠিকানা") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (custName.isNotBlank() && custPhone.isNotBlank()) {
                            viewModel.addCustomerDirect(custName, custPhone, custAddress)
                            quickCustomerDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("সেভ করুন") }
            },
            dismissButton = { TextButton(onClick = { quickCustomerDialog = false }) { Text("বাতিল") } }
        )
    }

    if (generatedTempPassDialog != null) {
        AlertDialog(
            onDismissRequest = { generatedTempPassDialog = null },
            title = { Text("✅ পাসওয়ার্ড রিসেট অনুমোদিত", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ইউজারকে লগইন করার জন্য এই ওয়ান-টাইম অস্থায়ী পাসওয়ার্ডটি প্রদান করুন:", fontSize = 13.sp)
                    Surface(
                        color = Slate100,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = generatedTempPassDialog ?: "",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Navy900,
                            modifier = Modifier.padding(14.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                    Text("লগইন করার সাথে সাথে ইউজারকে নতুন স্থায়ী পাসওয়ার্ড সেট করতে বলা হবে।", fontSize = 12.sp, color = Slate600)
                }
            },
            confirmButton = {
                Button(onClick = { generatedTempPassDialog = null }, colors = ButtonDefaults.buttonColors(containerColor = Navy900)) {
                    Text("ঠিক আছে")
                }
            }
        )
    }

    // Create Custom Seller / Secondary Admin Account Dialog (via Firebase Cloud Function)
    if (showCreateSellerDialog) {
        var sellerName by remember { mutableStateOf("") }
        var sellerPhone by remember { mutableStateOf("") }
        var sellerEmail by remember { mutableStateOf("") }
        var customUserId by remember { mutableStateOf("") }
        var sellerPassword by remember { mutableStateOf("") }
        var sellerTargetText by remember { mutableStateOf("50000") }
        var selectedRole by remember(preselectedCreateRole) { mutableStateOf(preselectedCreateRole) }
        var createError by remember { mutableStateOf<String?>(null) }
        var isCreating by remember { mutableStateOf(false) }
        val canCreateSecAdmin = currentUser?.role == UserRole.PRIMARY_SUPER_ADMIN

        AlertDialog(
            onDismissRequest = { if (!isCreating) showCreateSellerDialog = false },
            title = { Text("নতুন অ্যাকাউন্ট তৈরি করুন", fontWeight = FontWeight.Bold, color = Slate900) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("সুপার অ্যাডমিন কর্তৃক ইউজার আইডি ও পাসওয়ার্ড তৈরি (Firebase Auth):", fontSize = 12.sp, color = Slate600)

                    OutlinedTextField(
                        value = sellerName,
                        onValueChange = { sellerName = it; createError = null },
                        label = { Text("পূর্ণ নাম (Full Name)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = sellerPhone,
                        onValueChange = { sellerPhone = it; createError = null },
                        label = { Text("ফোন নম্বর (Phone Number)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = customUserId,
                        onValueChange = { customUserId = it; createError = null },
                        label = { Text("ইউজার আইডি (যেমন: USR-105 বা ADM-002)") },
                        placeholder = { Text("খালি রাখলে স্বয়ংক্রিয় আইডি হবে") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = sellerEmail,
                        onValueChange = { sellerEmail = it; createError = null },
                        label = { Text("ইমেইল (ঐচ্ছিক - খালি রাখলে অটো তৈরি হবে)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = sellerPassword,
                        onValueChange = { sellerPassword = it; createError = null },
                        label = { Text("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = sellerTargetText,
                        onValueChange = { sellerTargetText = it },
                        label = { Text("মাসিক সেলস টার্গেট (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate900, unfocusedTextColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (canCreateSecAdmin) {
                        Text("অ্যাকাউন্ট রোল:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate800)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = selectedRole == UserRole.USER,
                                onClick = { selectedRole = UserRole.USER }
                            )
                            Text("Sales User", fontSize = 12.sp, color = Slate900)
                            Spacer(modifier = Modifier.width(10.dp))
                            RadioButton(
                                selected = selectedRole == UserRole.SECONDARY_SUPER_ADMIN,
                                onClick = { selectedRole = UserRole.SECONDARY_SUPER_ADMIN }
                            )
                            Text("2nd Super Admin", fontSize = 12.sp, color = Slate900)
                        }
                    }

                    if (createError != null) {
                        Text(createError!!, color = LossRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (sellerName.isBlank() || sellerPhone.isBlank() || sellerPassword.length < 6) {
                            createError = "নাম, ফোন নম্বর এবং কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন!"
                            return@Button
                        }
                        val target = sellerTargetText.toDoubleOrNull() ?: 50000.0
                        isCreating = true
                        createError = null
                        viewModel.createUser(
                            name = sellerName,
                            phone = sellerPhone,
                            role = selectedRole,
                            pass = sellerPassword,
                            customUserIdCode = customUserId.ifBlank { null },
                            monthlyTarget = target,
                            email = sellerEmail
                        ) { ok, err, _ ->
                            isCreating = false
                            if (ok) {
                                showCreateSellerDialog = false
                            } else {
                                createError = err ?: "অ্যাকাউন্ট তৈরি ব্যর্থ হয়েছে"
                            }
                        }
                    },
                    enabled = !isCreating,
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) {
                    Text(if (isCreating) "তৈরি হচ্ছে..." else "একাউন্ট তৈরি করুন")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { if (!isCreating) showCreateSellerDialog = false },
                    enabled = !isCreating
                ) { Text("বাতিল") }
            }
        )
    }

    // Delete User Confirmation Dialog
    if (userToDelete != null) {
        val u = userToDelete!!
        val targetUid = u.uid.ifBlank { u.id }
        AlertDialog(
            onDismissRequest = { userToDelete = null },
            title = { Text("⚠️ ইউজার মুছে ফেলার নিশ্চিতকরণ", fontWeight = FontWeight.Bold, color = LossRed) },
            text = {
                Text(
                    text = "আপনি কি নিশ্চিত যে '${u.fullName}' (আইডি: ${u.userIdCode}) একাউন্টটি স্থায়ীভাবে মুছে ফেলতে চান?",
                    fontSize = 13.sp,
                    color = Slate800
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteUser(targetUid)
                        userToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LossRed)
                ) {
                    Text("হ্যাঁ, ডিলিট করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { userToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Change Password Dialog (For logged-in Admin/User)
    if (showChangePasswordDialog) {
        var newPassText by remember { mutableStateOf("") }
        var confirmPassText by remember { mutableStateOf("") }
        var passError by remember { mutableStateOf<String?>(null) }
        var passSuccess by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("নিজের পাসওয়ার্ড পরিবর্তন করুন", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("আপনার একাউন্টের জন্য নতুন পাসওয়ার্ড দিন:", fontSize = 12.sp, color = Slate600)

                    OutlinedTextField(
                        value = newPassText,
                        onValueChange = { newPassText = it; passError = null; passSuccess = null },
                        label = { Text("নতুন পাসওয়ার্ড (New Password)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = confirmPassText,
                        onValueChange = { confirmPassText = it; passError = null; passSuccess = null },
                        label = { Text("পাসওয়ার্ড নিশ্চিত করুন (Confirm Password)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (passError != null) {
                        Text(passError!!, color = LossRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    if (passSuccess != null) {
                        Text(passSuccess!!, color = ProfitGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPassText.isBlank()) {
                            passError = "পাসওয়ার্ড লিখুন!"
                            return@Button
                        }
                        if (newPassText != confirmPassText) {
                            passError = "পাসওয়ার্ড দুটি মেলেনি!"
                            return@Button
                        }
                        viewModel.changePassword(newPassText) { success, msg ->
                            if (success) {
                                passSuccess = "✓ পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!"
                                showChangePasswordDialog = false
                            } else {
                                passError = msg ?: "পরিবর্তন ব্যর্থ"
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) { Text("পাসওয়ার্ড আপডেট") }
            },
            dismissButton = {
                TextButton(onClick = { showChangePasswordDialog = false }) { Text("বাতিল") }
            }
        )
    }
}

@Composable
private fun OperationalCard(
    title: String,
    primaryStat: String,
    secondaryStat: String,
    extraDetail: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    onEdit: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = iconTint.copy(alpha = 0.12f),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = title, fontWeight = FontWeight.Bold, color = Slate900, fontSize = 14.sp)
                }

                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("আপডেট", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(text = primaryStat, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Slate900)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = secondaryStat, fontSize = 12.sp, color = Slate700)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = extraDetail, fontSize = 11.sp, color = Blue600, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun PermToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp, color = Slate800)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
