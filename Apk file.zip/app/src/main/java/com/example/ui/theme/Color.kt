package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Navy & Royal Blues
val Navy900 = Color(0xFF0A192F)
val Navy800 = Color(0xFF0F223D)
val Navy700 = Color(0xFF1E3A5F)
val Blue600 = Color(0xFF1E88E5)
val Blue500 = Color(0xFF2196F3)
val BlueCyan = Color(0xFF00D2FF)

// Status Colors for Business Metrics
val ProfitGreen = Color(0xFF10B981)
val ProfitGreenLight = Color(0xFFE8F5E9)
val LossRed = Color(0xFFEF4444)
val LossRedLight = Color(0xFFFFEBEE)
val PendingOrange = Color(0xFFF59E0B)
val PendingOrangeLight = Color(0xFFFFF8E1)
val DeliveredBlue = Color(0xFF0284C7)
val ShippedPurple = Color(0xFF8B5CF6)

val AmberGold = Color(0xFFD97706)
val AmberGoldLight = Color(0xFFFEF3C7)

// Neutral Backgrounds & Cards
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
