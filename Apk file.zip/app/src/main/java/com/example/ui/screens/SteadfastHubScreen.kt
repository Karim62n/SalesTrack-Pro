package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Strings
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class CourierParcelFilter(val labelBn: String) {
    ALL("সব পার্সেল"),
    PENDING("পেন্ডিং (Pending)"),
    IN_TRANSIT("চলমান (In Transit)"),
    DELIVERED("ডেলিভারি (Delivered)"),
    CANCELLED_RETURN("রিটার্ন / বাতিল")
}

private fun categorizeCourierStatus(raw: String): CourierParcelFilter {
    return when (raw.trim().lowercase()) {
        "in_review", "pending", "hold", "unknown" -> CourierParcelFilter.PENDING
        "in_transit", "shipped", "out_for_delivery" -> CourierParcelFilter.IN_TRANSIT
        "delivered", "partial_delivered", "delivered_approval_pending", "partial_delivered_approval_pending" -> CourierParcelFilter.DELIVERED
        "cancelled", "cancelled_approval_pending", "returned" -> CourierParcelFilter.CANCELLED_RETURN
        else -> CourierParcelFilter.PENDING
    }
}

private fun formatStatusBadgeText(raw: String): String {
    return when (raw.trim().lowercase()) {
        "in_review" -> "ইন রিভিউ (Pending)"
        "pending" -> "পেন্ডিং (Pending)"
        "hold" -> "হোল্ড (Pending)"
        "in_transit", "shipped", "out_for_delivery" -> "ট্রানজিটে আছে (In Transit)"
        "delivered", "delivered_approval_pending" -> "ডেলিভারি সম্পন্ন (Delivered)"
        "partial_delivered", "partial_delivered_approval_pending" -> "আংশিক ডেলিভারি"
        "cancelled", "cancelled_approval_pending" -> "বাতিল (Cancelled)"
        "returned" -> "রিটার্ন (Returned)"
        else -> raw
    }
}

@Composable
fun SteadfastHubScreen(
    viewModel: MainViewModel,
    strings: Strings,
    modifier: Modifier = Modifier
) {
    val config by viewModel.steadfastConfig.collectAsState()
    val shipments by viewModel.shipments.collectAsState()
    val isCourierLoading by viewModel.isCourierLoading.collectAsState()

    var showConfigDialog by remember { mutableStateOf(false) }
    var showProductionConfirmDialog by remember { mutableStateOf(false) }
    var connectionTestResult by remember { mutableStateOf<String?>(null) }
    var liveSyncResult by remember { mutableStateOf<String?>(null) }
    var directTrackResult by remember { mutableStateOf<String?>(null) }
    var trackingSearchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(CourierParcelFilter.ALL) }
    var hasAutoSynced by remember(config.isSandbox, config.apiKey) { mutableStateOf(false) }

    LaunchedEffect(config.isSandbox, config.apiKey, shipments.isNotEmpty()) {
        if (!hasAutoSynced && !config.isSandbox && config.apiKey.isNotBlank() && config.secretKey.isNotBlank() && shipments.isNotEmpty()) {
            hasAutoSynced = true
            viewModel.syncAllCourierShipments(showToastOnSuccess = false) { ok, msg ->
                liveSyncResult = if (ok) "✓ $msg" else "✗ $msg"
            }
        }
    }

    val pendingCount = remember(shipments) {
        shipments.count { categorizeCourierStatus(it.status) == CourierParcelFilter.PENDING }
    }
    val inTransitCount = remember(shipments) {
        shipments.count { categorizeCourierStatus(it.status) == CourierParcelFilter.IN_TRANSIT }
    }
    val deliveredCount = remember(shipments) {
        shipments.count { categorizeCourierStatus(it.status) == CourierParcelFilter.DELIVERED }
    }
    val cancelledReturnCount = remember(shipments) {
        shipments.count { categorizeCourierStatus(it.status) == CourierParcelFilter.CANCELLED_RETURN }
    }

    val lastSyncedText = remember(shipments) {
        val latest = shipments.maxOfOrNull { it.lastSyncedMillis } ?: 0L
        if (latest > 0L) {
            SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(latest))
        } else {
            "এখনো সিঙ্ক হয়নি"
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate50)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Mode Banner (Sandbox vs Production)
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (config.isSandbox) PendingOrangeLight else ProfitGreenLight
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (config.isSandbox) Icons.Default.Science else Icons.Default.Verified,
                            contentDescription = null,
                            tint = if (config.isSandbox) PendingOrange else ProfitGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (config.isSandbox) strings.sandboxMode else strings.productionMode,
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            fontSize = 15.sp
                        )
                    }

                    Switch(
                        checked = !config.isSandbox,
                        onCheckedChange = { isProd ->
                            if (isProd) {
                                if (config.apiKey.isBlank() || config.secretKey.isBlank()) {
                                    connectionTestResult = "✗ লাইভ মোড চালু করতে আগে API Key ও Secret Key দিন।"
                                    showConfigDialog = true
                                } else {
                                    showProductionConfirmDialog = true
                                }
                            } else {
                                viewModel.updateSteadfastConfig(config.apiKey, config.secretKey, isSandbox = true)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ProfitGreen,
                            checkedTrackColor = ProfitGreenLight
                        ),
                        modifier = Modifier.testTag("courier_mode_switch")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (config.isSandbox) {
                        "🛡️ Demo parcels are safely isolated from real courier dispatches. You can test consignment creation freely."
                    } else {
                        "⚡ Live Production Mode Active. Real parcels will be dispatched & synced with Steadfast Courier."
                    },
                    fontSize = 12.sp,
                    color = Slate700
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // API Configuration Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Steadfast Merchant API Settings",
                        fontWeight = FontWeight.Bold,
                        color = Slate900,
                        fontSize = 15.sp
                    )
                    IconButton(onClick = { showConfigDialog = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Edit Config", tint = Navy900)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "API Key: ${if (config.apiKey.isNotBlank()) "••••••••" + config.apiKey.takeLast(4) else "Not configured (Using Sandbox)"}",
                    fontSize = 12.sp,
                    color = Slate600
                )
                Text(
                    text = "Secret Key: ${if (config.secretKey.isNotBlank()) "••••••••••••" else "Not configured"}",
                    fontSize = 12.sp,
                    color = Slate600
                )
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (config.isSandbox) PendingOrangeLight else ProfitGreenLight
                ) {
                    Text(
                        text = if (config.isSandbox) "বর্তমান মোড: SANDBOX (ডেমো)" else "বর্তমান মোড: LIVE PRODUCTION ⚡",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (config.isSandbox) PendingOrange else ProfitGreen,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.testSteadfastConnection { ok, msg ->
                                connectionTestResult = if (ok) "✓ $msg" else "✗ $msg"
                            }
                        },
                        enabled = !isCourierLoading,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = Color.White),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("test_courier_connection_button")
                    ) {
                        if (isCourierLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                        } else {
                            Text(strings.testConnection, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    OutlinedButton(
                        onClick = { showConfigDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Navy900),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Configure Keys", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy900)
                    }
                }

                if (connectionTestResult != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = connectionTestResult!!,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (connectionTestResult!!.startsWith("✓")) ProfitGreen else LossRed
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Courier Parcel Metrics Header + Live Sync Action
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Courier Shipments & Live Status",
                    fontWeight = FontWeight.Bold,
                    color = Slate900,
                    fontSize = 16.sp
                )
                Text(
                    text = "সর্বশেষ আপডেট: $lastSyncedText",
                    fontSize = 11.sp,
                    color = Slate600
                )
            }
            Button(
                onClick = {
                    viewModel.syncAllCourierShipments { ok, msg ->
                        liveSyncResult = if (ok) "✓ $msg" else "✗ $msg"
                    }
                },
                enabled = !isCourierLoading,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ProfitGreen,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("courier_live_sync_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = "Live Sync",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "লাইভ আপডেট",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        if (liveSyncResult != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (liveSyncResult!!.startsWith("✓")) ProfitGreenLight else LossRedLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = liveSyncResult!!,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (liveSyncResult!!.startsWith("✓")) ProfitGreen else LossRed,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Interactive 2x2 Status Summary Grid: Total, Pending, In Transit, Delivered
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CourierStatusSummaryCard(
                title = "মোট পার্সেল (Total)",
                count = shipments.size,
                icon = Icons.Default.LocalShipping,
                accentColor = Navy900,
                isSelected = selectedFilter == CourierParcelFilter.ALL,
                onClick = { selectedFilter = CourierParcelFilter.ALL },
                modifier = Modifier
                    .weight(1f)
                    .testTag("courier_filter_all")
            )
            CourierStatusSummaryCard(
                title = "পেন্ডিং (Pending)",
                count = pendingCount,
                icon = Icons.Default.HourglassTop,
                accentColor = PendingOrange,
                isSelected = selectedFilter == CourierParcelFilter.PENDING,
                onClick = {
                    selectedFilter = if (selectedFilter == CourierParcelFilter.PENDING) {
                        CourierParcelFilter.ALL
                    } else {
                        CourierParcelFilter.PENDING
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("courier_filter_pending")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CourierStatusSummaryCard(
                title = "ট্রানজিটে (In Transit)",
                count = inTransitCount,
                icon = Icons.Default.DirectionsRun,
                accentColor = DeliveredBlue,
                isSelected = selectedFilter == CourierParcelFilter.IN_TRANSIT,
                onClick = {
                    selectedFilter = if (selectedFilter == CourierParcelFilter.IN_TRANSIT) {
                        CourierParcelFilter.ALL
                    } else {
                        CourierParcelFilter.IN_TRANSIT
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("courier_filter_in_transit")
            )
            CourierStatusSummaryCard(
                title = "ডেলিভারি (Delivered)",
                count = deliveredCount,
                icon = Icons.Default.CheckCircle,
                accentColor = ProfitGreen,
                isSelected = selectedFilter == CourierParcelFilter.DELIVERED,
                onClick = {
                    selectedFilter = if (selectedFilter == CourierParcelFilter.DELIVERED) {
                        CourierParcelFilter.ALL
                    } else {
                        CourierParcelFilter.DELIVERED
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("courier_filter_delivered")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Return / Cancelled Filter Pill
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = if (selectedFilter == CourierParcelFilter.CANCELLED_RETURN) {
                BorderStroke(1.5.dp, LossRed)
            } else {
                BorderStroke(1.dp, Slate200)
            },
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    selectedFilter = if (selectedFilter == CourierParcelFilter.CANCELLED_RETURN) {
                        CourierParcelFilter.ALL
                    } else {
                        CourierParcelFilter.CANCELLED_RETURN
                    }
                }
                .testTag("courier_filter_cancelled")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AssignmentReturn,
                        contentDescription = null,
                        tint = LossRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "রিটার্ন ও বাতিল (Return / Cancelled)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Slate800
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = LossRedLight
                ) {
                    Text(
                        text = "$cancelledReturnCount",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = LossRed,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search & Live Direct Parcel Tracking Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = trackingSearchQuery,
                onValueChange = {
                    trackingSearchQuery = it
                    directTrackResult = null
                },
                placeholder = { Text("Consignment ID / Tracking / Invoice...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Slate600) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Slate900,
                    unfocusedTextColor = Slate900,
                    focusedLabelColor = Slate700,
                    unfocusedLabelColor = Slate600,
                    focusedPlaceholderColor = Slate500,
                    unfocusedPlaceholderColor = Slate500
                ),
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    viewModel.trackCourierParcelDirect(trackingSearchQuery) { ok, msg ->
                        directTrackResult = if (ok) "✓ $msg" else "✗ $msg"
                    }
                },
                enabled = !isCourierLoading && trackingSearchQuery.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = Color.White),
                contentPadding = PaddingValues(horizontal = 12.dp),
                modifier = Modifier
                    .height(54.dp)
                    .testTag("courier_direct_track_button")
            ) {
                Text("লাইভ ট্র্যাক", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        if (directTrackResult != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (directTrackResult!!.startsWith("✓")) ProfitGreenLight else LossRedLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = directTrackResult!!,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (directTrackResult!!.startsWith("✓")) ProfitGreen else LossRed,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Shipments list filtered by status card & search query
        val statusFiltered = if (selectedFilter == CourierParcelFilter.ALL) {
            shipments
        } else {
            shipments.filter { categorizeCourierStatus(it.status) == selectedFilter }
        }
        val filteredShipments = if (trackingSearchQuery.isBlank()) {
            statusFiltered
        } else {
            statusFiltered.filter {
                it.consignmentId.contains(trackingSearchQuery, ignoreCase = true) ||
                    it.trackingCode.contains(trackingSearchQuery, ignoreCase = true) ||
                    it.invoiceNumber.contains(trackingSearchQuery, ignoreCase = true)
            }
        }

        if (filteredShipments.isEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalShipping,
                        contentDescription = null,
                        tint = Slate400,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (shipments.isEmpty()) {
                            "এখনো কোনো কুরিয়ার পার্সেল রেকর্ড নেই।"
                        } else {
                            "'${selectedFilter.labelBn}' ফিল্টারে কোনো পার্সেল পাওয়া যায়নি।"
                        },
                        color = Slate700,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (shipments.isEmpty()) {
                            "অর্ডার (Orders) ট্যাব থেকে 'Send to Steadfast' দিয়ে পার্সেল পাঠান অথবা উপরে Consignment ID লিখে 'লাইভ ট্র্যাক' চাপুন।"
                        } else {
                            "সব পার্সেল দেখতে 'মোট পার্সেল' কার্ডে ট্যাপ করুন।"
                        },
                        color = Slate500,
                        fontSize = 12.sp
                    )
                    if (shipments.isNotEmpty() && selectedFilter != CourierParcelFilter.ALL) {
                        Spacer(modifier = Modifier.height(10.dp))
                        TextButton(onClick = { selectedFilter = CourierParcelFilter.ALL }) {
                            Text("সব পার্সেল দেখুন", color = Navy900, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            filteredShipments.forEach { ship ->
                val category = categorizeCourierStatus(ship.status)
                val (badgeBg, badgeFg) = when (category) {
                    CourierParcelFilter.PENDING -> PendingOrangeLight to PendingOrange
                    CourierParcelFilter.IN_TRANSIT -> Color(0xFFE0F2FE) to DeliveredBlue
                    CourierParcelFilter.DELIVERED -> ProfitGreenLight to ProfitGreen
                    CourierParcelFilter.CANCELLED_RETURN -> LossRedLight to LossRed
                    CourierParcelFilter.ALL -> Slate100 to Slate700
                }
                val syncedAt = if (ship.lastSyncedMillis > 0L) {
                    SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ship.lastSyncedMillis))
                } else {
                    ""
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Consignment: ${ship.consignmentId}",
                                fontWeight = FontWeight.Bold,
                                color = Navy900,
                                fontSize = 14.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (ship.isSandbox) PendingOrangeLight else ProfitGreenLight
                                ) {
                                    Text(
                                        text = if (ship.isSandbox) "SANDBOX" else "LIVE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (ship.isSandbox) PendingOrange else ProfitGreen,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.syncSingleCourierShipment(ship.id) },
                                    enabled = !isCourierLoading,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Refresh parcel status",
                                        tint = Navy900,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "Invoice: ${ship.invoiceNumber} • Tracking: ${ship.trackingCode}",
                            fontSize = 12.sp,
                            color = Slate600
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "COD: ৳${ship.codAmount.toInt()} • Delivery Charge: ৳${ship.deliveryCharge.toInt()}",
                            fontSize = 12.sp,
                            color = ProfitGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = badgeBg
                            ) {
                                Text(
                                    text = formatStatusBadgeText(ship.status),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = badgeFg,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            if (syncedAt.isNotBlank()) {
                                Text(
                                    text = "আপডেট: $syncedAt",
                                    fontSize = 11.sp,
                                    color = Slate500
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // Config Dialog
    if (showConfigDialog) {
        var keyInput by remember(config.apiKey) { mutableStateOf(config.apiKey) }
        var secretInput by remember(config.secretKey) { mutableStateOf(config.secretKey) }
        var switchToLive by remember(config.isSandbox) { mutableStateOf(true) }
        var dialogError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showConfigDialog = false },
            containerColor = Color.White,
            title = { Text("Steadfast API Credentials", fontWeight = FontWeight.Bold, color = Slate900) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Steadfast Merchant Portal থেকে আপনার API Key ও Secret Key দিন। সেভ করার সাথে সাথেই লাইভ মোড চালু করতে পারবেন।",
                        fontSize = 12.sp,
                        color = Slate600
                    )
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it; dialogError = null },
                        label = { Text("API Key") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = Slate900,
                            unfocusedTextColor = Slate900,
                            focusedLabelColor = Navy900,
                            unfocusedLabelColor = Slate600
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = secretInput,
                        onValueChange = { secretInput = it; dialogError = null },
                        label = { Text("Secret Key") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = Slate900,
                            unfocusedTextColor = Slate900,
                            focusedLabelColor = Navy900,
                            unfocusedLabelColor = Slate600
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "লাইভ প্রোডাকশন মোড চালু করুন",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Slate900
                            )
                            Text(
                                text = if (switchToLive) "সেভ করলেই Live Mode সক্রিয় হবে" else "শুধু Key সেভ হবে (Sandbox থাকবে)",
                                fontSize = 11.sp,
                                color = if (switchToLive) ProfitGreen else Slate600
                            )
                        }
                        Switch(
                            checked = switchToLive,
                            onCheckedChange = { switchToLive = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = ProfitGreen,
                                checkedTrackColor = ProfitGreenLight
                            )
                        )
                    }
                    if (dialogError != null) {
                        Text(
                            text = dialogError!!,
                            color = LossRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cleanKey = keyInput.trim()
                        val cleanSecret = secretInput.trim()
                        if (switchToLive && (cleanKey.isBlank() || cleanSecret.isBlank())) {
                            dialogError = "লাইভ মোড চালু করতে API Key এবং Secret Key দিন!"
                            return@Button
                        }
                        viewModel.updateSteadfastConfig(cleanKey, cleanSecret, isSandbox = !switchToLive)
                        connectionTestResult = null
                        showConfigDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (switchToLive) ProfitGreen else Navy900)
                ) {
                    Text(if (switchToLive) "Save & Go Live" else "Save Credentials", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfigDialog = false }) { Text("Cancel", color = Slate700) }
            }
        )
    }

    // Production Mode Confirmation Dialog
    if (showProductionConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showProductionConfirmDialog = false },
            containerColor = Color.White,
            title = { Text("Confirm Live Production Mode?", fontWeight = FontWeight.Bold, color = LossRed) },
            text = {
                Text(
                    text = "Are you sure you want to switch to Production Mode? Live parcels will be registered directly with Steadfast Courier and charges will be incurred on your merchant balance.",
                    fontSize = 13.sp,
                    color = Slate700
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateSteadfastConfig(config.apiKey, config.secretKey, isSandbox = false)
                        showProductionConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LossRed)
                ) {
                    Text("Switch to Production", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showProductionConfirmDialog = false }) { Text("Cancel", color = Slate700) }
            }
        )
    }
}

@Composable
private fun CourierStatusSummaryCard(
    title: String,
    count: Int,
    icon: ImageVector,
    accentColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) accentColor.copy(alpha = 0.08f) else Color.White
        ),
        border = if (isSelected) BorderStroke(1.5.dp, accentColor) else BorderStroke(1.dp, Slate200),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 0.dp else 1.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(accentColor.copy(alpha = 0.14f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
                if (isSelected) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = accentColor
                    ) {
                        Text(
                            text = "ফিল্টার",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "$count",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Slate900
            )
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Slate600
            )
        }
    }
}

