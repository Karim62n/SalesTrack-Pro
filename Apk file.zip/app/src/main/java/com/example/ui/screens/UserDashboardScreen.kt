package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Strings
import com.example.ui.components.CircularDonutRing
import com.example.ui.components.SalesBarChart
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@Composable
fun UserDashboardScreen(
    viewModel: MainViewModel,
    strings: Strings,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val permissions by viewModel.userPermissions.collectAsState()
    val userMetrics by viewModel.userMetrics.collectAsState()
    val packagingInfo by viewModel.packagingInfo.collectAsState()
    val adSpendInfo by viewModel.adSpendInfo.collectAsState()
    val boxInfo by viewModel.boxInfo.collectAsState()
    val stickerInfo by viewModel.stickerInfo.collectAsState()

    // Quick Customer Add state
    var custName by remember { mutableStateOf("") }
    var custPhone by remember { mutableStateOf("") }
    var custAddress by remember { mutableStateOf("") }
    var customerSuccessMsg by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate50)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Top Header matching notebook: "User page" & "User ID আর পাসওয়ার্ড দিয়ে লগইন করতে হবে"
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Navy900),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "User page (সেলস ড্যাশবোর্ড)",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "লগইন আইডি: ${currentUser?.userIdCode} • ${currentUser?.fullName}",
                            color = BlueCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = ProfitGreenLight
                    ) {
                        Text(
                            text = "Active Staff",
                            color = ProfitGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SECTION 1: "All Track" (3 Circular Rings as drawn in the User Notebook sketch)
        // 1. Total cost
        // 2. Total profit
        // 3. Total order
        Text(
            text = "All Track",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Navy900,
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Total Cost
            CircularDonutRing(
                title = "Total cost",
                value = if (permissions.canViewTotalCost) "৳${userMetrics.totalCost.toInt()}" else "গোপনীয়",
                percentage = 15,
                ringColor = PendingOrange,
                modifier = Modifier.weight(1f)
            )

            // 2. Total Profit
            CircularDonutRing(
                title = "Total profit",
                value = if (permissions.canViewTotalProfit) "৳${userMetrics.totalProfit.toInt()}" else "গোপনীয়",
                percentage = 25,
                ringColor = ProfitGreen,
                modifier = Modifier.weight(1f)
            )

            // 3. Total Order
            CircularDonutRing(
                title = "Total order",
                value = "${userMetrics.totalOrders} টি",
                percentage = 35,
                ringColor = Blue600,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 2: Notebook User Modules
        Text(
            text = "দৈনিক ও অপারেশনাল ট্র্যাকার (User Tools)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Slate900,
            fontSize = 15.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 1. প্যাকেজিং
        // [টোটাল কত টাকা খরচ হয়েছে তা হিসাব রাখতে পারবে, এবং কতটুকু প্যাকেজিং করা আছে কতটুকু জমা আছে তা দেখতে পারবে]
        UserDetailCard(
            title = "প্যাকেজিং (Packaging Info)",
            description = "টোটাল প্যাকেজিং খরচ: ৳${packagingInfo.totalExpense.toInt()} | প্যাকেজিং করা হয়েছে: ${packagingInfo.totalPiecesUsed} পিস | স্টকে জমা আছে: ${packagingInfo.stockRemainingPieces} পিস",
            icon = Icons.Default.Inventory2,
            iconTint = Navy900
        )

        Spacer(modifier = Modifier.height(8.dp))

        // 2. এড খরচ
        // [মাসে কত ডলার বুস্টিং দিলাম তা দেখবে, এবং কয়টা এড রান ও দৈনিক বাজেট দেখতে পারবে]
        UserDetailCard(
            title = "এড খরচ (Ad & Boosting Info)",
            description = "মাসে বুস্টিং খরচ: $${adSpendInfo.totalDollarsSpent.toInt()} | বর্তমানে চালু এড: ${adSpendInfo.activeAdsCount} টি | দৈনিক বাজেট: $${adSpendInfo.dailyBudgetDollars}",
            icon = Icons.Default.Campaign,
            iconTint = Blue600
        )

        Spacer(modifier = Modifier.height(8.dp))

        // 3. প্যাকেজিং বক্স
        // [কতটি বক্স আছে ও কত টাকা খরচ হয়েছে ও পার পিস হিসাব রাখতে পারবে]
        UserDetailCard(
            title = "প্যাকেজিং বক্স (Boxes in Stock)",
            description = "মোট বক্স আছে: ${boxInfo.totalBoxesStock} টি | খরচ হয়েছে: ৳${boxInfo.totalExpense.toInt()} | প্রতি পিস বক্সের দাম: ৳${boxInfo.perPieceCost}",
            icon = Icons.Default.AllInbox,
            iconTint = PendingOrange
        )

        Spacer(modifier = Modifier.height(8.dp))

        // 4. স্টিকার
        // [টোটাল স্টিকার ও প্রতি পিস কত টাকা ও কয়টি জমা আছে তা দেখতে পারবে]
        UserDetailCard(
            title = "স্টিকার (Stickers Available)",
            description = "টোটাল স্টিকার জমা আছে: ${stickerInfo.totalStickersStock} টি | ব্যবহৃত: ${stickerInfo.totalStickersUsed} টি | প্রতি পিস: ৳${stickerInfo.perPieceCost}",
            icon = Icons.Default.Label,
            iconTint = DeliveredBlue
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 5. সাপ্তাহিক সেল (Weekly Sales)
        // [১ সপ্তাহের হিসাব দেখতে পারবে]
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "সাপ্তাহিক সেল (Weekly Sales Trend)",
                    fontWeight = FontWeight.Bold,
                    color = Slate900,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                val weeklyUserData = listOf(
                    Pair("Sat", 1200.0),
                    Pair("Sun", 2400.0),
                    Pair("Mon", 1800.0),
                    Pair("Tue", 3200.0),
                    Pair("Wed", 2100.0),
                    Pair("Thu", 3800.0),
                    Pair("Fri", 4500.0)
                )

                SalesBarChart(
                    title = "১ সপ্তাহের ব্যক্তিগত বিক্রয় হিসাব",
                    dataPoints = weeklyUserData
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "এই সপ্তাহের অর্জিত ডেলিভার্ড সেল: ৳19,000",
                    fontWeight = FontWeight.Bold,
                    color = ProfitGreen,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 6. কাস্টমার তথ্য যোগ (Add Customer Info)
        // [কাস্টমার নাম, নাম্বার, তথ্য সেভ করতে পারবে]
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "কাস্টমার তথ্য যোগ (Save Customer Info)",
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "কাস্টমার নাম, নাম্বার ও তথ্য সরাসরি সেভ করুন",
                            fontSize = 11.sp,
                            color = Slate600
                        )
                    }
                    Icon(Icons.Default.PersonAddAlt1, contentDescription = null, tint = Navy900)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = custName,
                    onValueChange = { custName = it },
                    label = { Text("কাস্টমারের নাম") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        focusedLabelColor = Slate700,
                        unfocusedLabelColor = Slate600
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = custPhone,
                    onValueChange = { custPhone = it },
                    label = { Text("মোবাইল নম্বর (যেমন: 01711223344)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        focusedLabelColor = Slate700,
                        unfocusedLabelColor = Slate600
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = custAddress,
                    onValueChange = { custAddress = it },
                    label = { Text("ঠিকানা / নোট") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        focusedLabelColor = Slate700,
                        unfocusedLabelColor = Slate600
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (customerSuccessMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = customerSuccessMsg!!,
                        color = ProfitGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (custName.isNotBlank() && custPhone.isNotBlank()) {
                            viewModel.addCustomerDirect(custName, custPhone, custAddress)
                            customerSuccessMsg = "✓ কাস্টমার তথ্য সফলভাবে সেভ হয়েছে!"
                            custName = ""
                            custPhone = ""
                            custAddress = ""
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("কাস্টমার তথ্য সেভ করুন", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun UserDetailCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = iconTint.copy(alpha = 0.12f),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(22.dp))
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, color = Slate900, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = description, fontSize = 12.sp, color = Slate700)
            }
        }
    }
}
