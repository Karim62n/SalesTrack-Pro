package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@Composable
fun LoginScreen(
    viewModel: MainViewModel,
    strings: Strings,
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    // Portal selection: 0 = Admin Portal, 1 = Seller Portal
    var selectedPortal by remember { mutableStateOf(0) }

    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    val authError by viewModel.authError.collectAsState()
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    // Forgot Password Recovery Dialog State
    var showForgotPasswordDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val displayedError = errorMessage ?: authError

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Navy900, Navy800, Slate900)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Language switcher in top corner
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = { viewModel.toggleLanguage() },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.testTag("login_language_toggle")
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Language",
                        tint = BlueCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.BANGLA) "বাংলা" else "English",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // App Logo
            Image(
                painter = painterResource(id = R.drawable.app_logo),
                contentDescription = "SalesTrack Logo",
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(20.dp))
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "SalesTrack Pro",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 24.sp
            )

            Text(
                text = strings.loginSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Slate300,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Portal Selector Tabs: Admin vs Seller
            TabRow(
                selectedTabIndex = selectedPortal,
                containerColor = Navy800,
                contentColor = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
            ) {
                Tab(
                    selected = selectedPortal == 0,
                    onClick = {
                        selectedPortal = 0
                        errorMessage = null
                        viewModel.clearAuthError()
                    },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("অ্যাডমিন পোর্টাল", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedPortal == 1,
                    onClick = {
                        selectedPortal = 1
                        errorMessage = null
                        viewModel.clearAuthError()
                    },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storefront, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("সেলার পোর্টাল", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Secure Login Card (No public self-registration)
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedPortal == 0) "সুপার অ্যাডমিন লগইন" else "সেলার ড্যাশবোর্ড লগইন",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                        Surface(
                            color = ProfitGreenLight,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "🔒 Firebase Auth",
                                color = ProfitGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "অ্যাডমিন কর্তৃক প্রদত্ত ইউজার আইডি বা ইমেইল এবং পাসওয়ার্ড দিয়ে প্রবেশ করুন।",
                        fontSize = 11.sp,
                        color = Slate600
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = identifier,
                        onValueChange = {
                            identifier = it
                            errorMessage = null
                            viewModel.clearAuthError()
                        },
                        label = {
                            Text(
                                if (selectedPortal == 0) "ইমেইল বা আইডি"
                                else "সেলার ইমেইল বা আইডি"
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Person, contentDescription = null, tint = Navy900)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = Slate900,
                            unfocusedTextColor = Slate900,
                            focusedLabelColor = Navy900,
                            unfocusedLabelColor = Slate600,
                            focusedBorderColor = Navy900,
                            unfocusedBorderColor = Slate300
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("user_id_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = null
                            viewModel.clearAuthError()
                        },
                        label = { Text(strings.passwordLabel) },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Navy900)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle password",
                                    tint = Slate600
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = Slate900,
                            unfocusedTextColor = Slate900,
                            focusedLabelColor = Navy900,
                            unfocusedLabelColor = Slate600,
                            focusedBorderColor = Navy900,
                            unfocusedBorderColor = Slate300
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("password_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { showForgotPasswordDialog = true },
                            modifier = Modifier.testTag("forgot_password_button")
                        ) {
                            Text(
                                text = "পাসওয়ার্ড ভুলে গেছেন? (রিসেট রিকোয়েস্ট)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Blue600
                            )
                        }
                    }

                    if (displayedError != null) {
                        Surface(
                            color = LossRedLight,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = displayedError,
                                color = LossRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Primary Email/Password Login Button
                    Button(
                        onClick = {
                            val inputId = identifier.trim()
                            if (inputId.isBlank() || password.isBlank()) {
                                errorMessage = "ইউজার আইডি/ইমেইল এবং পাসওয়ার্ড দিন!"
                                return@Button
                            }
                            isLoading = true
                            errorMessage = null
                            viewModel.login(inputId, password) { success, err ->
                                isLoading = false
                                if (!success) {
                                    errorMessage = err ?: strings.invalidCredentialsError
                                }
                            }
                        },
                        enabled = !isLoading,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = Color.White),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("login_submit_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = strings.loginButton,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Google Sign-In option for Admin / Pre-authorized users
                    OutlinedButton(
                        onClick = {
                            isLoading = true
                            errorMessage = null
                            viewModel.loginWithGoogle(context) { success, err ->
                                isLoading = false
                                if (!success) {
                                    errorMessage = err ?: "Google Sign-In ব্যর্থ হয়েছে"
                                }
                            }
                        },
                        enabled = !isLoading,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Navy900),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("google_signin_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Google Sign-In",
                            tint = Navy900,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Google দিয়ে সাইন-ইন (অনুমোদিত অ্যাকাউন্ট)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Navy900
                        )
                    }

                    if (selectedPortal == 0) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "টিপস: প্রথমবার প্রাইমারি সুপার অ্যাডমিন হিসেবে প্রবেশ করতে আপনার অনুমোদিত Google অ্যাকাউন্ট দিয়ে সাইন-ইন করুন অথবা Firebase Console-এ Email/Password সেট করুন।",
                            fontSize = 10.sp,
                            color = Slate500,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }

    if (showForgotPasswordDialog) {
        ForgotPasswordRequestDialog(
            onDismiss = { showForgotPasswordDialog = false },
            onSubmit = { idInput, phoneInput, reasonInput, onResult ->
                viewModel.requestPasswordReset(idInput, phoneInput, reasonInput, onResult)
            }
        )
    }
}

@Composable
private fun ForgotPasswordRequestDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, String, String, (Boolean, String?) -> Unit) -> Unit
) {
    var userIdInput by remember { mutableStateOf("") }
    var phoneInput by remember { mutableStateOf("") }
    var reasonInput by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var feedbackMsg by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "🔐 পাসওয়ার্ড রিসেট রিকোয়েস্ট",
                fontWeight = FontWeight.Bold,
                color = Slate900
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "নিরাপত্তার স্বার্থে আপনার নিবন্ধিত ইউজার আইডি/ইমেইল এবং মোবাইল নম্বর দিন। সুপার অ্যাডমিন যাচাই করে অনুমোদন দিলে একটি অস্থায়ী পাসওয়ার্ড প্রদান করবেন।",
                    fontSize = 12.sp,
                    color = Slate600
                )
                OutlinedTextField(
                    value = userIdInput,
                    onValueChange = { userIdInput = it; feedbackMsg = null },
                    label = { Text("ইউজার আইডি বা ইমেইল (USR-101)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it; feedbackMsg = null },
                    label = { Text("নিবন্ধিত মোবাইল নম্বর") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = reasonInput,
                    onValueChange = { reasonInput = it },
                    label = { Text("কারণ (ঐচ্ছিক)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (feedbackMsg != null) {
                    Text(
                        text = feedbackMsg!!,
                        color = if (isSuccess) ProfitGreen else LossRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            if (!isSuccess) {
                Button(
                    onClick = {
                        if (userIdInput.isBlank() || phoneInput.isBlank()) {
                            feedbackMsg = "ইউজার আইডি ও মোবাইল নম্বর প্রদান করুন!"
                            return@Button
                        }
                        isSubmitting = true
                        onSubmit(
                            userIdInput,
                            phoneInput,
                            reasonInput.ifBlank { "পাসওয়ার্ড ভুলে গেছি" }
                        ) { ok, msg ->
                            isSubmitting = false
                            isSuccess = ok
                            feedbackMsg = msg
                        }
                    },
                    enabled = !isSubmitting,
                    colors = ButtonDefaults.buttonColors(containerColor = Navy900)
                ) {
                    Text(if (isSubmitting) "পাঠানো হচ্ছে..." else "রিকোয়েস্ট পাঠান")
                }
            } else {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen)
                ) {
                    Text("ঠিক আছে")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বন্ধ করুন")
            }
        }
    )
}
