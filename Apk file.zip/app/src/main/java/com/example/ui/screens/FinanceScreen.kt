package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Strings
import com.example.model.Transaction
import com.example.model.TransactionType
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@Composable
fun FinanceScreen(
    viewModel: MainViewModel,
    strings: Strings,
    modifier: Modifier = Modifier
) {
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    var showAddDialog by remember { mutableStateOf<TransactionType?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Overview & P&L, 1: Ledger / History

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
    ) {
        // Tab selector
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = Navy900
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("P&L Statement", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Financial Ledger (${transactions.size})", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            // P&L Statement and Breakdown
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Net Profit Golden Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Navy900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Net Profit (Audited Formula)",
                            color = BlueCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "৳${metrics.totalProfit.toInt()}",
                            color = if (metrics.totalProfit >= 0) ProfitGreen else LossRed,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Net Profit = Recognized Revenue (৳${metrics.totalSales.toInt()}) - Total Expenses (৳${metrics.totalCost.toInt()})",
                            color = Slate300,
                            fontSize = 12.sp
                        )
                    }
                }

                // Action Buttons for Adding Income / Expense
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { showAddDialog = TransactionType.INCOME },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("add_income_button")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.addIncome, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                    }

                    Button(
                        onClick = { showAddDialog = TransactionType.EXPENSE },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = LossRed),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("add_expense_button")
                    ) {
                        Icon(Icons.Default.RemoveCircle, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.addExpense, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                    }
                }

                // Cost Breakdown Item Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Operating & Product Cost Breakdown",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        CostRow("Delivered Revenue (Recognized Sales)", "৳${metrics.totalSales.toInt()}", ProfitGreen, isPositive = true)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Slate200)
                        CostRow(strings.cogsCost, "৳${metrics.cogsAmount.toInt()}", Slate800)
                        CostRow(strings.adCost, "৳${metrics.adCostAmount.toInt()}", Slate800)
                        CostRow(strings.courierCost, "৳${metrics.courierExpense.toInt()}", Slate800)
                        CostRow(strings.packagingCost, "৳${metrics.packagingExpense.toInt()}", Slate800)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Slate200)
                        CostRow("Calculated Net Profit", "৳${metrics.totalProfit.toInt()}", if (metrics.totalProfit >= 0) ProfitGreen else LossRed, isBold = true)
                    }
                }
            }
        } else {
            // Ledger / Transaction List
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = { showAddDialog = TransactionType.EXPENSE },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Record Entry", fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(transactions, key = { it.id }) { txn ->
                    val currentUser by viewModel.currentUser.collectAsState()
                    val isAdmin = currentUser?.role?.isAdmin == true
                    TransactionItemCard(
                        txn = txn,
                        canDelete = isAdmin,
                        onDelete = { viewModel.deleteTransaction(txn.id) }
                    )
                }
            }
        }
    }

    // Add Income / Expense Dialog
    if (showAddDialog != null) {
        val type = showAddDialog!!
        AddTransactionDialog(
            type = type,
            onDismiss = { showAddDialog = null },
            onConfirm = { cat, amt, desc ->
                viewModel.addTransaction(type, cat, amt, desc)
                showAddDialog = null
            }
        )
    }
}

@Composable
private fun CostRow(title: String, amount: String, color: Color, isPositive: Boolean = false, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = if (isBold) 14.sp else 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
            color = Slate800
        )
        Text(
            text = amount,
            fontSize = if (isBold) 15.sp else 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            color = color
        )
    }
}

@Composable
fun TransactionItemCard(
    txn: Transaction,
    canDelete: Boolean = false,
    onDelete: () -> Unit = {}
) {
    val isIncome = txn.type == TransactionType.INCOME
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isIncome) ProfitGreenLight else LossRedLight
                ) {
                    Icon(
                        imageVector = if (isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = if (isIncome) ProfitGreen else LossRed,
                        modifier = Modifier
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = txn.category,
                        fontWeight = FontWeight.Bold,
                        color = Slate900,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "${txn.transactionCode} • ${txn.description}",
                        fontSize = 12.sp,
                        color = Slate600
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${if (isIncome) "+" else "-"}৳${txn.amount.toInt()}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = if (isIncome) ProfitGreen else LossRed
                )
                if (canDelete) {
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete Transaction",
                            tint = LossRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddTransactionDialog(
    type: TransactionType,
    onDismiss: () -> Unit,
    onConfirm: (String, Double, String) -> Unit
) {
    val isIncome = type == TransactionType.INCOME
    val categories = if (isIncome) {
        listOf("Product Sales", "Courier COD Collection", "Other Income", "Refund Adjustments")
    } else {
        listOf("Product Purchase Cost", "Advertising Cost", "Courier Charge", "Packaging Cost", "Employee Cost", "Operational Cost", "Other Expenses")
    }

    var selectedCategory by remember { mutableStateOf(categories.first()) }
    var amountText by remember { mutableStateOf("0") }
    var description by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isIncome) "Add Income Entry" else "Add Expense Entry", fontWeight = FontWeight.Bold, color = Slate900) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select Category:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Slate900)
                categories.take(4).forEach { cat ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat }
                        )
                        Text(cat, fontSize = 13.sp, color = Slate900)
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount ৳ (0 or custom)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description / Note") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(errorMessage!!, color = LossRed, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt < 0) {
                        errorMessage = "Please enter a valid amount (0 or positive)!"
                        return@Button
                    }
                    onConfirm(selectedCategory, amt, description)
                },
                colors = ButtonDefaults.buttonColors(containerColor = if (isIncome) ProfitGreen else LossRed)
            ) {
                Text("Save Entry")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
