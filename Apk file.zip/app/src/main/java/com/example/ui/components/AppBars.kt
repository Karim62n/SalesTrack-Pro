package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.ui.theme.*

enum class AppNavDestination(
    val titleKey: (Strings) -> String,
    val iconFilled: ImageVector,
    val iconOutlined: ImageVector
) {
    DASHBOARD({ it.navDashboard }, Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    ORDERS({ it.navOrders }, Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart),
    FINANCE({ it.navFinance }, Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
    COURIER({ it.navCourier }, Icons.Filled.LocalShipping, Icons.Outlined.LocalShipping),
    MORE({ it.navSettings }, Icons.Filled.Menu, Icons.Outlined.Menu)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    currentUser: UserProfile?,
    currentLanguage: AppLanguage,
    connectionType: com.example.util.ConnectionType = com.example.util.ConnectionType.CELLULAR,
    onSyncCloud: () -> Unit = {},
    onToggleLanguage: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    TopAppBar(
        modifier = modifier.testTag("app_top_bar"),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.app_logo),
                    contentDescription = "SalesTrack Logo",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "SalesTrack Pro",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        // Live Mobile Data Badge
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = ProfitGreen.copy(alpha = 0.25f)
                        ) {
                            Text(
                                text = if (currentLanguage == AppLanguage.BANGLA) "🟢 ডাটা লাইভ" else "🟢 Data Live",
                                color = ProfitGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (currentUser != null) {
                        Text(
                            text = "${currentUser.fullName} (${currentUser.userIdCode})",
                            style = MaterialTheme.typography.labelSmall,
                            color = BlueCyan,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        },
        actions = {
            // Cloud Sync Icon Button
            IconButton(
                onClick = onSyncCloud,
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CloudSync,
                    contentDescription = "Sync Cloud",
                    tint = BlueCyan,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(2.dp))

            // Language Switcher Button
            OutlinedButton(
                onClick = onToggleLanguage,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("language_switch_button")
            ) {
                Text(
                    text = if (currentLanguage == AppLanguage.BANGLA) "বাং" else "EN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Logout Button
            IconButton(
                onClick = onLogout,
                modifier = Modifier.testTag("logout_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = "Logout",
                    tint = Color.White
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Navy900
        )
    )
}

@Composable
fun AppBottomNav(
    selectedDestination: AppNavDestination,
    onSelectDestination: (AppNavDestination) -> Unit,
    strings: Strings,
    isAdmin: Boolean,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .testTag("app_bottom_nav")
            .windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = Color.White,
        tonalElevation = 8.dp
    ) {
        val destinations = if (isAdmin) {
            listOf(
                AppNavDestination.DASHBOARD,
                AppNavDestination.ORDERS,
                AppNavDestination.FINANCE,
                AppNavDestination.COURIER,
                AppNavDestination.MORE
            )
        } else {
            listOf(
                AppNavDestination.DASHBOARD,
                AppNavDestination.ORDERS,
                AppNavDestination.COURIER,
                AppNavDestination.MORE
            )
        }

        destinations.forEach { dest ->
            val isSelected = dest == selectedDestination
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectDestination(dest) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) dest.iconFilled else dest.iconOutlined,
                        contentDescription = dest.titleKey(strings),
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = dest.titleKey(strings),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Navy900,
                    selectedTextColor = Navy900,
                    indicatorColor = BlueCyan.copy(alpha = 0.25f),
                    unselectedIconColor = Slate600,
                    unselectedTextColor = Slate600
                ),
                modifier = Modifier.testTag("nav_item_${dest.name.lowercase()}")
            )
        }
    }
}
