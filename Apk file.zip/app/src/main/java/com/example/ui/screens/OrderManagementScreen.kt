package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Strings
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.ui.components.OrderStatusBadge
import com.example.ui.theme.*
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderManagementScreen(
    viewModel: MainViewModel,
    strings: Strings,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.filteredOrders.collectAsState()
    val searchQuery by viewModel.orderSearchQuery.collectAsState()
    val statusFilter by viewModel.selectedStatusFilter.collectAsState()
    val products by viewModel.products.collectAsState()
    val isCourierLoading by viewModel.isCourierLoading.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedOrderForDetail by remember { mutableStateOf<Order?>(null) }
    var orderToEdit by remember { mutableStateOf<Order?>(null) }
    var orderToDelete by remember { mutableStateOf<Order?>(null) }

    val currentUser by viewModel.currentUser.collectAsState()
    val permissions by viewModel.userPermissions.collectAsState()
    val isAdmin = currentUser?.role?.isAdmin == true
    val canCreateOrders = isAdmin || (permissions?.canCreateOrders == true)
    val canCreateCourierOrders = isAdmin || (permissions?.canCreateCourierOrders == true)
    val canEdit = isAdmin || (permissions?.canEditOrders == true)
    val canDelete = isAdmin || (permissions?.canDeleteOrders == true)

    val filterScrollState = rememberScrollState()

    Scaffold(
        floatingActionButton = {
            if (canCreateOrders) {
                FloatingActionButton(
                    onClick = { showCreateDialog = true },
                    containerColor = Navy900,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("create_order_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Add, contentDescription = strings.createOrder)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = strings.createOrder, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Slate50)
                .padding(16.dp)
        ) {
            // Prominent Create Order CTA at top of Order Tab (Admin always, Seller when permitted)
            if (canCreateOrders) {
                Button(
                    onClick = { showCreateDialog = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Navy900,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 50.dp)
                        .testTag("top_create_order_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddCircle,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "নতুন অর্ডার তৈরি করুন (Create Order)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setOrderSearch(it) },
                placeholder = { Text("Search by Invoice, Customer or Phone...") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = Slate600)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setOrderSearch("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("order_search_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Slate900,
                    unfocusedTextColor = Slate900,
                    focusedPlaceholderColor = Slate500,
                    unfocusedPlaceholderColor = Slate500
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Status Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(filterScrollState),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = statusFilter == null,
                    onClick = { viewModel.setOrderStatusFilter(null) },
                    label = { Text("All (${orders.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Navy900,
                        selectedLabelColor = Color.White
                    )
                )

                OrderStatus.values().forEach { st ->
                    val isSelected = statusFilter == st
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setOrderStatusFilter(st) },
                        label = { Text(st.displayName) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Navy900,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!canCreateOrders) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PendingOrangeLight,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Text(
                        text = "অর্ডার তৈরি করার অনুমতি বর্তমানে বন্ধ রয়েছে। সুপার অ্যাডমিনের অনুমতি পেলে নতুন অর্ডার তৈরি করতে পারবেন।",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Slate900,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Order List
            if (orders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Inbox,
                            contentDescription = null,
                            tint = Slate400,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No orders found matching filter.",
                            color = Slate600,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(orders, key = { it.id }) { order ->
                        OrderItemCard(
                            order = order,
                            canSendCourier = canCreateCourierOrders,
                            onItemClick = { selectedOrderForDetail = order },
                            onSendSteadfast = { viewModel.sendToSteadfast(order.id) },
                            onUpdateStatus = { newStatus -> viewModel.updateOrderStatus(order.id, newStatus) },
                            isCourierLoading = isCourierLoading
                        )
                    }
                }
            }
        }
    }

    // Create Order Dialog
    if (showCreateDialog) {
        CreateOrderDialog(
            products = products,
            canSendCourier = canCreateCourierOrders,
            onDismiss = { showCreateDialog = false },
            onCreate = { name, phone, district, address, productName, qty, amount, costPerUnit, disc, deliv, sendCourierNow ->
                viewModel.createCustomOrder(
                    customerName = name,
                    customerPhone = phone,
                    customerDistrict = district,
                    customerAddress = address,
                    productName = productName,
                    quantity = qty,
                    productAmount = amount,
                    productCostPerUnit = costPerUnit,
                    discount = disc,
                    deliveryCharge = deliv,
                    sendToCourierImmediately = sendCourierNow
                )
                showCreateDialog = false
            }
        )
    }

    // Order Detail & Status Update Dialog
    if (selectedOrderForDetail != null) {
        OrderDetailDialog(
            order = selectedOrderForDetail!!,
            canEdit = canEdit,
            canDelete = canDelete,
            canSendCourier = canCreateCourierOrders,
            isCourierLoading = isCourierLoading,
            onDismiss = { selectedOrderForDetail = null },
            onUpdateStatus = { newStatus ->
                viewModel.updateOrderStatus(selectedOrderForDetail!!.id, newStatus)
                selectedOrderForDetail = null
            },
            onSendSteadfast = {
                viewModel.sendToSteadfast(selectedOrderForDetail!!.id)
                selectedOrderForDetail = null
            },
            onEditOrder = {
                orderToEdit = selectedOrderForDetail
                selectedOrderForDetail = null
            },
            onDeleteOrder = {
                orderToDelete = selectedOrderForDetail
                selectedOrderForDetail = null
            }
        )
    }

    // Edit Order Dialog
    if (orderToEdit != null) {
        EditOrderDialog(
            order = orderToEdit!!,
            onDismiss = { orderToEdit = null },
            onSave = { updatedOrder ->
                viewModel.updateOrder(updatedOrder)
                orderToEdit = null
            }
        )
    }

    // Delete Order Confirmation
    if (orderToDelete != null) {
        AlertDialog(
            onDismissRequest = { orderToDelete = null },
            title = { Text("অর্ডার মুছে ফেলার নিশ্চিতকরণ", fontWeight = FontWeight.Bold, color = LossRed) },
            text = {
                Text(
                    text = "আপনি কি নিশ্চিত যে অর্ডারটি (${orderToDelete!!.invoiceNumber}) মুছে ফেলতে চান?",
                    color = Slate800,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteOrder(orderToDelete!!.id)
                        orderToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LossRed)
                ) {
                    Text("মুছে ফেলুন (Delete)")
                }
            },
            dismissButton = {
                TextButton(onClick = { orderToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
fun OrderItemCard(
    order: Order,
    canSendCourier: Boolean = true,
    onItemClick: () -> Unit,
    onSendSteadfast: () -> Unit,
    onUpdateStatus: (OrderStatus) -> Unit,
    isCourierLoading: Boolean
) {
    Card(
        onClick = onItemClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("order_item_${order.invoiceNumber}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = order.invoiceNumber,
                        fontWeight = FontWeight.Bold,
                        color = Navy900,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Created by: ${order.createdByName}",
                        fontSize = 11.sp,
                        color = Slate600
                    )
                }
                OrderStatusBadge(status = order.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = order.customerName,
                        fontWeight = FontWeight.SemiBold,
                        color = Slate900,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "${order.customerPhone} • ${order.customerAddress}",
                        fontSize = 12.sp,
                        color = Slate600,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = order.productSummary,
                        fontSize = 12.sp,
                        color = Blue600,
                        fontWeight = FontWeight.Medium
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "৳${order.codAmount.toInt()}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = ProfitGreen
                    )
                    Text(
                        text = "COD Amount",
                        fontSize = 11.sp,
                        color = Slate600
                    )
                }
            }

            // Tracking info if shipped with Steadfast
            if (order.consignmentId != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Slate100,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalShipping,
                            contentDescription = null,
                            tint = DeliveredBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Steadfast Consignment: ${order.consignmentId}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Slate800
                        )
                    }
                }
            } else if (canSendCourier && (order.status == OrderStatus.NEW || order.status == OrderStatus.PENDING || order.status == OrderStatus.CONFIRMED || order.status == OrderStatus.PROCESSING)) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onSendSteadfast,
                    enabled = !isCourierLoading,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Navy900),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 42.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isCourierLoading) "কুরিয়ারে পাঠানো হচ্ছে..." else "Steadfast কুরিয়ারে পাঠান",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun CreateOrderDialog(
    products: List<Product>,
    canSendCourier: Boolean = true,
    onDismiss: () -> Unit,
    onCreate: (
        customerName: String,
        customerPhone: String,
        customerDistrict: String,
        customerAddress: String,
        productName: String,
        qty: Int,
        amount: Double,
        costPerUnit: Double,
        discount: Double,
        deliveryCharge: Double,
        sendToCourierNow: Boolean
    ) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("ঢাকা") }
    var address by remember { mutableStateOf("") }
    val initialProd = products.firstOrNull()
    var productName by remember { mutableStateOf(initialProd?.name ?: "") }
    var quantityText by remember { mutableStateOf("1") }
    var amountText by remember {
        mutableStateOf(
            if (initialProd != null && initialProd.salePrice > 0.0) {
                initialProd.salePrice.toInt().toString()
            } else {
                ""
            }
        )
    }
    var selectedCostPerUnit by remember { mutableStateOf(initialProd?.purchaseCost ?: 0.0) }
    var discountText by remember { mutableStateOf("0") }
    var deliveryChargeText by remember { mutableStateOf("80") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val quickDistricts = listOf(
        "ঢাকা", "চট্টগ্রাম", "গাজীপুর", "কুমিল্লা", "সিলেট",
        "রাজশাহী", "খুলনা", "বরিশাল", "রংপুর", "ময়মনসিংহ"
    )

    val qty = (quantityText.toIntOrNull() ?: 1).coerceAtLeast(1)
    val baseAmount = amountText.toDoubleOrNull() ?: 0.0
    val disc = discountText.toDoubleOrNull() ?: 0.0
    val deliv = deliveryChargeText.toDoubleOrNull() ?: 0.0
    val cod = (baseAmount - disc + deliv).coerceAtLeast(0.0)

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White,
        focusedTextColor = Slate900,
        unfocusedTextColor = Slate900,
        focusedLabelColor = Navy900,
        unfocusedLabelColor = Slate600,
        focusedBorderColor = Navy900,
        unfocusedBorderColor = Slate300
    )

    fun validateAndSubmit(sendToCourierNow: Boolean) {
        if (name.isBlank() || phone.isBlank() || district.isBlank() || address.isBlank()) {
            errorMsg = "কাস্টমারের নাম, মোবাইল নম্বর, জেলা এবং পূর্ণ ঠিকানা দিন!"
            return
        }
        if (baseAmount <= 0.0) {
            errorMsg = "সঠিক টাকার পরিমাণ (Amount ৳) লিখুন!"
            return
        }
        onCreate(
            name,
            phone,
            district,
            address,
            productName.ifBlank { "অর্ডার আইটেম" },
            qty,
            baseAmount,
            selectedCostPerUnit,
            disc,
            deliv,
            sendToCourierNow
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = {
            Text(
                text = "নতুন অর্ডার তৈরি করুন",
                fontWeight = FontWeight.Bold,
                color = Slate900
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMsg = null },
                    label = { Text("কাস্টমারের নাম *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("order_customer_name_input")
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it; errorMsg = null },
                    label = { Text("মোবাইল নম্বর * (যেমন: 01711223344)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("order_customer_phone_input")
                )
                OutlinedTextField(
                    value = district,
                    onValueChange = { district = it; errorMsg = null },
                    label = { Text("জেলা (District) *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("order_customer_district_input")
                )

                // Quick district chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickDistricts.forEach { dist ->
                        FilterChip(
                            selected = district.equals(dist, ignoreCase = true),
                            onClick = { district = dist; errorMsg = null },
                            label = { Text(dist, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Navy900,
                                selectedLabelColor = Color.White,
                                containerColor = Slate100,
                                labelColor = Slate800
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it; errorMsg = null },
                    label = { Text("পূর্ণ ঠিকানা / এলাকা / থানা *") },
                    colors = fieldColors,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("order_customer_address_input")
                )

                if (products.isNotEmpty()) {
                    Text(
                        text = "ক্যাটালগ পণ্য (ঐচ্ছিক দ্রুত নির্বাচন):",
                        fontWeight = FontWeight.SemiBold,
                        color = Slate700,
                        fontSize = 12.sp
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        products.forEach { prod ->
                            FilterChip(
                                selected = productName == prod.name,
                                onClick = {
                                    productName = prod.name
                                    selectedCostPerUnit = prod.purchaseCost
                                    val calculated = (prod.salePrice * qty).toInt()
                                    amountText = calculated.toString()
                                    errorMsg = null
                                },
                                label = { Text("${prod.name} (৳${prod.salePrice.toInt()})", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Blue600,
                                    selectedLabelColor = Color.White,
                                    containerColor = Slate100,
                                    labelColor = Slate800
                                )
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = productName,
                        onValueChange = { productName = it },
                        label = { Text("পণ্যের নাম / বিবরণ") },
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.weight(2f)
                    )
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("সংখ্যা") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it; errorMsg = null },
                        label = { Text("টাকার পরিমাণ (৳) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier
                            .weight(1.4f)
                            .testTag("order_amount_input")
                    )
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = { discountText = it },
                        label = { Text("ছাড় ৳") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = deliveryChargeText,
                        onValueChange = { deliveryChargeText = it },
                        label = { Text("ডেলিভারি ৳") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier.weight(1.1f)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = ProfitGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "মোট COD টাকা:",
                            fontWeight = FontWeight.Bold,
                            color = Slate900,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "৳${cod.toInt()}",
                            fontWeight = FontWeight.Bold,
                            color = ProfitGreen,
                            fontSize = 18.sp
                        )
                    }
                }

                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        color = LossRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (canSendCourier) {
                    Button(
                        onClick = { validateAndSubmit(sendToCourierNow = true) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ProfitGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 46.dp)
                            .testTag("create_and_send_courier_button")
                    ) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("অর্ডার তৈরি ও কুরিয়ারে পাঠান", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { validateAndSubmit(sendToCourierNow = false) },
                colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = Color.White),
                modifier = Modifier.testTag("confirm_create_order_button")
            ) {
                Text("অর্ডার তৈরি করুন", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল", color = Slate700) }
        }
    )
}

@Composable
fun OrderDetailDialog(
    order: Order,
    canEdit: Boolean = true,
    canDelete: Boolean = true,
    canSendCourier: Boolean = true,
    isCourierLoading: Boolean = false,
    onDismiss: () -> Unit,
    onUpdateStatus: (OrderStatus) -> Unit,
    onSendSteadfast: () -> Unit,
    onEditOrder: () -> Unit = {},
    onDeleteOrder: () -> Unit = {}
) {
    var expandedStatus by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(order.invoiceNumber, fontWeight = FontWeight.Bold, color = Slate900)
                OrderStatusBadge(status = order.status)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Customer: ${order.customerName}", fontWeight = FontWeight.Bold, color = Slate900)
                Text("Phone: ${order.customerPhone}", color = Slate800)
                Text("Address: ${order.customerAddress}", color = Slate800)
                Text("Product: ${order.productSummary}", color = Slate800)
                Text("Price: ৳${order.productPrice.toInt()} | Delivery: ৳${order.deliveryCharge.toInt()} | Disc: ৳${order.discount.toInt()}", color = Slate700)
                Text("Total COD: ৳${order.codAmount.toInt()}", fontWeight = FontWeight.Bold, color = ProfitGreen)
                if (order.consignmentId != null) {
                    Text("Steadfast Consignment: ${order.consignmentId}", color = DeliveredBlue, fontWeight = FontWeight.SemiBold)
                    Text("Tracking Code: ${order.trackingCode}", color = Slate700)
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text("Update Order Status:", fontWeight = FontWeight.Bold, color = Slate900)

                Box {
                    OutlinedButton(
                        onClick = { expandedStatus = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Current: ${order.status.displayName} ▾")
                    }
                    DropdownMenu(
                        expanded = expandedStatus,
                        onDismissRequest = { expandedStatus = false }
                    ) {
                        OrderStatus.values().forEach { st ->
                            DropdownMenuItem(
                                text = { Text(st.displayName) },
                                onClick = {
                                    expandedStatus = false
                                    onUpdateStatus(st)
                                }
                            )
                        }
                    }
                }

                if (canSendCourier && order.consignmentId == null &&
                    order.status != OrderStatus.DELIVERED &&
                    order.status != OrderStatus.CANCELLED &&
                    order.status != OrderStatus.RETURNED
                ) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onSendSteadfast,
                        enabled = !isCourierLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = ProfitGreen, contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Steadfast কুরিয়ারে পাঠান", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (canEdit || canDelete) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (canEdit) {
                            OutlinedButton(
                                onClick = onEditOrder,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("অর্ডার এডিট", fontSize = 12.sp)
                            }
                        }
                        if (canDelete) {
                            Button(
                                onClick = onDeleteOrder,
                                colors = ButtonDefaults.buttonColors(containerColor = LossRed),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ডিলিট করুন", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun EditOrderDialog(
    order: Order,
    onDismiss: () -> Unit,
    onSave: (Order) -> Unit
) {
    var customerName by remember { mutableStateOf(order.customerName) }
    var customerPhone by remember { mutableStateOf(order.customerPhone) }
    var customerAddress by remember { mutableStateOf(order.customerAddress) }
    var productSummary by remember { mutableStateOf(order.productSummary) }
    var priceText by remember { mutableStateOf(order.productPrice.toInt().toString()) }
    var discountText by remember { mutableStateOf(order.discount.toInt().toString()) }
    var deliveryChargeText by remember { mutableStateOf(order.deliveryCharge.toInt().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("অর্ডার সম্পাদনা করুন (${order.invoiceNumber})", fontWeight = FontWeight.Bold, color = Slate900) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text("Customer Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = customerPhone,
                    onValueChange = { customerPhone = it },
                    label = { Text("Phone") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = customerAddress,
                    onValueChange = { customerAddress = it },
                    label = { Text("Address") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = productSummary,
                    onValueChange = { productSummary = it },
                    label = { Text("Product Summary") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Price ৳") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = { discountText = it },
                        label = { Text("Disc ৳") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = deliveryChargeText,
                        onValueChange = { deliveryChargeText = it },
                        label = { Text("Delivery ৳") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = priceText.toDoubleOrNull() ?: order.productPrice
                    val d = discountText.toDoubleOrNull() ?: order.discount
                    val del = deliveryChargeText.toDoubleOrNull() ?: order.deliveryCharge
                    val cod = (p - d + del).coerceAtLeast(0.0)

                    val updated = order.copy(
                        customerName = customerName,
                        customerPhone = customerPhone,
                        customerAddress = customerAddress,
                        productSummary = productSummary,
                        productPrice = p,
                        discount = d,
                        deliveryCharge = del,
                        codAmount = cod
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Navy900)
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
