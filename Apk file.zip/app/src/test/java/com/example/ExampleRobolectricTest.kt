package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.auth.FirebaseAuthManager
import com.example.data.BusinessRepository
import com.example.model.AccountStatus
import com.example.model.UserPermissions
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.viewmodel.MainViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import com.google.firebase.functions.FirebaseFunctions
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppResourcesConfigured() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("SalesTrack Pro", context.getString(R.string.app_name))
        assertTrue(context.getString(R.string.firestore_database_id).isNotBlank())
    }

    @Test
    fun testUserIdToEmailResolution() {
        assertEquals("adm-001@salestrack.app", FirebaseAuthManager.normalizeIdentifierToEmail("ADM-001"))
        assertEquals("usr-101@salestrack.app", FirebaseAuthManager.normalizeIdentifierToEmail("  usr-101 "))
        assertEquals("mdk56750@gmail.com", FirebaseAuthManager.normalizeIdentifierToEmail("MDK56750@GMAIL.COM"))
    }

    @Test
    fun testRoleAndPermissionDefaults() {
        assertTrue(UserRole.PRIMARY_SUPER_ADMIN.isAdmin)
        assertTrue(UserRole.SECONDARY_SUPER_ADMIN.isAdmin)
        assertFalse(UserRole.USER.isAdmin)

        val adminPerms = UserPermissions.adminPermissions("adm_uid")
        assertTrue(adminPerms.canViewTotalProfit)
        assertTrue(adminPerms.canDeleteOrders)
        assertTrue(adminPerms.canExportReports)

        val userPerms = UserPermissions.defaultUserPermissions("usr_uid")
        assertFalse(userPerms.canViewTotalProfit)
        assertFalse(userPerms.canDeleteOrders)
        assertTrue(userPerms.canCreateOrders)

        val suspended = UserProfile(uid = "u1", status = AccountStatus.SUSPENDED, isActive = false)
        assertEquals(AccountStatus.SUSPENDED, suspended.status)
    }

    @Test
    fun testMainViewModelInitialization() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val databaseId = context.getString(R.string.firestore_database_id)
        val app = if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(
                context,
                FirebaseOptions.Builder()
                    .setApplicationId("com.aistudio.salestrack.bizapp")
                    .setProjectId("demo-no-project")
                    .setApiKey("fake-api-key")
                    .build()
            )
        } else {
            FirebaseApp.getInstance()
        }

        val db = FirebaseFirestore.getInstance(app, databaseId).apply {
            firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
                .build()
        }
        val auth = FirebaseAuth.getInstance(app)
        auth.signOut()
        val functions = FirebaseFunctions.getInstance(app)

        val repo = BusinessRepository(db, auth, functions)
        val vm = MainViewModel(repo)
        assertNotNull(vm)
        assertNull(vm.currentUser.value)
        assertTrue(vm.orders.value.isEmpty())
        assertTrue(vm.users.value.isEmpty())

        val iidInternal = app.get(com.google.firebase.iid.internal.FirebaseInstanceIdInternal::class.java)
        assertNotNull(iidInternal)
        assertNull(iidInternal.token)
        val legacyIidPresent = runCatching {
            Class.forName("com.google.firebase.iid.FirebaseInstanceId")
        }.isSuccess
        assertFalse("Legacy firebase-iid must be excluded", legacyIidPresent)

        repo.cleanup()
    }
}
