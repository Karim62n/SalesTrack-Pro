package com.example.base

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Before
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE, sdk = [34])
@LooperMode(LooperMode.Mode.INSTRUMENTATION_TEST)
abstract class FirestoreEmulatorTestBase {

    protected lateinit var firestore: FirebaseFirestore
    protected lateinit var auth: FirebaseAuth
    protected lateinit var functions: FirebaseFunctions
    protected lateinit var databaseId: String
    private val httpClient = OkHttpClient()

    @Before
    open fun setUpFirebase() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val resId = context.resources.getIdentifier("firestore_database_id", "string", context.packageName)
        databaseId = if (resId != 0) context.getString(resId) else "ai-studio-android-salestra-7ce3324f-5938-425c-96db-3cec18b439de"

        val app = if (FirebaseApp.getApps(context).isEmpty()) {
            val newApp = FirebaseApp.initializeApp(
                context,
                FirebaseOptions.Builder()
                    .setApplicationId("com.aistudio.salestrack.bizapp")
                    .setProjectId(PROJECT_ID)
                    .setApiKey("fake-api-key-for-emulator")
                    .build()
            )
            val newFirestore = FirebaseFirestore.getInstance(newApp, databaseId)
            newFirestore.useEmulator(EMULATOR_HOST, FIRESTORE_PORT)
            newFirestore.firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
                .build()

            val newAuth = FirebaseAuth.getInstance(newApp)
            newAuth.useEmulator(EMULATOR_HOST, AUTH_PORT)

            val newFunctions = FirebaseFunctions.getInstance(newApp)
            newFunctions.useEmulator(EMULATOR_HOST, FUNCTIONS_PORT)
            newApp
        } else {
            FirebaseApp.getInstance()
        }

        firestore = FirebaseFirestore.getInstance(app, databaseId)
        auth = FirebaseAuth.getInstance(app)
        functions = FirebaseFunctions.getInstance(app)
    }

    @After
    open fun tearDownFirebase() {
        auth.signOut()
    }

    protected suspend fun signInTestUser(email: String, verifyEmail: Boolean = false): String =
        withContext(Dispatchers.IO) {
            withTimeout(AUTH_TIMEOUT_MS) {
                val result = try {
                    auth.signInWithEmailAndPassword(email, DEFAULT_PASSWORD).await()
                } catch (unused: FirebaseAuthInvalidUserException) {
                    auth.createUserWithEmailAndPassword(email, DEFAULT_PASSWORD).await()
                }
                val user = checkNotNull(result.user) { "User auth failed for $email" }
                if (verifyEmail && !user.isEmailVerified) {
                    markEmailVerifiedInEmulator(user.uid)
                    user.reload().await()
                    user.getIdToken(true).await()
                }
                user.uid
            }
        }

    protected suspend fun seedUserProfileInEmulator(
        uid: String,
        userIdCode: String,
        email: String,
        fullName: String,
        role: String,
        status: String = "ACTIVE",
        isActive: Boolean = (status == "ACTIVE")
    ) = withContext(Dispatchers.IO) {
        val nowIso = java.time.Instant.now().toString()
        val json = """
            {
              "fields": {
                "uid": {"stringValue": "$uid"},
                "userIdCode": {"stringValue": "$userIdCode"},
                "email": {"stringValue": "$email"},
                "fullName": {"stringValue": "$fullName"},
                "phone": {"stringValue": "01711000000"},
                "role": {"stringValue": "$role"},
                "status": {"stringValue": "$status"},
                "isActive": {"booleanValue": $isActive},
                "mustChangePasswordOnFirstLogin": {"booleanValue": false},
                "monthlySalesTarget": {"doubleValue": 50000.0},
                "createdAt": {"timestampValue": "$nowIso"},
                "updatedAt": {"timestampValue": "$nowIso"}
              }
            }
        """.trimIndent()
        patchDocumentBypassingRules("users", uid, json)
    }

    protected suspend fun seedOrderInEmulator(
        orderId: String,
        ownerUid: String,
        invoiceNumber: String,
        customerName: String = "Test Customer"
    ) = withContext(Dispatchers.IO) {
        val nowIso = java.time.Instant.now().toString()
        val nowMillis = System.currentTimeMillis()
        val json = """
            {
              "fields": {
                "userId": {"stringValue": "$ownerUid"},
                "invoiceNumber": {"stringValue": "$invoiceNumber"},
                "customerId": {"stringValue": "cust_test"},
                "customerName": {"stringValue": "$customerName"},
                "customerPhone": {"stringValue": "01711223344"},
                "customerAddress": {"stringValue": "Dhaka"},
                "productSummary": {"stringValue": "Test Item (1x)"},
                "productPrice": {"doubleValue": 1500.0},
                "productCost": {"doubleValue": 900.0},
                "discount": {"doubleValue": 0.0},
                "deliveryCharge": {"doubleValue": 80.0},
                "codAmount": {"doubleValue": 1580.0},
                "createdBy": {"stringValue": "$ownerUid"},
                "createdByName": {"stringValue": "Test User"},
                "assignedTo": {"stringValue": ""},
                "status": {"stringValue": "NEW"},
                "orderDateMillis": {"integerValue": "$nowMillis"},
                "updatedAtMillis": {"integerValue": "$nowMillis"},
                "createdAt": {"timestampValue": "$nowIso"},
                "updatedAt": {"timestampValue": "$nowIso"}
              }
            }
        """.trimIndent()
        patchDocumentBypassingRules("orders", orderId, json)
    }

    private fun markEmailVerifiedInEmulator(uid: String) {
        val mediaType = "application/json; charset=utf-8".toMediaType()
        val body = """{"localId":"$uid","emailVerified":true}""".toRequestBody(mediaType)
        val request = Request.Builder()
            .url("http://$EMULATOR_HOST:$AUTH_PORT/identitytoolkit.googleapis.com/v1/projects/$PROJECT_ID/accounts:update")
            .header("Authorization", "Bearer owner")
            .post(body)
            .build()
        httpClient.newCall(request).execute().use { resp ->
            val respBody = resp.body?.string().orEmpty()
            check(resp.isSuccessful) {
                "Auth emulator email verification failed (${resp.code}): $respBody"
            }
        }
    }

    private fun patchDocumentBypassingRules(collection: String, docId: String, jsonBody: String) {
        val mediaType = "application/json; charset=utf-8".toMediaType()
        val body = jsonBody.toRequestBody(mediaType)
        val request = Request.Builder()
            .url("http://$EMULATOR_HOST:$FIRESTORE_PORT/v1/projects/$PROJECT_ID/databases/$databaseId/documents/$collection/$docId")
            .header("Authorization", "Bearer owner")
            .patch(body)
            .build()
        httpClient.newCall(request).execute().use { resp ->
            val respBody = resp.body?.string().orEmpty()
            check(resp.isSuccessful) {
                "Firestore emulator admin seed failed (${resp.code}): $respBody"
            }
        }
    }

    protected fun Throwable.unwrapFirestoreException(): FirebaseFirestoreException? {
        var current: Throwable? = this
        while (current != null) {
            if (current is FirebaseFirestoreException) return current
            current = current.cause
        }
        return null
    }

    private companion object {
        const val EMULATOR_HOST = "127.0.0.1"
        const val FIRESTORE_PORT = 8085
        const val AUTH_PORT = 9099
        const val FUNCTIONS_PORT = 5001
        const val PROJECT_ID = "demo-no-project"
        const val DEFAULT_PASSWORD = "password123"
        const val AUTH_TIMEOUT_MS = 5000L
    }
}
