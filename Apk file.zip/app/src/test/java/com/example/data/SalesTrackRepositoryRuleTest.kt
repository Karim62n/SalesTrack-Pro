package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.Customer
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.UserRole
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class SalesTrackRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun unauthenticatedCaller_queryOrders_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("orders").get().await()
            }
            fail("Expected PERMISSION_DENIED for unauthenticated orders query")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull("Expected FirebaseFirestoreException, got $e", fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
        }
    }

    @Test
    fun allowlistedSuperAdmin_bootstrapsProfileAndSyncsOrdersRealtime() = runBlocking {
        val adminUid = signInTestUser(ADMIN_EMAIL, verifyEmail = true)
        seedUserProfileInEmulator(
            uid = adminUid,
            userIdCode = "ADM-001",
            email = ADMIN_EMAIL,
            fullName = "Primary Super Admin",
            role = UserRole.PRIMARY_SUPER_ADMIN.name,
            status = "ACTIVE"
        )

        val repo = BusinessRepository(firestore, auth, functions)
        try {
            val loadedAdmin = withTimeout(FLOW_TIMEOUT_MS) {
                repo.currentUser.first { it != null && it.uid == adminUid }
            }
            assertEquals(UserRole.PRIMARY_SUPER_ADMIN, loadedAdmin?.role)

            val uniqueId = "ord_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val invoice = "INV-ADM-${uniqueId.takeLast(5)}"
            val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
                repo.createOrder(
                    Order(
                        id = uniqueId,
                        invoiceNumber = invoice,
                        customerId = "cust_adm",
                        customerName = "Admin Client",
                        customerPhone = "01711112222",
                        customerAddress = "Banani, Dhaka",
                        productSummary = "Combo Pack (1x)",
                        productPrice = 2500.0,
                        productCost = 1400.0,
                        discount = 100.0,
                        deliveryCharge = 80.0,
                        codAmount = 2480.0,
                        status = OrderStatus.NEW
                    )
                )
            }
            assertTrue("Expected admin order create to succeed: ${createResult.exceptionOrNull()}", createResult.isSuccess)

            val syncedOrders = withTimeout(FLOW_TIMEOUT_MS) {
                repo.orders.first { list -> list.any { it.id == uniqueId } }
            }
            assertTrue(syncedOrders.any { it.invoiceNumber == invoice })

            // Verify Admin can save Steadfast credentials and switch to Live Production mode (isSandbox = false)
            val sfRes = withTimeout(DEFAULT_TIMEOUT_MS) {
                repo.updateSteadfastConfig("sf_live_key_12345", "sf_live_secret_67890", isSandbox = false)
            }
            assertTrue("Expected Steadfast config update to succeed: ${sfRes.exceptionOrNull()}", sfRes.isSuccess)
            val syncedConfig = withTimeout(FLOW_TIMEOUT_MS) {
                repo.steadfastConfig.first { !it.isSandbox && it.apiKey == "sf_live_key_12345" }
            }
            assertTrue(!syncedConfig.isSandbox)
            assertEquals("sf_live_secret_67890", syncedConfig.secretKey)
        } finally {
            repo.cleanup()
        }
    }

    @Test
    fun activeSeller_createsOwnScopedOrderAndBlockedFromCrossUserOrder() = runBlocking {
        val bobUid = signInTestUser(BOB_EMAIL)
        seedUserProfileInEmulator(
            uid = bobUid,
            userIdCode = "USR-BOB",
            email = BOB_EMAIL,
            fullName = "Bob Seller",
            role = UserRole.USER.name,
            status = "ACTIVE"
        )
        val bobOrderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        seedOrderInEmulator(bobOrderId, bobUid, "INV-BOB-${bobOrderId.takeLast(4)}", "Bob Buyer")

        val aliceUid = signInTestUser(ALICE_EMAIL)
        seedUserProfileInEmulator(
            uid = aliceUid,
            userIdCode = "USR-ALICE",
            email = ALICE_EMAIL,
            fullName = "Alice Seller",
            role = UserRole.USER.name,
            status = "ACTIVE"
        )

        val repo = BusinessRepository(firestore, auth, functions)
        try {
            val loadedAlice = withTimeout(FLOW_TIMEOUT_MS) {
                repo.currentUser.first { it != null && it.uid == aliceUid }
            }
            assertEquals(UserRole.USER, loadedAlice?.role)

            val custId = "cust_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val custRes = withTimeout(DEFAULT_TIMEOUT_MS) {
                repo.addCustomer(
                    Customer(
                        id = custId,
                        name = "Alice Customer",
                        phone = "018${System.currentTimeMillis().toString().takeLast(8)}",
                        address = "Mirpur, Dhaka"
                    )
                )
            }
            assertTrue("Expected seller customer add to succeed: ${custRes.exceptionOrNull()}", custRes.isSuccess)

            val aliceOrderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val aliceOrderRes = withTimeout(DEFAULT_TIMEOUT_MS) {
                repo.createOrder(
                    Order(
                        id = aliceOrderId,
                        invoiceNumber = "INV-ALC-${aliceOrderId.takeLast(5)}",
                        customerId = custId,
                        customerName = "Alice Customer",
                        customerPhone = "01812345678",
                        customerAddress = "Mirpur, Dhaka",
                        productSummary = "Shoe (1x)",
                        productPrice = 1200.0,
                        productCost = 700.0,
                        deliveryCharge = 60.0,
                        codAmount = 1260.0,
                        status = OrderStatus.NEW
                    )
                )
            }
            assertTrue("Expected seller order create to succeed: ${aliceOrderRes.exceptionOrNull()}", aliceOrderRes.isSuccess)

            val aliceOrders = withTimeout(FLOW_TIMEOUT_MS) {
                repo.orders.first { list -> list.any { it.id == aliceOrderId } }
            }
            assertTrue(aliceOrders.all { it.userId == aliceUid })

            // Cross-user read of Bob's private order must fail with PERMISSION_DENIED
            try {
                withTimeout(DEFAULT_TIMEOUT_MS) {
                    firestore.collection("orders").document(bobOrderId).get().await()
                }
                fail("Expected PERMISSION_DENIED for cross-user order access")
            } catch (e: Exception) {
                val fsEx = e.unwrapFirestoreException()
                assertNotNull(fsEx)
                assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
            }

            // Role escalation attempt must fail with PERMISSION_DENIED
            try {
                withTimeout(DEFAULT_TIMEOUT_MS) {
                    firestore.collection("users").document(aliceUid)
                        .update(mapOf("role" to UserRole.PRIMARY_SUPER_ADMIN.name))
                        .await()
                }
                fail("Expected PERMISSION_DENIED on role self-escalation")
            } catch (e: Exception) {
                val fsEx = e.unwrapFirestoreException()
                assertNotNull(fsEx)
                assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
            }
        } finally {
            repo.cleanup()
        }
    }

    @Test
    fun suspendedUser_cannotAccessOrCreateOrders() = runBlocking {
        val suspendedUid = signInTestUser(SUSPENDED_EMAIL)
        seedUserProfileInEmulator(
            uid = suspendedUid,
            userIdCode = "USR-SUSP",
            email = SUSPENDED_EMAIL,
            fullName = "Suspended Seller",
            role = UserRole.USER.name,
            status = "SUSPENDED",
            isActive = false
        )

        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("orders").whereEqualTo("userId", suspendedUid).get().await()
            }
            fail("Expected PERMISSION_DENIED for suspended user querying orders")
        } catch (e: Exception) {
            val fsEx = e.unwrapFirestoreException()
            assertNotNull(fsEx)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
        }
    }

    @Test
    fun primaryAdmin_createsSellerViaSparkFallback_preservesSessionAndEnablesSellerLogin() = runBlocking {
        val adminUid = signInTestUser(ADMIN_EMAIL, verifyEmail = true)
        seedUserProfileInEmulator(
            uid = adminUid,
            userIdCode = "ADM-001",
            email = ADMIN_EMAIL,
            fullName = "Primary Super Admin",
            role = UserRole.PRIMARY_SUPER_ADMIN.name,
            status = "ACTIVE"
        )

        val repo = BusinessRepository(firestore, auth, functions)
        val sellerCode = "USR-${(200..899).random()}"
        val sellerPass = "pass12345"
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.currentUser.first { it != null && it.uid == adminUid }
            }

            // Admin creates a new Seller via Spark-plan Secondary FirebaseApp fallback
            val createRes = withTimeout(15000L) {
                repo.createUser(
                    fullName = "Rahim Seller",
                    phone = "01712345678",
                    email = "",
                    role = UserRole.USER,
                    initialPass = sellerPass,
                    customUserIdCode = sellerCode,
                    monthlyTarget = 60000.0
                )
            }
            assertTrue(
                "Expected Spark-plan seller creation to succeed: ${createRes.exceptionOrNull()?.stackTraceToString()}",
                createRes.isSuccess
            )
            val createdSeller = createRes.getOrThrow()
            assertEquals(sellerCode, createdSeller.userIdCode)
            assertEquals(UserRole.USER, createdSeller.role)

            // Admin's own login session MUST remain completely unchanged
            assertEquals(adminUid, auth.currentUser?.uid)
            assertEquals(ADMIN_EMAIL, auth.currentUser?.email)

            // Newly created Seller profile & permissions must exist in Firestore
            val sellerDoc = withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("users").document(createdSeller.uid).get().await()
            }
            assertTrue(sellerDoc.exists())
            assertEquals("ACTIVE", sellerDoc.getString("status"))
            assertEquals(false, sellerDoc.contains("password"))

            // Sign out Admin and verify Seller can sign in online using User ID + Password
            repo.logout()
            val loginRes = withTimeout(10000L) {
                repo.login(sellerCode, sellerPass)
            }
            assertTrue("Expected new seller login by User ID to succeed: ${loginRes.exceptionOrNull()}", loginRes.isSuccess)
            assertEquals(createdSeller.uid, loginRes.getOrThrow().uid)
            assertEquals(UserRole.USER, loginRes.getOrThrow().role)
        } finally {
            repo.cleanup()
        }
    }

    @Test
    fun primaryAdmin_createsCustomEmailSellerViaSparkFallback_resolvesUserIdOnLogin() = runBlocking {
        val adminUid = signInTestUser(ADMIN_EMAIL, verifyEmail = true)
        seedUserProfileInEmulator(
            uid = adminUid,
            userIdCode = "ADM-001",
            email = ADMIN_EMAIL,
            fullName = "Primary Super Admin",
            role = UserRole.PRIMARY_SUPER_ADMIN.name,
            status = "ACTIVE"
        )

        val repo = BusinessRepository(firestore, auth, functions)
        val sellerCode = "USR-C${(100..899).random()}"
        val customEmail = "seller.${sellerCode.lowercase()}@gmail.com"
        val sellerPass = "customPass99"
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.currentUser.first { it != null && it.uid == adminUid }
            }

            val createRes = withTimeout(15000L) {
                repo.createUser(
                    fullName = "Custom Email Seller",
                    phone = "01811223344",
                    email = customEmail,
                    role = UserRole.USER,
                    initialPass = sellerPass,
                    customUserIdCode = sellerCode,
                    monthlyTarget = 75000.0
                )
            }
            assertTrue(
                "Expected custom-email seller creation to succeed: ${createRes.exceptionOrNull()?.stackTraceToString()}",
                createRes.isSuccess
            )
            val createdSeller = createRes.getOrThrow()
            assertEquals(customEmail, createdSeller.email)
            assertEquals(adminUid, auth.currentUser?.uid)

            val dirDoc = withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("login_directory").document(sellerCode).get().await()
            }
            assertTrue(dirDoc.exists())
            assertEquals(customEmail, dirDoc.getString("email"))

            // Log out Admin and sign in as Seller using only User ID + Password
            repo.logout()
            val loginRes = withTimeout(10000L) {
                repo.login(sellerCode, sellerPass)
            }
            assertTrue(
                "Expected custom-email seller login via User ID to succeed: ${loginRes.exceptionOrNull()}",
                loginRes.isSuccess
            )
            assertEquals(createdSeller.uid, loginRes.getOrThrow().uid)
            assertEquals(customEmail, loginRes.getOrThrow().email)
        } finally {
            repo.cleanup()
        }
    }

    private companion object {
        const val ADMIN_EMAIL = "mdk56750@gmail.com"
        const val ALICE_EMAIL = "usr_alice@salestrack.app"
        const val BOB_EMAIL = "usr_bob@salestrack.app"
        const val SUSPENDED_EMAIL = "usr_suspended@salestrack.app"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}

