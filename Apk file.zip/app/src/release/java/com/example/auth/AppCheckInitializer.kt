package com.example.auth

import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.firebase.FirebaseApp

private const val TAG = "AppCheckInitRelease"

/**
 * Release initialization for direct APK distribution (outside Google Play Store).
 * Intentionally does NOT install PlayIntegrityAppCheckProviderFactory or DebugAppCheckProviderFactory
 * so sideloaded Admin & Seller APKs never fail App Check attestation on any Android phone.
 */
fun configureAppCheck(context: Context, @Suppress("UNUSED_PARAMETER") intent: Intent?) {
    try {
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }
        Log.d(TAG, "Firebase initialized for direct APK release without App Check provider.")
    } catch (e: Exception) {
        Log.e(TAG, "Failed to initialize Firebase in release build", e)
    }
}

fun configureAppCheckForSecondaryApp(
    @Suppress("UNUSED_PARAMETER") context: Context,
    @Suppress("UNUSED_PARAMETER") primaryApp: FirebaseApp,
    @Suppress("UNUSED_PARAMETER") secondaryApp: FirebaseApp
) {
    // No-op for direct APK release builds
}
