const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");
const path = require("node:path");
const rutDir = path.dirname(require.resolve("@firebase/rules-unit-testing"));
const firebase = require(require.resolve("firebase/compat/app", { paths: [rutDir] }));
require(require.resolve("firebase/compat/firestore", { paths: [rutDir] }));

const serverTimestamp = () => firebase.firestore.FieldValue.serverTimestamp();

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const PRIMARY_ADMIN_UID = "admin_primary_1";
const SECONDARY_ADMIN_UID = "admin_secondary_2";
const SELLER_ALICE_UID = "seller_alice_1";
const SELLER_BOB_UID = "seller_bob_2";
const SUSPENDED_UID = "seller_suspended_3";
const DEACTIVATED_UID = "seller_deactivated_4";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

async function seedUsers() {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    const now = serverTimestamp();

    await db.collection("users").doc(PRIMARY_ADMIN_UID).set({
      uid: PRIMARY_ADMIN_UID,
      userIdCode: "ADM-001",
      email: "mdk56750@gmail.com",
      fullName: "Primary Owner",
      phone: "01711000111",
      role: "PRIMARY_SUPER_ADMIN",
      status: "ACTIVE",
      isActive: true,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 100000,
      createdAt: now,
      updatedAt: now,
    });

    await db.collection("users").doc(SECONDARY_ADMIN_UID).set({
      uid: SECONDARY_ADMIN_UID,
      userIdCode: "ADM-002",
      email: "adm-002@salestrack.app",
      fullName: "Secondary Admin",
      phone: "01711000222",
      role: "SECONDARY_SUPER_ADMIN",
      status: "ACTIVE",
      isActive: true,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 80000,
      createdAt: now,
      updatedAt: now,
    });

    await db.collection("users").doc(SELLER_ALICE_UID).set({
      uid: SELLER_ALICE_UID,
      userIdCode: "USR-101",
      email: "usr-101@salestrack.app",
      fullName: "Alice Seller",
      phone: "01811000111",
      role: "USER",
      status: "ACTIVE",
      isActive: true,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 50000,
      createdAt: now,
      updatedAt: now,
    });

    await db.collection("users").doc(SELLER_BOB_UID).set({
      uid: SELLER_BOB_UID,
      userIdCode: "USR-102",
      email: "usr-102@salestrack.app",
      fullName: "Bob Seller",
      phone: "01811000222",
      role: "USER",
      status: "ACTIVE",
      isActive: true,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 50000,
      createdAt: now,
      updatedAt: now,
    });

    await db.collection("users").doc(SUSPENDED_UID).set({
      uid: SUSPENDED_UID,
      userIdCode: "USR-103",
      email: "usr-103@salestrack.app",
      fullName: "Suspended User",
      phone: "01811000333",
      role: "USER",
      status: "SUSPENDED",
      isActive: false,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 50000,
      createdAt: now,
      updatedAt: now,
    });

    await db.collection("users").doc(DEACTIVATED_UID).set({
      uid: DEACTIVATED_UID,
      userIdCode: "USR-104",
      email: "usr-104@salestrack.app",
      fullName: "Deactivated User",
      phone: "01811000444",
      role: "USER",
      status: "DEACTIVATED",
      isActive: false,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 50000,
      createdAt: now,
      updatedAt: now,
    });
  });
}

function validOrderPayload(ownerUid, invoice = "INV-2026-900") {
  const now = serverTimestamp();
  return {
    userId: ownerUid,
    invoiceNumber: invoice,
    customerId: "cust_1",
    customerName: "Shakil Ahmed",
    customerPhone: "01755123456",
    customerAddress: "Dhanmondi, Dhaka",
    productSummary: "Smart Watch (1x)",
    productPrice: 2450,
    productCost: 1200,
    discount: 50,
    deliveryCharge: 80,
    codAmount: 2480,
    createdBy: ownerUid,
    createdByName: "Alice Seller",
    assignedTo: "",
    status: "NEW",
    orderDateMillis: Date.now(),
    updatedAtMillis: Date.now(),
    createdAt: now,
    updatedAt: now,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// 1. Unauthenticated bounds
test("Unauthenticated caller cannot read or write any collection", async () => {
  await seedUsers();
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("orders").get());
  await assertFails(unauthDb.collection("customers").get());
  await assertFails(unauthDb.collection("transactions").get());
  await assertFails(unauthDb.collection("password_reset_requests").get());
  await assertFails(unauthDb.collection("audit_logs").get());
  await assertFails(unauthDb.collection("admin_settings").get());
});

// 2. No public self-registration or privilege escalation
test("Random authenticated user cannot self-register a user profile or admin profile", async () => {
  await seedUsers();
  const rogueDb = testEnv.authenticatedContext("rogue_uid_99", {
    email: "rogue@gmail.com",
    email_verified: true,
  }).firestore();
  const now = serverTimestamp();

  await assertFails(
    rogueDb.collection("users").doc("rogue_uid_99").set({
      uid: "rogue_uid_99",
      userIdCode: "USR-999",
      email: "rogue@gmail.com",
      fullName: "Rogue User",
      phone: "01700000000",
      role: "USER",
      status: "ACTIVE",
      isActive: true,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 50000,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    rogueDb.collection("users").doc("rogue_uid_99").set({
      uid: "rogue_uid_99",
      userIdCode: "ADM-999",
      email: "rogue@gmail.com",
      fullName: "Rogue Admin",
      phone: "01700000000",
      role: "PRIMARY_SUPER_ADMIN",
      status: "ACTIVE",
      isActive: true,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 50000,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Allowlisted Super Admin email can bootstrap first Primary Super Admin profile without passwords", async () => {
  const ownerDb = testEnv.authenticatedContext("owner_boot_uid", {
    email: "mdk56750@gmail.com",
    email_verified: true,
  }).firestore();
  const now = serverTimestamp();

  await assertSucceeds(
    ownerDb.collection("users").doc("owner_boot_uid").set({
      uid: "owner_boot_uid",
      userIdCode: "ADM-001",
      email: "mdk56750@gmail.com",
      fullName: "Owner Admin",
      phone: "01711000111",
      role: "PRIMARY_SUPER_ADMIN",
      status: "ACTIVE",
      isActive: true,
      mustChangePasswordOnFirstLogin: false,
      monthlySalesTarget: 100000,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Regular user cannot escalate own role or status, and cannot store password fields", async () => {
  await seedUsers();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();

  // Cannot escalate role
  await assertFails(
    aliceDb.collection("users").doc(SELLER_ALICE_UID).update({
      role: "PRIMARY_SUPER_ADMIN",
      updatedAt: serverTimestamp(),
    })
  );

  // Cannot write passwordHash
  await assertFails(
    aliceDb.collection("users").doc(SELLER_ALICE_UID).update({
      passwordHash: "123456",
      updatedAt: serverTimestamp(),
    })
  );

  // Can update own display name
  await assertSucceeds(
    aliceDb.collection("users").doc(SELLER_ALICE_UID).update({
      fullName: "Alice Updated",
      updatedAt: serverTimestamp(),
    })
  );

  // Regular user cannot delete user document
  await assertFails(aliceDb.collection("users").doc(SELLER_BOB_UID).delete());

  // Admin can delete user document
  const adminDb = testEnv.authenticatedContext(PRIMARY_ADMIN_UID).firestore();
  await assertSucceeds(adminDb.collection("users").doc(SELLER_BOB_UID).delete());

  // Admin cannot delete Primary Super Admin
  await assertFails(adminDb.collection("users").doc(PRIMARY_ADMIN_UID).delete());
});

// 3. Account suspension / deactivation enforcement
test("Suspended and deactivated users are blocked from reading or writing business data", async () => {
  await seedUsers();
  const suspendedDb = testEnv.authenticatedContext(SUSPENDED_UID).firestore();
  const deactivatedDb = testEnv.authenticatedContext(DEACTIVATED_UID).firestore();

  await assertFails(
    suspendedDb.collection("orders").where("userId", "==", SUSPENDED_UID).get()
  );
  await assertFails(
    suspendedDb.collection("orders").doc("ord_susp").set(validOrderPayload(SUSPENDED_UID))
  );
  await assertFails(
    deactivatedDb.collection("customers").where("userId", "==", DEACTIVATED_UID).get()
  );
  await assertFails(deactivatedDb.collection("products").get());
});

// 4. Per-user private data isolation & Super Admin management
test("Active user can create and query own orders, but fails unfiltered query or reading another user's order", async () => {
  await seedUsers();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(SELLER_BOB_UID).firestore();

  // Alice creates her own order
  await assertSucceeds(
    aliceDb.collection("orders").doc("ord_alice_1").set(validOrderPayload(SELLER_ALICE_UID))
  );

  // Alice can query her own orders with userId filter
  await assertSucceeds(
    aliceDb.collection("orders").where("userId", "==", SELLER_ALICE_UID).get()
  );

  // Alice cannot run an unfiltered collection query
  await assertFails(aliceDb.collection("orders").get());

  // Bob cannot read or delete Alice's order
  await assertFails(bobDb.collection("orders").doc("ord_alice_1").get());
  await assertFails(bobDb.collection("orders").doc("ord_alice_1").delete());

  // Bob cannot spoof Alice's userId on create
  await assertFails(
    bobDb.collection("orders").doc("ord_spoof").set(validOrderPayload(SELLER_ALICE_UID))
  );
});

test("Super Admins (Primary and Secondary) can query all orders, update, and delete any order", async () => {
  await seedUsers();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("orders").doc("ord_alice_2").set(validOrderPayload(SELLER_ALICE_UID))
  );

  const primaryDb = testEnv.authenticatedContext(PRIMARY_ADMIN_UID).firestore();
  const secondaryDb = testEnv.authenticatedContext(SECONDARY_ADMIN_UID).firestore();

  await assertSucceeds(primaryDb.collection("orders").get());
  await assertSucceeds(secondaryDb.collection("orders").get());
  await assertSucceeds(
    secondaryDb.collection("orders").doc("ord_alice_2").update({
      status: "CONFIRMED",
      updatedAt: serverTimestamp(),
    })
  );
  await assertSucceeds(primaryDb.collection("orders").doc("ord_alice_2").delete());
});

// 5. Password reset requests cannot store plain-text or temporary passwords
test("Password reset requests forbid tempPassword and allow user/admin scoped access", async () => {
  await seedUsers();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(SELLER_BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(PRIMARY_ADMIN_UID).firestore();
  const now = serverTimestamp();

  // Reject if tempPassword is included
  await assertFails(
    aliceDb.collection("password_reset_requests").doc("req_bad").set({
      userId: SELLER_ALICE_UID,
      userIdCode: "USR-101",
      userFullName: "Alice Seller",
      email: "usr-101@salestrack.app",
      mobileNumber: "01811000111",
      status: "PENDING",
      tempPassword: "secret",
      requestTimeMillis: Date.now(),
      createdAt: now,
      updatedAt: now,
    })
  );

  // Valid request without password
  await assertSucceeds(
    aliceDb.collection("password_reset_requests").doc("req_ok").set({
      userId: SELLER_ALICE_UID,
      userIdCode: "USR-101",
      userFullName: "Alice Seller",
      email: "usr-101@salestrack.app",
      mobileNumber: "01811000111",
      reason: "Forgot password",
      status: "PENDING",
      requestTimeMillis: Date.now(),
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob cannot read Alice's reset request
  await assertFails(bobDb.collection("password_reset_requests").doc("req_ok").get());

  // Admin can list and approve/update status
  await assertSucceeds(adminDb.collection("password_reset_requests").get());
});

// 6. Audit logs & Admin settings
test("Audit logs are append-only and non-admins cannot read audit logs or admin_settings", async () => {
  await seedUsers();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(PRIMARY_ADMIN_UID).firestore();
  const now = serverTimestamp();

  await assertSucceeds(
    aliceDb.collection("audit_logs").doc("log_1").set({
      action: "Order Created",
      performedBy: SELLER_ALICE_UID,
      performedByName: "Alice Seller",
      targetUserId: SELLER_ALICE_UID,
      details: "Created INV-101",
      timestampMillis: Date.now(),
      createdAt: now,
    })
  );

  // Non-admin cannot read audit logs or admin settings
  await assertFails(aliceDb.collection("audit_logs").get());
  await assertFails(aliceDb.collection("admin_settings").doc("steadfast").get());

  // Even admin cannot update or delete audit logs (immutable)
  await assertSucceeds(adminDb.collection("audit_logs").get());
  await assertFails(adminDb.collection("audit_logs").doc("log_1").update({ action: "Tampered" }));
  await assertFails(adminDb.collection("audit_logs").doc("log_1").delete());

  // Admin can read/write admin_settings
  await assertSucceeds(
    adminDb.collection("admin_settings").doc("steadfast").set({
      apiKey: "key123",
      secretKey: "sec123",
      isSandbox: true,
      isConnected: true,
      updatedAt: now,
    })
  );
});

// 7. Shipments live status sync rules
test("Shipment owner can live-update status and lastSyncedMillis but cannot alter codAmount or another user's shipment", async () => {
  await seedUsers();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(SELLER_BOB_UID).firestore();
  const now = serverTimestamp();

  await assertSucceeds(
    aliceDb.collection("shipments").doc("ship_1").set({
      userId: SELLER_ALICE_UID,
      orderId: "ord_1",
      invoiceNumber: "INV-2026-101",
      consignmentId: "12345678",
      trackingCode: "TRK-101",
      codAmount: 1500,
      deliveryCharge: 120,
      status: "in_review",
      isSandbox: false,
      lastSyncedMillis: Date.now(),
      createdAt: now,
      updatedAt: now,
    })
  );

  // Owner can sync live delivery status & lastSyncedMillis
  await assertSucceeds(
    aliceDb.collection("shipments").doc("ship_1").update({
      status: "in_transit",
      lastSyncedMillis: Date.now(),
      updatedAt: serverTimestamp(),
    })
  );

  // Owner cannot tamper with codAmount
  await assertFails(
    aliceDb.collection("shipments").doc("ship_1").update({
      codAmount: 99999,
      updatedAt: serverTimestamp(),
    })
  );

  // Bob cannot update Alice's shipment
  await assertFails(
    bobDb.collection("shipments").doc("ship_1").update({
      status: "delivered",
      lastSyncedMillis: Date.now(),
      updatedAt: serverTimestamp(),
    })
  );
});

// 8. Admin-delegated Seller permissions for creating orders & sending to courier
test("Seller order and courier creation respect user_permissions granted by Admin", async () => {
  await seedUsers();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(PRIMARY_ADMIN_UID).firestore();
  const now = serverTimestamp();

  // Admin restricts Alice from creating orders or courier shipments
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("user_permissions").doc(SELLER_ALICE_UID).set({
      userId: SELLER_ALICE_UID,
      canViewDashboard: true,
      canViewTotalSales: true,
      canViewTotalCost: false,
      canViewTotalProfit: false,
      canViewOrders: true,
      canCreateOrders: false,
      canEditOrders: false,
      canDeleteOrders: false,
      canViewCustomers: true,
      canAddCustomers: true,
      canViewIncome: false,
      canAddIncome: false,
      canViewExpenses: false,
      canAddExpenses: false,
      canViewCourier: true,
      canCreateCourierOrders: false,
      canViewReturnOrders: true,
      canViewReports: false,
      canExportReports: false,
      updatedAt: now,
    });
  });

  // Alice cannot create an order or shipment when denied
  await assertFails(
    aliceDb.collection("orders").doc("ord_denied").set(validOrderPayload(SELLER_ALICE_UID, "INV-DENIED"))
  );
  await assertFails(
    aliceDb.collection("shipments").doc("ship_denied").set({
      userId: SELLER_ALICE_UID,
      orderId: "ord_denied",
      invoiceNumber: "INV-DENIED",
      consignmentId: "SF-0001",
      trackingCode: "TRK-0001",
      codAmount: 1000,
      deliveryCharge: 80,
      status: "in_review",
      isSandbox: true,
      lastSyncedMillis: Date.now(),
      createdAt: now,
      updatedAt: now,
    })
  );

  // Admin grants Alice permission to create orders and send them to courier
  await assertSucceeds(
    adminDb.collection("user_permissions").doc(SELLER_ALICE_UID).update({
      canCreateOrders: true,
      canCreateCourierOrders: true,
      updatedAt: serverTimestamp(),
    })
  );

  // Now Alice succeeds in creating order and courier shipment
  await assertSucceeds(
    aliceDb.collection("orders").doc("ord_allowed").set(validOrderPayload(SELLER_ALICE_UID, "INV-ALLOW"))
  );
  await assertSucceeds(
    aliceDb.collection("shipments").doc("ship_allowed").set({
      userId: SELLER_ALICE_UID,
      orderId: "ord_allowed",
      invoiceNumber: "INV-ALLOW",
      consignmentId: "SF-0002",
      trackingCode: "TRK-0002",
      codAmount: 1000,
      deliveryCharge: 80,
      status: "in_review",
      isSandbox: true,
      lastSyncedMillis: Date.now(),
      createdAt: now,
      updatedAt: now,
    })
  );
});

// 9. Spark-plan Admin user creation & max-2 Super Admin slot enforcement
test("Primary and Secondary Admins can create Sellers; only Primary Admin can create 1 Secondary Admin; Sellers cannot create users", async () => {
  await seedUsers();
  const primaryDb = testEnv.authenticatedContext(PRIMARY_ADMIN_UID).firestore();
  const secondaryDb = testEnv.authenticatedContext(SECONDARY_ADMIN_UID).firestore();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();
  const now = serverTimestamp();

  const makeUserDoc = (uid, code, email, role) => ({
    uid,
    userIdCode: code,
    email,
    fullName: `Created ${code}`,
    phone: "01799000111",
    role,
    status: "ACTIVE",
    isActive: true,
    mustChangePasswordOnFirstLogin: true,
    monthlySalesTarget: 50000,
    createdAt: now,
    updatedAt: now,
  });

  // Seller cannot create another user
  await assertFails(
    aliceDb.collection("users").doc("rogue_seller_created").set(
      makeUserDoc("rogue_seller_created", "USR-888", "usr-888@salestrack.app", "USER")
    )
  );

  // Admin cannot create a user with plain-text password field
  await assertFails(
    primaryDb.collection("users").doc("bad_pw_user").set({
      ...makeUserDoc("bad_pw_user", "USR-889", "usr-889@salestrack.app", "USER"),
      password: "plaintextpassword",
    })
  );

  // Admin cannot create another PRIMARY_SUPER_ADMIN
  await assertFails(
    primaryDb.collection("users").doc("second_primary").set(
      makeUserDoc("second_primary", "ADM-999", "adm-999@salestrack.app", "PRIMARY_SUPER_ADMIN")
    )
  );

  // Secondary Admin cannot create another SECONDARY_SUPER_ADMIN
  const secAdminBatch = secondaryDb.batch();
  secAdminBatch.set(
    secondaryDb.collection("users").doc("sec_by_sec"),
    makeUserDoc("sec_by_sec", "ADM-003", "adm-003@salestrack.app", "SECONDARY_SUPER_ADMIN")
  );
  secAdminBatch.set(
    secondaryDb.collection("admin_slots").doc("secondary_super_admin"),
    { uid: "sec_by_sec", createdAt: now }
  );
  await assertFails(secAdminBatch.commit());

  // Primary and Secondary Admin CAN create regular Sellers (USER)
  await assertSucceeds(
    primaryDb.collection("users").doc("new_seller_1").set(
      makeUserDoc("new_seller_1", "USR-105", "usr-105@salestrack.app", "USER")
    )
  );
  await assertSucceeds(
    secondaryDb.collection("users").doc("new_seller_2").set(
      makeUserDoc("new_seller_2", "USR-106", "usr-106@salestrack.app", "USER")
    )
  );

  // Primary Admin CAN atomically create 1 Secondary Super Admin with admin_slots lock
  const validSecBatch = primaryDb.batch();
  validSecBatch.set(
    primaryDb.collection("users").doc("new_sec_admin"),
    makeUserDoc("new_sec_admin", "ADM-002B", "adm-002b@salestrack.app", "SECONDARY_SUPER_ADMIN")
  );
  validSecBatch.set(
    primaryDb.collection("admin_slots").doc("secondary_super_admin"),
    { uid: "new_sec_admin", createdAt: now }
  );
  await assertSucceeds(validSecBatch.commit());

  // Primary Admin CANNOT create a 2nd Secondary Super Admin (max 2 Super Admins total)
  const extraSecBatch = primaryDb.batch();
  extraSecBatch.set(
    primaryDb.collection("users").doc("extra_sec_admin"),
    makeUserDoc("extra_sec_admin", "ADM-004", "adm-004@salestrack.app", "SECONDARY_SUPER_ADMIN")
  );
  extraSecBatch.set(
    primaryDb.collection("admin_slots").doc("secondary_super_admin"),
    { uid: "extra_sec_admin", createdAt: now }
  );
  await assertFails(extraSecBatch.commit());
});

// 10. Minimal login_directory security (get by exact User ID only; list blocked; admin-only writes)
test("login_directory blocks collection listing and non-admin writes while permitting single-ID get", async () => {
  await seedUsers();
  const primaryDb = testEnv.authenticatedContext(PRIMARY_ADMIN_UID).firestore();
  const aliceDb = testEnv.authenticatedContext(SELLER_ALICE_UID).firestore();
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const now = serverTimestamp();

  // Seller and unauthenticated caller cannot write to login_directory
  await assertFails(
    aliceDb.collection("login_directory").doc("USR-777").set({
      email: "rogue@gmail.com",
      updatedAt: now,
    })
  );
  await assertFails(
    unauthDb.collection("login_directory").doc("USR-777").set({
      email: "rogue@gmail.com",
      updatedAt: now,
    })
  );

  // Admin cannot store extra PII fields in login_directory
  await assertFails(
    primaryDb.collection("login_directory").doc("USR-777").set({
      email: "seller777@gmail.com",
      phone: "01711111111",
      updatedAt: now,
    })
  );

  // Admin can write minimal { email, updatedAt } mapping
  await assertSucceeds(
    primaryDb.collection("login_directory").doc("USR-777").set({
      email: "seller777@gmail.com",
      updatedAt: now,
    })
  );

  // Listing login_directory is strictly blocked even for authenticated users
  await assertFails(unauthDb.collection("login_directory").get());
  await assertFails(aliceDb.collection("login_directory").get());

  // Exact-ID get succeeds for User ID login resolution
  await assertSucceeds(unauthDb.collection("login_directory").doc("USR-777").get());
});


