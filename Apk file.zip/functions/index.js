const { onCall, HttpsError } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const crypto = require("crypto");

admin.initializeApp();

const DATABASE_ID = "ai-studio-android-salestra-7ce3324f-5938-425c-96db-3cec18b439de";
const db = getFirestore(DATABASE_ID);
const auth = admin.auth();

const BOOTSTRAPPED_SUPER_ADMIN_EMAIL = "mdk56750@gmail.com";
const DEFAULT_EMAIL_DOMAIN = "salestrack.app";

function normalizeEmailFromIdentifier(identifier) {
  const trimmed = String(identifier || "").trim();
  if (!trimmed) return "";
  if (trimmed.includes("@")) return trimmed.toLowerCase();
  const safeCode = trimmed.toLowerCase().replace(/[^a-z0-9._-]/g, "");
  return `${safeCode}@${DEFAULT_EMAIL_DOMAIN}`;
}

function normalizePhoneDigits(phone) {
  return String(phone || "").replace(/\D/g, "");
}

function defaultPermissionsForRole(userId, isAdmin) {
  return {
    userId,
    canViewDashboard: true,
    canViewTotalSales: true,
    canViewTotalCost: isAdmin,
    canViewTotalProfit: isAdmin,
    canViewOrders: true,
    canCreateOrders: true,
    canEditOrders: isAdmin,
    canDeleteOrders: isAdmin,
    canViewCustomers: true,
    canAddCustomers: true,
    canViewIncome: isAdmin,
    canAddIncome: isAdmin,
    canViewExpenses: isAdmin,
    canAddExpenses: isAdmin,
    canViewCourier: true,
    canCreateCourierOrders: isAdmin,
    canViewReturnOrders: true,
    canViewReports: isAdmin,
    canExportReports: isAdmin,
    updatedAt: FieldValue.serverTimestamp(),
  };
}

async function requireActiveAdmin(request) {
  if (!request.auth || !request.auth.uid) {
    throw new HttpsError("unauthenticated", "Authentication required.");
  }
  const callerSnap = await db.collection("users").doc(request.auth.uid).get();
  if (!callerSnap.exists) {
    throw new HttpsError("permission-denied", "Admin profile not found.");
  }
  const caller = callerSnap.data();
  if (!caller.isActive || caller.status !== "ACTIVE") {
    throw new HttpsError("permission-denied", "Caller account is not active.");
  }
  if (caller.role !== "PRIMARY_SUPER_ADMIN" && caller.role !== "SECONDARY_SUPER_ADMIN") {
    throw new HttpsError("permission-denied", "Super Admin privileges required.");
  }
  return { uid: request.auth.uid, profile: caller };
}

async function writeAuditLog(action, performedBy, performedByName, targetUserId, details) {
  const ref = db.collection("audit_logs").doc();
  await ref.set({
    action,
    performedBy,
    performedByName,
    targetUserId: targetUserId || "",
    details,
    timestampMillis: Date.now(),
    createdAt: FieldValue.serverTimestamp(),
  });
}

/**
 * Resolves a User ID code (e.g., ADM-001, USR-101) to the account's registered Auth email
 * so users created with custom emails can still sign in with their User ID code.
 */
exports.resolveLoginEmail = onCall({ region: "us-central1" }, async (request) => {
  const raw = String(request.data?.identifier || "").trim();
  if (!raw) {
    return { email: null };
  }
  if (raw.includes("@")) {
    return { email: raw.toLowerCase() };
  }
  const code = raw.toUpperCase();
  const snap = await db.collection("users").where("userIdCode", "==", code).limit(1).get();
  if (!snap.empty) {
    const data = snap.docs[0].data();
    return { email: data.email || normalizeEmailFromIdentifier(code) };
  }
  return { email: null };
});

/**
 * Non-destructively initializes the first Primary Super Admin account (only if none exists
 * or caller matches BOOTSTRAPPED_SUPER_ADMIN_EMAIL). Never overwrites existing user data.
 */
exports.bootstrapSuperAdmin = onCall({ region: "us-central1" }, async (request) => {
  if (!request.auth || !request.auth.uid) {
    throw new HttpsError("unauthenticated", "Sign in required before bootstrapping Super Admin.");
  }

  const uid = request.auth.uid;
  const email = (request.auth.token.email || "").toLowerCase();
  const emailVerified = request.auth.token.email_verified === true;
  const existingUserDoc = await db.collection("users").doc(uid).get();

  if (existingUserDoc.exists) {
    return { status: "already_exists", profile: existingUserDoc.data() };
  }

  const primaryAdminsSnap = await db
    .collection("users")
    .where("role", "==", "PRIMARY_SUPER_ADMIN")
    .limit(1)
    .get();

  const isAllowlistedOwner = email === BOOTSTRAPPED_SUPER_ADMIN_EMAIL && emailVerified;
  if (!primaryAdminsSnap.empty && !isAllowlistedOwner) {
    throw new HttpsError(
      "permission-denied",
      "Public registration is disabled. Contact a Super Admin to create your account."
    );
  }

  const fullName = String(request.data?.fullName || request.auth.token.name || "Primary Super Admin").trim();
  const phone = String(request.data?.phone || "").trim();
  const userIdCode = String(request.data?.userIdCode || "ADM-001").trim().toUpperCase();

  const profileData = {
    uid,
    userIdCode,
    email,
    fullName,
    phone,
    role: "PRIMARY_SUPER_ADMIN",
    status: "ACTIVE",
    isActive: true,
    mustChangePasswordOnFirstLogin: false,
    monthlySalesTarget: 100000,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  };

  const batch = db.batch();
  batch.set(db.collection("users").doc(uid), profileData);
  batch.set(db.collection("user_permissions").doc(uid), defaultPermissionsForRole(uid, true));
  await batch.commit();

  await auth.setCustomUserClaims(uid, { role: "PRIMARY_SUPER_ADMIN", status: "ACTIVE" });
  await writeAuditLog("Bootstrap Super Admin", uid, fullName, uid, `Initialized Primary Super Admin (${userIdCode})`);

  return { status: "created", profile: profileData };
});

/**
 * Privileged User Creation by Super Admin (no public self-registration).
 * Enforces max 2 Super Admins (1 Primary + 1 Secondary) and stores NO passwords in Firestore.
 */
exports.createManagedUser = onCall({ region: "us-central1" }, async (request) => {
  const { uid: adminUid, profile: adminProfile } = await requireActiveAdmin(request);

  const fullName = String(request.data?.fullName || "").trim();
  const phone = String(request.data?.phone || "").trim();
  const requestedRole = String(request.data?.role || "USER").trim();
  const password = String(request.data?.password || "");
  const customUserIdCode = String(request.data?.userIdCode || "").trim().toUpperCase();
  const rawEmail = String(request.data?.email || "").trim().toLowerCase();
  const monthlySalesTarget = Number(request.data?.monthlySalesTarget ?? 50000);
  const mustChangePasswordOnFirstLogin = Boolean(request.data?.mustChangePasswordOnFirstLogin ?? true);

  if (!fullName || !phone || password.length < 6) {
    throw new HttpsError("invalid-argument", "Full name, phone, and a password of at least 6 characters are required.");
  }

  if (requestedRole !== "USER" && requestedRole !== "SECONDARY_SUPER_ADMIN") {
    throw new HttpsError("invalid-argument", "Invalid target role.");
  }

  if (requestedRole === "SECONDARY_SUPER_ADMIN") {
    if (adminProfile.role !== "PRIMARY_SUPER_ADMIN") {
      throw new HttpsError("permission-denied", "Only the Primary Super Admin can create a Secondary Super Admin.");
    }
    const existingSuperAdmins = await db
      .collection("users")
      .where("role", "in", ["PRIMARY_SUPER_ADMIN", "SECONDARY_SUPER_ADMIN"])
      .get();
    if (existingSuperAdmins.size >= 2) {
      throw new HttpsError("failed-precondition", "Maximum of 2 Super Admin accounts reached.");
    }
  }

  const prefix = requestedRole === "SECONDARY_SUPER_ADMIN" ? "ADM" : "USR";
  const userIdCode = customUserIdCode || `${prefix}-${Math.floor(100 + Math.random() * 900)}`;

  const duplicateCodeSnap = await db.collection("users").where("userIdCode", "==", userIdCode).limit(1).get();
  if (!duplicateCodeSnap.empty) {
    throw new HttpsError("already-exists", `User ID '${userIdCode}' already exists.`);
  }

  const email = rawEmail || normalizeEmailFromIdentifier(userIdCode);

  let authUser;
  try {
    authUser = await auth.createUser({
      email,
      password,
      displayName: fullName,
      disabled: false,
    });
  } catch (err) {
    throw new HttpsError("already-exists", err.message || "Failed to create Firebase Auth user.");
  }

  const newUid = authUser.uid;
  const isAdminRole = requestedRole === "SECONDARY_SUPER_ADMIN";

  const userDoc = {
    uid: newUid,
    userIdCode,
    email,
    fullName,
    phone,
    role: requestedRole,
    status: "ACTIVE",
    isActive: true,
    mustChangePasswordOnFirstLogin,
    monthlySalesTarget: Number.isFinite(monthlySalesTarget) && monthlySalesTarget >= 0 ? monthlySalesTarget : 50000,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  };

  const now = Date.now();
  const batch = db.batch();
  batch.set(db.collection("users").doc(newUid), userDoc);
  batch.set(db.collection("user_permissions").doc(newUid), defaultPermissionsForRole(newUid, isAdminRole));
  batch.set(db.collection("sales_targets").doc(`target_${newUid}`), {
    userId: newUid,
    period: "MONTHLY",
    targetAmount: userDoc.monthlySalesTarget,
    startDate: now,
    endDate: now + 30 * 24 * 60 * 60 * 1000,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });
  await batch.commit();

  await auth.setCustomUserClaims(newUid, { role: requestedRole, status: "ACTIVE" });
  await writeAuditLog(
    "User Created",
    adminUid,
    adminProfile.fullName,
    newUid,
    `Created ${requestedRole} account ${fullName} (${userIdCode} / ${email})`
  );

  return {
    uid: newUid,
    userIdCode,
    email,
    fullName,
    phone,
    role: requestedRole,
    status: "ACTIVE",
    isActive: true,
    mustChangePasswordOnFirstLogin,
    monthlySalesTarget: userDoc.monthlySalesTarget,
  };
});

/**
 * Activate, Deactivate, or Suspend a user across both Firebase Auth and Firestore.
 */
exports.updateUserAccountStatus = onCall({ region: "us-central1" }, async (request) => {
  const { uid: adminUid, profile: adminProfile } = await requireActiveAdmin(request);

  const targetUid = String(request.data?.targetUid || "").trim();
  const newStatus = String(request.data?.status || "").trim();

  if (!targetUid || !["ACTIVE", "DEACTIVATED", "SUSPENDED"].includes(newStatus)) {
    throw new HttpsError("invalid-argument", "Valid targetUid and status (ACTIVE, DEACTIVATED, SUSPENDED) required.");
  }

  if (targetUid === adminUid) {
    throw new HttpsError("failed-precondition", "Cannot change your own account status.");
  }

  const targetRef = db.collection("users").doc(targetUid);
  const targetSnap = await targetRef.get();
  if (!targetSnap.exists) {
    throw new HttpsError("not-found", "Target user not found.");
  }
  const target = targetSnap.data();

  if (target.role === "PRIMARY_SUPER_ADMIN") {
    throw new HttpsError("permission-denied", "Primary Super Admin cannot be deactivated or suspended.");
  }
  if (target.role === "SECONDARY_SUPER_ADMIN" && adminProfile.role !== "PRIMARY_SUPER_ADMIN") {
    throw new HttpsError("permission-denied", "Only Primary Super Admin can manage Secondary Super Admin status.");
  }

  const isActive = newStatus === "ACTIVE";
  await auth.updateUser(targetUid, { disabled: !isActive });
  if (!isActive) {
    await auth.revokeRefreshTokens(targetUid);
  }
  await auth.setCustomUserClaims(targetUid, { role: target.role, status: newStatus });

  await targetRef.update({
    status: newStatus,
    isActive,
    updatedAt: FieldValue.serverTimestamp(),
  });

  await writeAuditLog(
    `User Status: ${newStatus}`,
    adminUid,
    adminProfile.fullName,
    targetUid,
    `Changed status of ${target.fullName} (${target.userIdCode}) to ${newStatus}`
  );

  return { success: true, targetUid, status: newStatus, isActive };
});

/**
 * Delete a managed user from Firebase Auth and Firestore.
 */
exports.deleteManagedUser = onCall({ region: "us-central1" }, async (request) => {
  const { uid: adminUid, profile: adminProfile } = await requireActiveAdmin(request);
  const targetUid = String(request.data?.targetUid || "").trim();

  if (!targetUid) {
    throw new HttpsError("invalid-argument", "targetUid is required.");
  }
  if (targetUid === adminUid) {
    throw new HttpsError("failed-precondition", "Cannot delete your own account.");
  }

  const targetRef = db.collection("users").doc(targetUid);
  const targetSnap = await targetRef.get();
  if (!targetSnap.exists) {
    throw new HttpsError("not-found", "Target user not found.");
  }
  const target = targetSnap.data();

  if (target.role === "PRIMARY_SUPER_ADMIN") {
    throw new HttpsError("permission-denied", "Primary Super Admin cannot be deleted.");
  }
  if (target.role === "SECONDARY_SUPER_ADMIN" && adminProfile.role !== "PRIMARY_SUPER_ADMIN") {
    throw new HttpsError("permission-denied", "Only Primary Super Admin can remove a Secondary Super Admin.");
  }

  try {
    await auth.deleteUser(targetUid);
  } catch (err) {
    if (err.code !== "auth/user-not-found") {
      throw new HttpsError("internal", err.message || "Failed to delete Auth user.");
    }
  }

  const batch = db.batch();
  batch.delete(targetRef);
  batch.delete(db.collection("user_permissions").doc(targetUid));
  await batch.commit();

  await writeAuditLog(
    "User Deleted",
    adminUid,
    adminProfile.fullName,
    targetUid,
    `Deleted user ${target.fullName} (${target.userIdCode})`
  );

  return { success: true, targetUid };
});

/**
 * Public callable for unauthenticated users to submit an Admin-approved Password Recovery Request.
 * Validates userIdCode/email and registered mobile number without exposing user documents.
 */
exports.requestPasswordReset = onCall({ region: "us-central1" }, async (request) => {
  const identifier = String(request.data?.identifier || "").trim();
  const mobileNumber = String(request.data?.mobileNumber || "").trim();
  const reason = String(request.data?.reason || "Password forgotten").trim().slice(0, 300);

  if (!identifier || !mobileNumber) {
    throw new HttpsError("invalid-argument", "User ID / Email and registered mobile number are required.");
  }

  let userSnap;
  if (identifier.includes("@")) {
    userSnap = await db.collection("users").where("email", "==", identifier.toLowerCase()).limit(1).get();
  } else {
    userSnap = await db.collection("users").where("userIdCode", "==", identifier.toUpperCase()).limit(1).get();
    if (userSnap.empty) {
      const derivedEmail = normalizeEmailFromIdentifier(identifier);
      userSnap = await db.collection("users").where("email", "==", derivedEmail).limit(1).get();
    }
  }

  if (userSnap.empty) {
    throw new HttpsError("not-found", "Matching user account not found.");
  }

  const userDoc = userSnap.docs[0];
  const userData = userDoc.data();

  if (normalizePhoneDigits(userData.phone) !== normalizePhoneDigits(mobileNumber)) {
    throw new HttpsError("permission-denied", "Mobile number does not match the registered account.");
  }

  const existingPending = await db
    .collection("password_reset_requests")
    .where("userId", "==", userData.uid)
    .where("status", "==", "PENDING")
    .limit(1)
    .get();

  if (!existingPending.empty) {
    throw new HttpsError("already-exists", "A pending password reset request already exists for this user.");
  }

  const reqRef = db.collection("password_reset_requests").doc();
  const now = Date.now();
  await reqRef.set({
    userId: userData.uid,
    userIdCode: userData.userIdCode,
    userFullName: userData.fullName,
    email: userData.email,
    mobileNumber: userData.phone,
    reason,
    status: "PENDING",
    requestTimeMillis: now,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });

  await writeAuditLog(
    "Password Reset Requested",
    userData.uid,
    userData.fullName,
    userData.uid,
    `Password reset requested for ${userData.userIdCode}`
  );

  return { success: true, requestId: reqRef.id };
});

/**
 * Super Admin approves a password reset request: sets a one-time temporary password directly
 * in Firebase Auth via Admin SDK, forces password change on next login, and returns the
 * temporary password strictly in the HTTPS response (NEVER written to Firestore).
 */
exports.approvePasswordReset = onCall({ region: "us-central1" }, async (request) => {
  const { uid: adminUid, profile: adminProfile } = await requireActiveAdmin(request);
  const requestId = String(request.data?.requestId || "").trim();

  if (!requestId) {
    throw new HttpsError("invalid-argument", "requestId is required.");
  }

  const reqRef = db.collection("password_reset_requests").doc(requestId);
  const reqSnap = await reqRef.get();
  if (!reqSnap.exists) {
    throw new HttpsError("not-found", "Password reset request not found.");
  }
  const reqData = reqSnap.data();
  if (reqData.status !== "PENDING") {
    throw new HttpsError("failed-precondition", "This request has already been processed.");
  }

  const randomCode = crypto.randomBytes(4).toString("hex").toUpperCase();
  const tempPassword = `ST-${randomCode}`;

  await auth.updateUser(reqData.userId, {
    password: tempPassword,
    disabled: false,
  });
  await auth.revokeRefreshTokens(reqData.userId);

  const batch = db.batch();
  batch.update(db.collection("users").doc(reqData.userId), {
    mustChangePasswordOnFirstLogin: true,
    status: "ACTIVE",
    isActive: true,
    updatedAt: FieldValue.serverTimestamp(),
  });
  batch.update(reqRef, {
    status: "APPROVED",
    approvedBy: adminUid,
    approvedByName: adminProfile.fullName,
    resolvedTimeMillis: Date.now(),
    updatedAt: FieldValue.serverTimestamp(),
  });
  await batch.commit();

  await writeAuditLog(
    "Password Reset Approved",
    adminUid,
    adminProfile.fullName,
    reqData.userId,
    `Approved password reset for ${reqData.userFullName} (${reqData.userIdCode})`
  );

  return {
    success: true,
    tempPassword,
    userIdCode: reqData.userIdCode,
    email: reqData.email,
  };
});

/**
 * Super Admin rejects a password reset request.
 */
exports.rejectPasswordReset = onCall({ region: "us-central1" }, async (request) => {
  const { uid: adminUid, profile: adminProfile } = await requireActiveAdmin(request);
  const requestId = String(request.data?.requestId || "").trim();
  const rejectionReason = String(request.data?.rejectionReason || "Rejected by Super Admin").trim().slice(0, 300);

  if (!requestId) {
    throw new HttpsError("invalid-argument", "requestId is required.");
  }

  const reqRef = db.collection("password_reset_requests").doc(requestId);
  const reqSnap = await reqRef.get();
  if (!reqSnap.exists) {
    throw new HttpsError("not-found", "Password reset request not found.");
  }
  const reqData = reqSnap.data();

  await reqRef.update({
    status: "REJECTED",
    approvedBy: adminUid,
    approvedByName: adminProfile.fullName,
    rejectionReason,
    resolvedTimeMillis: Date.now(),
    updatedAt: FieldValue.serverTimestamp(),
  });

  await writeAuditLog(
    "Password Reset Rejected",
    adminUid,
    adminProfile.fullName,
    reqData.userId,
    `Rejected password reset for ${reqData.userIdCode}: ${rejectionReason}`
  );

  return { success: true };
});

/**
 * Dispatches an existing order to Steadfast Courier on behalf of an Admin or a Seller
 * who has been granted `canCreateCourierOrders` permission, keeping merchant API keys
 * strictly server-side inside `admin_settings/steadfast`.
 */
exports.dispatchOrderToSteadfast = onCall({ region: "us-central1" }, async (request) => {
  if (!request.auth || !request.auth.uid) {
    throw new HttpsError("unauthenticated", "Authentication required.");
  }
  const uid = request.auth.uid;
  const orderId = String(request.data?.orderId || "").trim();
  if (!orderId) {
    throw new HttpsError("invalid-argument", "orderId is required.");
  }

  const userSnap = await db.collection("users").doc(uid).get();
  if (!userSnap.exists) {
    throw new HttpsError("permission-denied", "User profile not found.");
  }
  const userProfile = userSnap.data();
  if (!userProfile.isActive || userProfile.status !== "ACTIVE") {
    throw new HttpsError("permission-denied", "Account is not active.");
  }

  const isAdmin =
    userProfile.role === "PRIMARY_SUPER_ADMIN" ||
    userProfile.role === "SECONDARY_SUPER_ADMIN";

  if (!isAdmin) {
    const permSnap = await db.collection("user_permissions").doc(uid).get();
    const canCourier = permSnap.exists && permSnap.data()?.canCreateCourierOrders === true;
    if (!canCourier) {
      throw new HttpsError(
        "permission-denied",
        "আপনার কুরিয়ারে অর্ডার পাঠানোর অনুমতি নেই। সুপার অ্যাডমিনের অনুমতি নিন।"
      );
    }
  }

  const orderRef = db.collection("orders").doc(orderId);
  const orderSnap = await orderRef.get();
  if (!orderSnap.exists) {
    throw new HttpsError("not-found", "Order not found.");
  }
  const order = orderSnap.data();
  if (!isAdmin && order.userId !== uid) {
    throw new HttpsError("permission-denied", "You can only dispatch your own orders.");
  }
  if (order.consignmentId) {
    throw new HttpsError("already-exists", `Order already dispatched (${order.consignmentId}).`);
  }

  const configSnap = await db.collection("admin_settings").doc("steadfast").get();
  const config = configSnap.exists ? configSnap.data() : { isSandbox: true, apiKey: "", secretKey: "" };
  const isSandbox = config.isSandbox !== false;

  let consignmentId;
  let trackingCode;
  let shipmentStatus = "in_review";

  if (isSandbox) {
    const rnd = Math.floor(100000 + Math.random() * 900000);
    consignmentId = `SF-${rnd}`;
    trackingCode = `TRK-${String(order.invoiceNumber || orderId).replace(/-/g, "")}-${rnd}`;
  } else {
    const apiKey = String(config.apiKey || "").trim();
    const secretKey = String(config.secretKey || "").trim();
    if (!apiKey || !secretKey) {
      throw new HttpsError(
        "failed-precondition",
        "সুপার অ্যাডমিন এখনো Steadfast Live API Key ও Secret Key সেট করেননি।"
      );
    }

    const resp = await fetch("https://portal.packzy.com/api/v1/create_order", {
      method: "POST",
      headers: {
        "Api-Key": apiKey,
        "Secret-Key": secretKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        invoice: order.invoiceNumber,
        recipient_name: order.customerName,
        recipient_phone: order.customerPhone,
        recipient_address: order.customerAddress,
        cod_amount: Number(order.codAmount || 0),
        note: `SalesTrack Order ${order.invoiceNumber}`,
      }),
    });

    const rawText = await resp.text();
    let parsed;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      throw new HttpsError("internal", `Steadfast API error (${resp.status}): ${rawText.slice(0, 120)}`);
    }

    if (!resp.ok || parsed.status !== 200 || !parsed.consignment) {
      throw new HttpsError(
        "failed-precondition",
        parsed.message || `Steadfast API rejected order (${resp.status})`
      );
    }

    consignmentId = String(parsed.consignment.consignment_id || "");
    trackingCode = String(parsed.consignment.tracking_code || "");
    shipmentStatus = String(parsed.consignment.status || "in_review");
  }

  const shipId = `ship_${crypto.randomBytes(8).toString("hex")}`;
  const nowMillis = Date.now();
  const ownerUid = order.userId || uid;

  const batch = db.batch();
  batch.set(db.collection("shipments").doc(shipId), {
    userId: ownerUid,
    orderId,
    invoiceNumber: order.invoiceNumber,
    consignmentId,
    trackingCode,
    codAmount: Number(order.codAmount || 0),
    deliveryCharge: Number(order.deliveryCharge || 120),
    status: shipmentStatus,
    isSandbox,
    lastSyncedMillis: nowMillis,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });
  batch.update(orderRef, {
    consignmentId,
    trackingCode,
    status: "SHIPPED",
    updatedAtMillis: nowMillis,
    updatedAt: FieldValue.serverTimestamp(),
  });
  await batch.commit();

  await writeAuditLog(
    "Courier Dispatched",
    uid,
    userProfile.fullName || "Staff",
    ownerUid,
    `Dispatched ${order.invoiceNumber} to Steadfast (${consignmentId})`
  );

  return {
    id: shipId,
    userId: ownerUid,
    orderId,
    invoiceNumber: order.invoiceNumber,
    consignmentId,
    trackingCode,
    codAmount: Number(order.codAmount || 0),
    deliveryCharge: Number(order.deliveryCharge || 120),
    status: shipmentStatus,
    isSandbox,
    lastSyncedMillis: nowMillis,
  };
});

