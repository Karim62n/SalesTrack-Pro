-- ==============================================================================
-- PRODUCTION SUPABASE / POSTGRESQL SCHEMA FOR BUSINESS & AUTHENTICATION SYSTEM
-- Roles: Primary Super Admin (Owner), Secondary Super Admin, Sales User
-- Features: Strict Hierarchy, Admin Account Creation, 18 Permissions, 
--           Password Recovery Request Hub, Single-use Temp Passwords, Audit Logs
-- ==============================================================================

-- 1. Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Custom Role Enum & Status Enum
DO $$ BEGIN
    CREATE TYPE user_role_type AS ENUM ('PRIMARY_SUPER_ADMIN', 'SECONDARY_SUPER_ADMIN', 'USER');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE reset_status_type AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'USED');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 3. PROFILES TABLE (Linked with Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    user_id_code TEXT UNIQUE NOT NULL, -- e.g. 'ADM-001', 'ADM-002', 'USR-101'
    full_name TEXT NOT NULL,
    phone TEXT UNIQUE NOT NULL,
    role user_role_type NOT NULL DEFAULT 'USER',
    is_active BOOLEAN NOT NULL DEFAULT true,
    must_change_password BOOLEAN NOT NULL DEFAULT false,
    monthly_sales_target NUMERIC(12, 2) NOT NULL DEFAULT 50000.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexing for fast lookups
CREATE INDEX IF NOT EXISTS idx_profiles_user_id_code ON public.profiles(user_id_code);
CREATE INDEX IF NOT EXISTS idx_profiles_phone ON public.profiles(phone);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);

-- 4. ADMIN ROLES & HIERARCHY TABLE
CREATE TABLE IF NOT EXISTS public.admin_roles (
    admin_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
    hierarchy_level INT NOT NULL CHECK (hierarchy_level IN (1, 2)), -- 1: Primary, 2: Secondary
    can_manage_secondary_admin BOOLEAN NOT NULL DEFAULT false, -- Strictly true only for Primary Admin
    can_manage_users BOOLEAN NOT NULL DEFAULT true,
    can_reset_passwords BOOLEAN NOT NULL DEFAULT true,
    can_view_all_reports BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. 18-GRANULAR USER PERMISSIONS MATRIX
CREATE TABLE IF NOT EXISTS public.user_permissions (
    user_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
    can_view_dashboard BOOLEAN NOT NULL DEFAULT true,
    can_view_total_sales BOOLEAN NOT NULL DEFAULT true,
    can_view_total_cost BOOLEAN NOT NULL DEFAULT false,
    can_view_total_profit BOOLEAN NOT NULL DEFAULT false,
    can_view_orders BOOLEAN NOT NULL DEFAULT true,
    can_create_orders BOOLEAN NOT NULL DEFAULT true,
    can_edit_orders BOOLEAN NOT NULL DEFAULT false,
    can_delete_orders BOOLEAN NOT NULL DEFAULT false,
    can_view_customers BOOLEAN NOT NULL DEFAULT true,
    can_add_customers BOOLEAN NOT NULL DEFAULT true,
    can_view_income BOOLEAN NOT NULL DEFAULT false,
    can_add_income BOOLEAN NOT NULL DEFAULT false,
    can_view_expenses BOOLEAN NOT NULL DEFAULT false,
    can_add_expenses BOOLEAN NOT NULL DEFAULT false,
    can_view_courier BOOLEAN NOT NULL DEFAULT true,
    can_create_courier_orders BOOLEAN NOT NULL DEFAULT false,
    can_view_return_orders BOOLEAN NOT NULL DEFAULT true,
    can_view_reports BOOLEAN NOT NULL DEFAULT false,
    can_export_reports BOOLEAN NOT NULL DEFAULT false,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. PASSWORD RESET REQUESTS TABLE
CREATE TABLE IF NOT EXISTS public.password_reset_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id_code TEXT NOT NULL,
    mobile_number TEXT NOT NULL,
    status reset_status_type NOT NULL DEFAULT 'PENDING',
    temp_password_hash TEXT,
    approved_by UUID REFERENCES public.profiles(id),
    rejection_reason TEXT,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_reset_status ON public.password_reset_requests(status);
CREATE INDEX IF NOT EXISTS idx_reset_user_code ON public.password_reset_requests(user_id_code);

-- 7. AUDIT LOGS & SECURITY TRAIL
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action TEXT NOT NULL,
    performed_by UUID REFERENCES public.profiles(id),
    performed_by_name TEXT,
    target_user_id TEXT,
    details TEXT NOT NULL,
    ip_address TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_created ON public.audit_logs(created_at DESC);

-- ==============================================================================
-- DATABASE CONSTRAINTS & SECURITY TRIGGERS (ADMIN HIERARCHY PROTECTION)
-- ==============================================================================

-- Function 1: Prevent anyone from deactivating or demoting the Primary Super Admin
CREATE OR REPLACE FUNCTION public.check_primary_admin_protection()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.role = 'PRIMARY_SUPER_ADMIN' THEN
        -- Prevent changing role
        IF NEW.role != 'PRIMARY_SUPER_ADMIN' THEN
            RAISE EXCEPTION 'Primary Super Admin (Owner) role cannot be changed or demoted!';
        END IF;
        -- Prevent deactivating
        IF NEW.is_active = false THEN
            RAISE EXCEPTION 'Primary Super Admin (Owner) account cannot be deactivated!';
        END IF;
    END IF;
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_protect_primary_admin ON public.profiles;
CREATE TRIGGER trg_protect_primary_admin
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.check_primary_admin_protection();

-- Function 2: Prevent Secondary Super Admin from creating another Super Admin
CREATE OR REPLACE FUNCTION public.validate_admin_hierarchy_creation()
RETURNS TRIGGER AS $$
DECLARE
    creator_role user_role_type;
BEGIN
    SELECT role INTO creator_role FROM public.profiles WHERE id = auth.uid();
    
    IF creator_role = 'SECONDARY_SUPER_ADMIN' AND NEW.role != 'USER' THEN
        RAISE EXCEPTION 'Secondary Super Admin cannot create another Super Admin account. Only Primary Super Admin (Owner) can!';
    END IF;

    IF creator_role = 'USER' THEN
        RAISE EXCEPTION 'Unauthorized: Regular users cannot create user accounts!';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.password_reset_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Helper security function: Check if current authenticated user is an Admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND (role = 'PRIMARY_SUPER_ADMIN' OR role = 'SECONDARY_SUPER_ADMIN')
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Profiles Policies
CREATE POLICY "Admins can view all profiles"
ON public.profiles FOR SELECT
TO authenticated
USING (public.is_admin() OR id = auth.uid());

CREATE POLICY "Admins can update user profiles"
ON public.profiles FOR UPDATE
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

CREATE POLICY "Admins can insert profiles"
ON public.profiles FOR INSERT
TO authenticated
WITH CHECK (public.is_admin());

-- Password Reset Requests Policies
-- Anyone (even unauthenticated) can insert a password reset request without user enumeration
CREATE POLICY "Anyone can submit a password reset request"
ON public.password_reset_requests FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Only Admins can view or approve reset requests
CREATE POLICY "Only admins can view reset requests"
ON public.password_reset_requests FOR SELECT
TO authenticated
USING (public.is_admin());

CREATE POLICY "Only admins can resolve reset requests"
ON public.password_reset_requests FOR UPDATE
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Audit Logs Policies
CREATE POLICY "Admins can view audit logs"
ON public.audit_logs FOR SELECT
TO authenticated
USING (public.is_admin());

CREATE POLICY "System can record audit logs"
ON public.audit_logs FOR INSERT
TO authenticated
WITH CHECK (true);
