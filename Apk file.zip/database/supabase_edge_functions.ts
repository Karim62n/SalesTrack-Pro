// ==============================================================================
// SUPABASE EDGE FUNCTIONS FOR ADMIN-CONTROLLED AUTHENTICATION & RECOVERY
// Environment: Deno / TypeScript (Supabase Edge Runtime)
// ==============================================================================

import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.21.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ------------------------------------------------------------------------------
// FUNCTION 1: handle-password-reset-request
// Triggered when user enters User ID & Mobile on Forgot Password screen
// ------------------------------------------------------------------------------
export async function handlePasswordResetRequest(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { userIdCode, mobileNumber } = await req.json();

    if (!userIdCode || !mobileNumber) {
      return new Response(
        JSON.stringify({ error: "User ID and Mobile Number are required." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Initialize Supabase Admin Client using Service Role Key
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Verify user exists and registered phone matches (anti-enumeration response)
    const { data: userProfile, error: userError } = await supabaseAdmin
      .from("profiles")
      .select("id, user_id_code, full_name, phone, is_active")
      .eq("user_id_code", userIdCode.trim().toUpperCase())
      .single();

    // If matching user found, insert into password_reset_requests
    if (userProfile && userProfile.phone.endsWith(mobileNumber.trim().slice(-8))) {
      // Check if already has a pending request
      const { data: existing } = await supabaseAdmin
        .from("password_reset_requests")
        .select("id")
        .eq("user_id_code", userProfile.user_id_code)
        .eq("status", "PENDING")
        .maybeSingle();

      if (!existing) {
        await supabaseAdmin.from("password_reset_requests").insert({
          user_id_code: userProfile.user_id_code,
          mobile_number: userProfile.phone,
          status: "PENDING",
        });

        // Record Audit Log
        await supabaseAdmin.from("audit_logs").insert({
          action: "Password Reset Requested",
          performed_by: userProfile.id,
          performed_by_name: userProfile.full_name,
          target_user_id: userProfile.user_id_code,
          details: `Password recovery request received for user ${userProfile.user_id_code}`,
        });
      }
    }

    // Always return success message to prevent user enumeration attacks
    return new Response(
      JSON.stringify({
        success: true,
        message: "পাসওয়ার্ড রিসেট আবেদন সফলভাবে জমা হয়েছে। অ্যাডমিন ভেরিফাই করে অনুমোদন করলে আপনাকে একটি ওয়ান-টাইম পাসওয়ার্ড প্রদান করবেন।",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
}

// ------------------------------------------------------------------------------
// FUNCTION 2: admin-approve-password-reset
// Called by Primary or Secondary Super Admin to generate single-use temp password
// ------------------------------------------------------------------------------
export async function adminApprovePasswordReset(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { requestId } = await req.json();
    if (!requestId) {
      return new Response(
        JSON.stringify({ error: "Request ID is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Verify caller has Super Admin role
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token);

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid admin authentication token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data: adminProfile } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, role")
      .eq("id", user.id)
      .single();

    if (!adminProfile || (adminProfile.role !== "PRIMARY_SUPER_ADMIN" && adminProfile.role !== "SECONDARY_SUPER_ADMIN")) {
      return new Response(
        JSON.stringify({ error: "Forbidden: Only authorized Super Admins can approve password reset requests" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Retrieve pending request
    const { data: resetReq, error: reqError } = await supabaseAdmin
      .from("password_reset_requests")
      .select("*")
      .eq("id", requestId)
      .single();

    if (reqError || !resetReq || resetReq.status !== "PENDING") {
      return new Response(
        JSON.stringify({ error: "Invalid or already resolved reset request" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get target user profile
    const { data: targetUser } = await supabaseAdmin
      .from("profiles")
      .select("id, user_id_code, full_name")
      .eq("user_id_code", resetReq.user_id_code)
      .single();

    if (!targetUser) {
      return new Response(
        JSON.stringify({ error: "Target user not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Generate secure single-use 6-character temporary password
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const tempPassword = `TMP-${randomDigits}`;

    // 1. Update Supabase Auth user password
    const { error: updateAuthError } = await supabaseAdmin.auth.admin.updateUserById(
      targetUser.id,
      { password: tempPassword }
    );

    if (updateAuthError) {
      throw updateAuthError;
    }

    // 2. Set must_change_password flag in profiles
    await supabaseAdmin
      .from("profiles")
      .update({ must_change_password: true, updated_at: new Date().toISOString() })
      .eq("id", targetUser.id);

    // 3. Mark request as APPROVED
    await supabaseAdmin
      .from("password_reset_requests")
      .update({
        status: "APPROVED",
        approved_by: adminProfile.id,
        resolved_at: new Date().toISOString(),
      })
      .eq("id", requestId);

    // 4. Log Audit Trail
    await supabaseAdmin.from("audit_logs").insert({
      action: "Password Reset Approved",
      performed_by: adminProfile.id,
      performed_by_name: adminProfile.full_name,
      target_user_id: targetUser.user_id_code,
      details: `${adminProfile.role} approved reset for ${targetUser.user_id_code}. Single-use temporary password issued.`,
    });

    return new Response(
      JSON.stringify({
        success: true,
        tempPassword: tempPassword,
        message: "অস্থায়ী পাসওয়ার্ড সফলভাবে তৈরি হয়েছে।",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
}
